<?php include __DIR__ . '/../layout/layout.php'; ?>

<div class="min-h-screen flex justify-center items-center bg-ivory px-4">
  <div class="w-full max-w-2xl bg-white border border-ether rounded-lg shadow p-10">
    <h2 class="text-2xl font-serif text-navy mb-6">Edit Product</h2>

    <form method="POST"
          action="/zenithco/public/index.php?page=edit_product&id=<?= $product['id'] ?>"
          enctype="multipart/form-data" class="space-y-6">

      <input type="hidden" name="old_image" value="<?= htmlspecialchars($product['image']) ?>">

      <!-- Product Name -->
      <div>
        <label class="block text-sm font-medium text-essence mb-1">Product Name</label>
        <input type="text" name="name" required
               value="<?= htmlspecialchars($product['name']) ?>"
               class="w-full px-4 py-3 bg-ether border border-ether rounded-md">
      </div>

      <!-- Price -->
      <div>
        <label class="block text-sm font-medium text-essence mb-1">Price (LKR)</label>
        <input type="number" name="price" step="0.01" required
               value="<?= $product['price'] ?>"
               class="w-full px-4 py-3 bg-ether border border-ether rounded-md">
      </div>

      <!-- Description -->
      <div>
        <label class="block text-sm font-medium text-essence mb-1">Description</label>
        <textarea name="description" rows="4"
                  class="w-full px-4 py-3 bg-ether border border-ether rounded-md"><?= htmlspecialchars($product['description']) ?></textarea>
      </div>

      <!-- Image Upload -->
      <div>
        <label class="block text-sm font-medium text-essence mb-1">Current Image</label>
        <img src="<?= $product['image'] ?>" class="h-40 object-cover mb-2 rounded">
        <input type="file" name="image"
               class="w-full px-4 py-2 border border-ether bg-ether rounded-md">
      </div>

      <!-- Stock -->
      <div>
        <label class="block text-sm font-medium text-essence mb-1">Stock</label>
        <input type="number" name="stock" required
               value="<?= $product['stock'] ?>"
               class="w-full px-4 py-3 bg-ether border border-ether rounded-md">
      </div>

      <!-- Submit -->
      <button type="submit"
              class="bg-ember hover:bg-essence text-white px-6 py-3 rounded-lg transition">
        Update Product
      </button>
    </form>
  </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
