<?php include __DIR__ . '/../layout/layout.php'; ?>

<div class="min-h-screen flex flex-col items-center justify-center bg-ivory p-6">
    <div class="text-center mb-8">
        <h1 class="font-display text-5xl text-navy tracking-wide">Zenith & Co</h1>
        <p class="font-sans text-sm uppercase tracking-widest text-essence mt-2">Admin Portal</p>
    </div>

    <div class="w-full max-w-md bg-white rounded-lg luxury-shadow overflow-hidden">
        <div class="bg-mist px-8 py-6 border-b border-ether">
            <h2 class="font-serif text-2xl font-medium text-essence">Administrator Login</h2>
            <div class="h-0.5 w-12 bg-ember mt-3"></div>
        </div>

        <div class="px-8 py-8 bg-white">
            <?php if (isset($error)): ?>
                <div class="bg-red-50 border-l-4 border-red-400 p-4 mb-6 rounded">
                    <p class="text-red-700 font-medium"><?= htmlspecialchars($error) ?></p>
                </div>
            <?php endif; ?>

            <form action="/zenithco/public/index.php?page=admin_login" method="post" class="space-y-6">
                <div class="space-y-2">
                    <label class="block text-essence text-sm font-medium" for="username">Username</label>
                    <input class="w-full px-4 py-3 border border-ether rounded-md bg-ivory focus:outline-none focus:ring-2 focus:ring-ember" name="username" id="username" required>
                </div>

                <div class="space-y-2">
                    <label class="block text-essence text-sm font-medium" for="password">Password</label>
                    <input class="w-full px-4 py-3 border border-ether rounded-md bg-ivory focus:outline-none focus:ring-2 focus:ring-ember" name="password" id="password" type="password" required>
                </div>

                <div class="pt-2">
                    <button class="w-full bg-navy hover:bg-essence text-ivory font-medium py-3 px-4 rounded-md transition duration-300" type="submit" name="login">
                        Sign In
                    </button>
                </div>
            </form>
        </div>

        <div class="px-8 py-4 bg-ether border-t border-mist">
            <p class="text-xs text-essence text-center">
                &copy; <?= date('Y') ?> Zenith & Co. All rights reserved.
            </p>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
