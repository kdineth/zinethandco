<?php
include __DIR__ . '/../layout/userheader.php';
?>

<main class="bg-pure">

  <!-- Hero Section -->
  <section class="relative py-24 lg:py-32 bg-pure">
    <div class="max-w-7xl mx-auto px-6">
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        
        <!-- Left Content -->
        <div class="space-y-8">
          <div class="space-y-6">
            <p class="text-primary text-sm font-semibold uppercase tracking-wide">Premium Jewelry Collection</p>
            <h1 class="text-5xl lg:text-6xl font-display text-charcoal leading-tight">
              Crafted for
              <span class="text-primary">Excellence</span>
            </h1>
            <p class="text-xl text-storm leading-relaxed max-w-lg">
              Discover timeless pieces that combine traditional craftsmanship with modern design. 
              Each creation reflects our commitment to quality and elegance.
            </p>
          </div>
          
          <div class="flex flex-col sm:flex-row gap-4">
            <a href="#collection" class="inline-flex items-center justify-center px-8 py-4 bg-primary text-pure font-semibold rounded-lg hover:bg-primary_dark transition-colors duration-200">
              Shop Collection
            </a>
            <a href="#contact" class="inline-flex items-center justify-center px-8 py-4 border-2 border-steel text-charcoal font-semibold rounded-lg hover:border-primary hover:text-primary transition-colors duration-200">
              Learn More
            </a>
          </div>
        </div>
        
        <!-- Right Content -->
        <div class="relative">
          <img src="/zenithco/public/images/hero.jpg" alt="Premium Jewelry Collection" 
               class="w-full h-96 object-cover rounded-lg">
        </div>
      </div>
    </div>
  </section>

  <!-- Stats Section -->
  <section class="py-16 bg-ghost">
    <div class="max-w-7xl mx-auto px-6">
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
        <div>
          <p class="text-3xl font-bold text-charcoal">37+</p>
          <p class="text-storm mt-1">Years Experience</p>
        </div>
        <div>
          <p class="text-3xl font-bold text-charcoal">10K+</p>
          <p class="text-storm mt-1">Happy Customers</p>
        </div>
        <div>
          <p class="text-3xl font-bold text-charcoal">500+</p>
          <p class="text-storm mt-1">Unique Designs</p>
        </div>
        <div>
          <p class="text-3xl font-bold text-charcoal">100%</p>
          <p class="text-storm mt-1">Quality Guarantee</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Product Grid Section -->
  <section id="collection" class="py-20 bg-pure">
    <div class="max-w-7xl mx-auto px-6">
      <div class="text-center mb-16">
        <h2 class="text-4xl font-display text-charcoal mb-4">Featured Products</h2>
        <p class="text-xl text-storm max-w-2xl mx-auto">
          Explore our carefully curated selection of premium jewelry pieces
        </p>
      </div>
      
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        <?php
        $search = $_GET['search'] ?? '';
        $filtered = [];

        foreach ($products as $product) {
          if ($search === '' || stripos($product['name'], $search) !== false || stripos($product['description'], $search) !== false) {
            $filtered[] = $product;
          }
        }
        ?>

        <?php if (!empty($filtered)): ?>
          <?php foreach ($filtered as $product): ?>
            <div class="group bg-pure border border-silver rounded-xl overflow-hidden hover:border-primary transition-colors duration-200 shadow-soft hover:shadow-medium">
              <div class="relative">
                <a href="/zenithco/public/index.php?page=product_detail&id=<?= $product['id'] ?>" class="block">
                  <div class="aspect-square bg-ghost overflow-hidden">
                    <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>"
                         class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
                  </div>
                </a>
                
                <!-- Wishlist Button -->
                <?php if (isset($_SESSION['user_id'])): ?>
                  <form method="POST" action="/zenithco/public/index.php?page=add_wishlist" class="absolute top-3 right-3">
                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                    <button type="submit" title="Add to Wishlist" 
                            class="w-9 h-9 bg-pure/90 backdrop-blur-sm border border-silver/50 rounded-full flex items-center justify-center text-steel hover:text-primary hover:bg-primary/5 hover:border-primary/30 transition-all duration-200">
                      <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
                      </svg>
                    </button>
                  </form>
                <?php endif; ?>
              </div>
              
              <div class="p-4">
                <a href="/zenithco/public/index.php?page=product_detail&id=<?= $product['id'] ?>" class="block">
                  <h3 class="text-lg font-semibold text-charcoal mb-2 group-hover:text-primary transition-colors line-clamp-1">
                    <?= htmlspecialchars($product['name']) ?>
                  </h3>
                  <p class="text-sm text-storm mb-3 line-clamp-2"><?= htmlspecialchars($product['description']) ?></p>
                  <p class="text-xl font-bold text-primary">LKR <?= number_format($product['price'], 2) ?></p>
                </a>
                
                <!-- Action Buttons -->
                <div class="mt-4 space-y-2">
                  <?php if (isset($_SESSION['user_id'])): ?>
                    <form method="POST" action="/zenithco/public/index.php" class="w-full">
                      <input type="hidden" name="action" value="add_to_cart">
                      <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                      <input type="hidden" name="quantity" value="1">
                      <button type="submit" class="w-full bg-primary text-pure font-semibold py-2.5 rounded-lg hover:bg-primary_dark transition-colors duration-200 text-sm">
                        Add to Cart
                      </button>
                    </form>
                  <?php else: ?>
                    <a href="/zenithco/public/index.php?page=user_login" class="block w-full text-center bg-primary text-pure font-semibold py-2.5 rounded-lg hover:bg-primary_dark transition-colors duration-200 text-sm">
                      Login to Add to Cart
                    </a>
                  <?php endif; ?>
                  
                  <a href="/zenithco/public/index.php?page=product_detail&id=<?= $product['id'] ?>" class="block w-full text-center border border-silver text-charcoal font-medium py-2.5 rounded-lg hover:border-primary hover:text-primary transition-colors duration-200 text-sm">
                    View Details
                  </a>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="col-span-full text-center py-16">
            <div class="max-w-md mx-auto">
              <div class="w-24 h-24 bg-ghost rounded-full flex items-center justify-center mx-auto mb-6">
                <svg class="w-12 h-12 text-steel" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                </svg>
              </div>
              <h3 class="text-xl font-semibold text-charcoal mb-2">No Products Found</h3>
              <p class="text-storm">Please check back later for new arrivals</p>
            </div>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <!-- About Section -->
  <section class="py-20 bg-ghost">
    <div class="max-w-7xl mx-auto px-6">
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div>
          <img src="/zenithco/public/images/craftsmanship.jpg" alt="Our Craftsmanship" 
               class="w-full h-80 object-cover rounded-lg">
        </div>
        
        <div class="space-y-6">
          <h2 class="text-4xl font-display text-charcoal">Our Story</h2>
          <div class="space-y-4 text-storm leading-relaxed">
            <p>
              For over three decades, we have been dedicated to creating exceptional jewelry 
              that combines traditional craftsmanship with contemporary design.
            </p>
            <p>
              Our master artisans use only the finest materials and time-honored techniques 
              to create pieces that will be treasured for generations.
            </p>
            <p>
              Every piece in our collection tells a story of passion, precision, and 
              unwavering commitment to excellence.
            </p>
          </div>
          
          <div class="grid grid-cols-2 gap-6 pt-4">
            <div class="text-center p-4 bg-pure rounded-lg border border-silver">
              <p class="text-2xl font-bold text-primary">37+</p>
              <p class="text-sm text-storm">Years of Excellence</p>
            </div>
            <div class="text-center p-4 bg-pure rounded-lg border border-silver">
              <p class="text-2xl font-bold text-primary">100%</p>
              <p class="text-sm text-storm">Handcrafted</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Services Section -->
  <section class="py-20 bg-pure">
    <div class="max-w-7xl mx-auto px-6">
      <div class="text-center mb-16">
        <h2 class="text-4xl font-display text-charcoal mb-4">Our Services</h2>
        <p class="text-xl text-storm max-w-2xl mx-auto">
          We offer comprehensive jewelry services to meet all your needs
        </p>
      </div>
      
      <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div class="text-center p-8 border border-silver rounded-lg hover:border-primary transition-colors duration-200">
          <div class="w-16 h-16 bg-ghost rounded-lg flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"></path>
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-charcoal mb-3">Custom Design</h3>
          <p class="text-storm">Create unique pieces tailored to your vision and preferences</p>
        </div>
        
        <div class="text-center p-8 border border-silver rounded-lg hover:border-primary transition-colors duration-200">
          <div class="w-16 h-16 bg-ghost rounded-lg flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path>
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-charcoal mb-3">Repair & Maintenance</h3>
          <p class="text-storm">Professional repair and maintenance services for all jewelry types</p>
        </div>
        
        <div class="text-center p-8 border border-silver rounded-lg hover:border-primary transition-colors duration-200">
          <div class="w-16 h-16 bg-ghost rounded-lg flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-charcoal mb-3">Lifetime Warranty</h3>
          <p class="text-storm">Comprehensive warranty coverage for all our jewelry pieces</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Contact Form Section -->
  <section id="contact" class="py-20 bg-ghost">
    <div class="max-w-4xl mx-auto px-6">
      <div class="text-center mb-12">
        <h2 class="text-4xl font-display text-charcoal mb-4">Get in Touch</h2>
        <p class="text-xl text-storm">
          Have questions about our products or services? We'd love to hear from you.
        </p>
      </div>

      <form action="#" method="POST" class="bg-pure p-8 rounded-lg border border-silver">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <label for="name" class="block text-sm font-medium text-charcoal mb-2">Full Name</label>
            <input type="text" id="name" name="name" required
                   class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary">
          </div>
          <div>
            <label for="email" class="block text-sm font-medium text-charcoal mb-2">Email Address</label>
            <input type="email" id="email" name="email" required
                   class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary">
          </div>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <label for="phone" class="block text-sm font-medium text-charcoal mb-2">Phone Number</label>
            <input type="tel" id="phone" name="phone"
                   class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary">
          </div>
          <div>
            <label for="subject" class="block text-sm font-medium text-charcoal mb-2">Subject</label>
            <select id="subject" name="subject" class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary">
              <option value="">Select a subject</option>
              <option value="general">General Inquiry</option>
              <option value="custom">Custom Design</option>
              <option value="repair">Repair Service</option>
              <option value="warranty">Warranty Claim</option>
            </select>
          </div>
        </div>
        
        <div class="mb-6">
          <label for="message" class="block text-sm font-medium text-charcoal mb-2">Message</label>
          <textarea id="message" name="message" rows="5" required
                    class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary resize-none"
                    placeholder="Please describe your inquiry or requirements..."></textarea>
        </div>
        
        <div class="text-center">
          <button type="submit"
                  class="bg-primary text-pure font-semibold py-4 px-8 rounded-lg hover:bg-primary_dark transition-colors duration-200">
            Send Message
          </button>
        </div>
      </form>
    </div>
  </section>

  <!-- Newsletter Section -->
  <section class="py-16 bg-pure border-t border-silver">
    <div class="max-w-4xl mx-auto text-center px-6">
      <h2 class="text-3xl font-display text-charcoal mb-4">Stay Updated</h2>
      <p class="text-lg text-storm mb-8">
        Subscribe to our newsletter for the latest collections and exclusive offers
      </p>
      
      <form class="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
        <input type="email" placeholder="Enter your email address" 
               class="flex-1 px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary">
        <button type="submit" class="bg-primary text-pure font-semibold px-8 py-3 rounded-lg hover:bg-primary_dark transition-colors duration-200">
          Subscribe
        </button>
      </form>
    </div>
  </section>

</main>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>