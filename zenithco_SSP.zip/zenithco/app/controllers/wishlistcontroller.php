<?php
require_once __DIR__ . '/../models/wishlist.php';
require_once __DIR__ . '/../models/user.php';
require_once __DIR__ . '/../models/product.php';


if (session_status() === PHP_SESSION_NONE) session_start();

function showWishlist() {
    $user_id = $_SESSION['user_id'] ?? null;
    if (!$user_id) {
        header("Location: /zenithco/public/index.php?page=user_login");
        exit;
    }

    $products = getWishlistItems($user_id);
    include __DIR__ . '/../views/customer/user_wishlist.php';
}

function handleAddToWishlist() {
    $user_id = $_SESSION['user_id'] ?? null;
    $product_id = $_POST['product_id'] ?? null;

    if (!$user_id || !$product_id) {
        header("Location: /zenithco/public/index.php?page=user_login");
        exit;
    }

    addToWishlist($user_id, $product_id);
    header("Location: /zenithco/public/index.php?page=user_wishlist");
    exit;
}

function handleRemoveFromWishlist() {
    $user_id = $_SESSION['user_id'] ?? null;
    $product_id = $_GET['product_id'] ?? null;

    if ($user_id && $product_id) {
        removeFromWishlist($user_id, $product_id);
    }

    header("Location: /zenithco/public/index.php?page=user_wishlist");
    exit;
}





function showAdminWishlist() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (!isset($_SESSION['admin_logged_in'])) {
        header("Location: /zenithco/public/index.php?page=admin_login");
        exit();
    }

    $wishlistItems = getAdminWishlistItems();
    include __DIR__ . '/../views/admin/wishlist.php';
}
