  <footer class="mt-12 border-t border-silver bg-white">
    <div class="max-w-7xl mx-auto px-4 py-6 text-center text-sm text-storm">
      <p>&copy; <?= date('Y') ?> Zenith & Co. All rights reserved.</p>
    </div>
  </footer>

</body>
</html>
