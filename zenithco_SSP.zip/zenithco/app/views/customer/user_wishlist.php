<?php
include __DIR__ . '/../layout/userheader.php';
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: /zenithco/public/index.php?page=user_login");
    exit;
}
?>

<main class="pt-24 pb-20 bg-ghost min-h-screen">
  <!-- Breadcrumb -->
  <section class="py-6 bg-pure border-b border-silver">
    <div class="max-w-7xl mx-auto px-6">
      <nav class="flex items-center space-x-2 text-sm">
        <a href="/zenithco/public/index.php?page=landing" class="text-steel hover:text-primary transition-colors">Home</a>
        <svg class="w-4 h-4 text-silver" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
        </svg>
        <span class="text-charcoal font-medium">My Wishlist</span>
      </nav>
    </div>
  </section>

  <div class="max-w-6xl mx-auto px-6 py-12">
    <!-- Header -->
    <div class="flex items-center justify-between mb-8">
      <div>
        <h1 class="text-4xl font-display text-charcoal mb-2">My Wishlist</h1>
        <p class="text-storm">
          <?php 
          $item_count = !empty($products) ? count($products) : 0;
          echo $item_count . ' ' . ($item_count === 1 ? 'item' : 'items') . ' saved for later';
          ?>
        </p>
      </div>
      
      <?php if (!empty($products)): ?>
        <a href="/zenithco/public/index.php?page=user_products"
           class="inline-flex items-center px-6 py-3 border-2 border-silver text-charcoal font-medium rounded-xl hover:border-primary hover:text-primary transition-colors duration-200">
          <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
          </svg>
          Add More Items
        </a>
      <?php endif; ?>
    </div>

    <?php if (!empty($products)): ?>
      <!-- Wishlist Items Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        <?php foreach ($products as $product): ?>
          <div class="group bg-pure border border-silver rounded-2xl shadow-soft overflow-hidden hover:shadow-medium transition-all duration-300 transform hover:-translate-y-1">
            
            <!-- Product Image -->
            <div class="relative">
              <a href="/zenithco/public/index.php?page=product_detail&id=<?= $product['id'] ?>">
                <div class="aspect-square bg-ghost overflow-hidden">
                  <img src="<?= htmlspecialchars($product['image']) ?>" 
                       alt="<?= htmlspecialchars($product['name']) ?>"
                       class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
                </div>
              </a>
              
              <!-- Remove from Wishlist Button -->
              <div class="absolute top-3 right-3">
                <a href="/zenithco/public/index.php?page=remove_wishlist&product_id=<?= $product['id'] ?>"
                   class="w-10 h-10 bg-pure/90 backdrop-blur-sm border border-silver/50 rounded-full flex items-center justify-center text-steel hover:text-error hover:bg-error/5 hover:border-error/30 transition-all duration-200"
                   title="Remove from wishlist">
                  <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                  </svg>
                </a>
              </div>
            </div>
            
            <!-- Product Details -->
            <div class="p-6 space-y-4">
              <div>
                <h3 class="text-lg font-serif text-charcoal group-hover:text-primary transition-colors duration-200 line-clamp-2">
                  <a href="/zenithco/public/index.php?page=product_detail&id=<?= $product['id'] ?>">
                    <?= htmlspecialchars($product['name']) ?>
                  </a>
                </h3>
                <p class="text-sm text-storm mt-2 line-clamp-3">
                  <?= htmlspecialchars(substr($product['description'], 0, 100)) ?>...
                </p>
              </div>
              
              <div class="pt-2">
                <p class="text-2xl font-semibold text-primary">LKR <?= number_format($product['price'], 2) ?></p>
              </div>
              
              <!-- Action Buttons -->
              <div class="space-y-3 pt-4">
                <form method="POST" action="/zenithco/public/index.php" class="w-full">
                  <input type="hidden" name="action" value="add_to_cart">
                  <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                  <input type="hidden" name="quantity" value="1">
                  <button type="submit" 
                          class="w-full bg-primary text-pure font-semibold py-3 rounded-xl hover:bg-primary_dark transition-colors duration-200 shadow-soft hover:shadow-primary">
                    <span class="flex items-center justify-center">
                      <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13l-1.5 6h13l-1.5-6M10 21a1 1 0 100-2 1 1 0 000 2zm8 0a1 1 0 100-2 1 1 0 000 2z"></path>
                      </svg>
                      Add to Cart
                    </span>
                  </button>
                </form>
                
                <a href="/zenithco/public/index.php?page=product_detail&id=<?= $product['id'] ?>"
                   class="block w-full text-center border-2 border-silver text-charcoal font-medium py-3 rounded-xl hover:border-primary hover:text-primary transition-colors duration-200">
                  View Details
                </a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      
      <!-- Bulk Actions -->
      <div class="mt-12 bg-pure border border-silver rounded-2xl p-8 shadow-soft">
        <div class="text-center">
          <h2 class="text-2xl font-serif text-charcoal mb-4">Quick Actions</h2>
          <div class="flex flex-col sm:flex-row gap-4 justify-center">
            <form method="POST" action="/zenithco/public/index.php" class="inline">
              <input type="hidden" name="action" value="add_all_to_cart">
              <button type="submit"
                      class="inline-flex items-center px-8 py-4 bg-primary text-pure font-semibold rounded-xl hover:bg-primary_dark transition-colors duration-200 shadow-soft hover:shadow-primary">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13l-1.5 6h13l-1.5-6M10 21a1 1 0 100-2 1 1 0 000 2zm8 0a1 1 0 100-2 1 1 0 000 2z"></path>
                </svg>
                Add All to Cart
              </button>
            </form>
            
            <a href="/zenithco/public/index.php?page=clear_wishlist"
               onclick="return confirm('Are you sure you want to clear your entire wishlist?')"
               class="inline-flex items-center px-8 py-4 border-2 border-error/30 text-error font-medium rounded-xl hover:border-error hover:bg-error/5 transition-colors duration-200">
              <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
              </svg>
              Clear Wishlist
            </a>
          </div>
        </div>
      </div>
      
    <?php else: ?>
      <!-- Empty Wishlist State -->
      <div class="text-center py-20">
        <div class="max-w-md mx-auto">
          <div class="w-32 h-32 bg-ghost rounded-full flex items-center justify-center mx-auto mb-8">
            <svg class="w-16 h-16 text-steel" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
            </svg>
          </div>
          <h2 class="text-3xl font-display text-charcoal mb-4">Your wishlist is empty</h2>
          <p class="text-storm text-lg mb-8 leading-relaxed">
            Save your favorite jewelry pieces to your wishlist so you can easily find them later. 
            Start browsing our beautiful collection now.
          </p>
          <a href="/zenithco/public/index.php?page=user_products"
             class="inline-flex items-center px-8 py-4 bg-primary text-pure font-semibold rounded-xl hover:bg-primary_dark transition-colors duration-200 shadow-soft hover:shadow-primary">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
            </svg>
            Discover Products
          </a>
        </div>
      </div>
    <?php endif; ?>
  </div>
</main>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>