<?php
if (session_status() === PHP_SESSION_NONE) session_start();
include __DIR__ . '/../layout/userheader.php';

$cartItems = $cartItems ?? [];
$cartTotal = $cartTotal ?? 0;
$cartCount = $cartCount ?? 0;
?>

<main class="bg-pure pt-32 pb-16 px-4 sm:px-8 min-h-screen animate-fade-in">
  <div class="max-w-6xl mx-auto">

    <?php if (isset($_SESSION['success'])): ?>
      <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
        <?= htmlspecialchars($_SESSION['success']) ?>
        <?php unset($_SESSION['success']); ?>
      </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
      <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
        <?= htmlspecialchars($_SESSION['error']) ?>
        <?php unset($_SESSION['error']); ?>
      </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <!-- Billing Form -->
      <div class="lg:col-span-2">
        <form method="POST" action="/zenithco/public/index.php?page=process_order" class="bg-white border border-silver p-8 rounded-xl shadow-md space-y-6">

          <!-- Contact Information -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label for="name" class="block text-sm font-medium text-charcoal mb-1">Full Name</label>
              <input type="text" id="name" name="name" required value="<?= htmlspecialchars($_SESSION['register_name'] ?? '') ?>"
                     class="w-full px-4 py-3 border border-silver rounded-lg focus:ring-2 focus:ring-primary">
            </div>
            <div>
              <label for="email" class="block text-sm font-medium text-charcoal mb-1">Email Address</label>
              <input type="email" id="email" name="email" required value="<?= htmlspecialchars($_SESSION['user_email'] ?? '') ?>"
                     class="w-full px-4 py-3 border border-silver rounded-lg focus:ring-2 focus:ring-primary">
            </div>
            <div class="md:col-span-2">
              <label for="phone" class="block text-sm font-medium text-charcoal mb-1">Phone Number</label>
              <input type="tel" id="phone" name="phone" required placeholder="+94 77 123 4567"
                     class="w-full px-4 py-3 border border-silver rounded-lg focus:ring-2 focus:ring-primary">
            </div>
          </div>

          <!-- Address -->
          <div>
            <label for="address" class="block text-sm font-medium text-charcoal mb-1">Shipping Address</label>
            <input type="text" id="address" name="address" required
                   class="w-full px-4 py-3 border border-silver rounded-lg focus:ring-2 focus:ring-primary">
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label for="city" class="block text-sm font-medium text-charcoal mb-1">City</label>
              <input type="text" id="city" name="city" required
                     class="w-full px-4 py-3 border border-silver rounded-lg focus:ring-2 focus:ring-primary">
            </div>
            <div>
              <label for="zip" class="block text-sm font-medium text-charcoal mb-1">Postal / ZIP Code</label>
              <input type="text" id="zip" name="zip" required
                     class="w-full px-4 py-3 border border-silver rounded-lg focus:ring-2 focus:ring-primary">
            </div>
          </div>

          <!-- Payment Method -->
          <div>
            <label for="payment" class="block text-sm font-medium text-charcoal mb-1">Payment Method</label>
            <select id="payment" name="payment" required
                    class="w-full px-4 py-3 border border-silver rounded-lg focus:ring-2 focus:ring-primary">
              <option value="">Select a method</option>
              <option value="card">Credit / Debit Card</option>
              <option value="cod">Cash on Delivery</option>
              <option value="paypal">PayPal</option>
              <option value="bank_transfer">Bank Transfer</option>
            </select>
          </div>

          <!-- Card Details -->
          <div id="card-details" class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6 hidden">
            <div>
              <label for="card_number" class="block text-sm font-medium text-charcoal mb-1">Card Number</label>
              <input type="text" name="card_number" id="card_number" placeholder="1234 5678 9012 3456"
                     class="w-full px-4 py-3 border border-silver rounded-lg focus:ring-2 focus:ring-primary">
            </div>
            <div>
              <label for="expiry_date" class="block text-sm font-medium text-charcoal mb-1">Expiry Date</label>
              <input type="text" name="expiry_date" id="expiry_date" placeholder="MM/YY"
                     class="w-full px-4 py-3 border border-silver rounded-lg focus:ring-2 focus:ring-primary">
            </div>
            <div>
              <label for="cvv" class="block text-sm font-medium text-charcoal mb-1">CVV</label>
              <input type="text" name="cvv" id="cvv" placeholder="123"
                     class="w-full px-4 py-3 border border-silver rounded-lg focus:ring-2 focus:ring-primary">
            </div>
            <div>
              <label for="card_name" class="block text-sm font-medium text-charcoal mb-1">Name on Card</label>
              <input type="text" name="card_name" id="card_name" placeholder="John Doe"
                     class="w-full px-4 py-3 border border-silver rounded-lg focus:ring-2 focus:ring-primary">
            </div>
          </div>

          <!-- Terms and Submit -->
          <div class="pt-6 border-t border-silver space-y-6">
            <div class="flex items-start">
              <input type="checkbox" id="terms" name="terms" required
                     class="w-4 h-4 text-primary border-silver rounded focus:ring-primary mt-1">
              <label for="terms" class="ml-3 text-sm text-charcoal">
                I agree to the <a href="#" class="text-primary underline">Terms and Conditions</a> and <a href="#" class="text-primary underline">Privacy Policy</a>
              </label>
            </div>
            <button type="submit"
                    class="w-full bg-primary text-white px-6 py-4 rounded-lg font-semibold hover:bg-primary_dark transition">
              Confirm & Place Order
            </button>
          </div>
        </form>
      </div>

      <!-- Order Summary -->
      <div class="lg:col-span-1">
        <div class="bg-white border border-silver rounded-xl shadow-md p-6 sticky top-24">
          <h2 class="text-xl font-semibold text-charcoal mb-6">Order Summary</h2>
          <?php if (!empty($cartItems)): ?>
            <div class="space-y-4 mb-6 max-h-64 overflow-y-auto">
              <?php foreach ($cartItems as $item): ?>
                <div class="flex items-center space-x-3">
                  <img src="<?= htmlspecialchars($item['image'] ?? '/zenithco/public/images/placeholder.jpg') ?>" alt="<?= htmlspecialchars($item['name']) ?>" class="w-12 h-12 object-cover rounded-lg">
                  <div class="flex-1">
                    <p class="text-sm font-medium"><?= htmlspecialchars($item['name']) ?></p>
                    <p class="text-xs text-storm">Qty: <?= $item['quantity'] ?></p>
                  </div>
                  <p class="text-sm font-semibold">LKR <?= number_format($item['subtotal'], 2) ?></p>
                </div>
              <?php endforeach; ?>
            </div>
            <div class="border-t border-silver pt-4 space-y-2">
              <div class="flex justify-between text-storm">
                <span>Items (<?= $cartCount ?>)</span>
                <span>LKR <?= number_format($cartTotal, 2) ?></span>
              </div>
              <div class="flex justify-between text-storm">
                <span>Shipping</span><span>Free</span>
              </div>
              <div class="flex justify-between font-bold">
                <span>Total</span><span class="text-primary">LKR <?= number_format($cartTotal, 2) ?></span>
              </div>
            </div>
          <?php else: ?>
            <p>Your cart is empty.</p>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</main>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const paymentSelect = document.getElementById('payment');
  const cardDetails = document.getElementById('card-details');
  paymentSelect.addEventListener('change', () => {
    const showCard = paymentSelect.value === 'card';
    cardDetails.classList.toggle('hidden', !showCard);
    ['card_number', 'expiry_date', 'cvv', 'card_name'].forEach(id => {
      const field = document.getElementById(id);
      if (field) field.required = showCard;
    });
  });
});
</script>
