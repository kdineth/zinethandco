<?php
require_once __DIR__ . '/../../config/database.php';

/**
 * Get cart items for a user
 * @param int $userId User ID
 * @return array Cart items
 */
function getCartItems($userId) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            SELECT c.*, p.name, p.price, p.image
            FROM cart c 
            JOIN products p ON c.product_id = p.id 
            WHERE c.user_id = ?
            ORDER BY c.created_at DESC
        ");
        $stmt->execute([$userId]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        error_log("[CART_MODEL] Found " . count($items) . " cart items for user: $userId");
        return $items;
        
    } catch (PDOException $e) {
        error_log("[CART_MODEL] Database error in getCartItems: " . $e->getMessage());
        return [];
    }
}

/**
 * Clear cart for a user
 * @param int $userId User ID
 * @return bool Success status
 */
function clearCart($userId) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("DELETE FROM cart WHERE user_id = ?");
        $result = $stmt->execute([$userId]);
        
        if ($result) {
            error_log("[CART_MODEL] Cart cleared for user: $userId");
        } else {
            error_log("[CART_MODEL] Failed to clear cart for user: $userId");
        }
        
        return $result;
        
    } catch (PDOException $e) {
        error_log("[CART_MODEL] Database error in clearCart: " . $e->getMessage());
        return false;
    }
}

/**
 * Add item to cart
 * @param int $userId User ID
 * @param int $productId Product ID
 * @param int $quantity Quantity
 * @return bool Success status
 */
function addToCart($userId, $productId, $quantity = 1) {
    global $pdo;
    
    try {
        // Check if item already exists in cart
        $stmt = $pdo->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$userId, $productId]);
        $existingItem = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existingItem) {
            // Update existing item
            $newQuantity = $existingItem['quantity'] + $quantity;
            $stmt = $pdo->prepare("UPDATE cart SET quantity = ?, updated_at = NOW() WHERE id = ?");
            $result = $stmt->execute([$newQuantity, $existingItem['id']]);
        } else {
            // Add new item
            $stmt = $pdo->prepare("INSERT INTO cart (user_id, product_id, quantity, created_at) VALUES (?, ?, ?, NOW())");
            $result = $stmt->execute([$userId, $productId, $quantity]);
        }
        
        if ($result) {
            error_log("[CART_MODEL] Added/Updated cart item for user: $userId, product: $productId");
        }
        
        return $result;
        
    } catch (PDOException $e) {
        error_log("[CART_MODEL] Database error in addToCart: " . $e->getMessage());
        return false;
    }
}

/**
 * Update cart item quantity
 * @param int $userId User ID
 * @param int $cartId Cart item ID
 * @param int $quantity New quantity
 * @return bool Success status
 */
function updateCartQuantity($userId, $cartId, $quantity) {
    global $pdo;
    
    try {
        if ($quantity <= 0) {
            // Remove item if quantity is 0 or less
            return removeFromCart($userId, $cartId);
        }
        
        $stmt = $pdo->prepare("UPDATE cart SET quantity = ?, updated_at = NOW() WHERE id = ? AND user_id = ?");
        $result = $stmt->execute([$quantity, $cartId, $userId]);
        
        if ($result) {
            error_log("[CART_MODEL] Updated cart quantity for user: $userId, cart ID: $cartId");
        }
        
        return $result;
        
    } catch (PDOException $e) {
        error_log("[CART_MODEL] Database error in updateCartQuantity: " . $e->getMessage());
        return false;
    }
}

/**
 * Remove item from cart
 * @param int $userId User ID
 * @param int $cartId Cart item ID
 * @return bool Success status
 */
function removeFromCart($userId, $cartId) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
        $result = $stmt->execute([$cartId, $userId]);
        
        if ($result) {
            error_log("[CART_MODEL] Removed cart item for user: $userId, cart ID: $cartId");
        }
        
        return $result;
        
    } catch (PDOException $e) {
        error_log("[CART_MODEL] Database error in removeFromCart: " . $e->getMessage());
        return false;
    }
}

/**
 * Get cart total for a user
 * @param int $userId User ID
 * @return float Cart total
 */
function getCartTotal($userId) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            SELECT SUM(c.quantity * p.price) as total
            FROM cart c 
            JOIN products p ON c.product_id = p.id 
            WHERE c.user_id = ?
        ");
        $stmt->execute([$userId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result['total'] ?? 0;
        
    } catch (PDOException $e) {
        error_log("[CART_MODEL] Database error in getCartTotal: " . $e->getMessage());
        return 0;
    }
}

/**
 * Get cart item count for a user
 * @param int $userId User ID
 * @return int Number of items in cart
 */
function getCartCount($userId) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT SUM(quantity) as count FROM cart WHERE user_id = ?");
        $stmt->execute([$userId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result['count'] ?? 0;
        
    } catch (PDOException $e) {
        error_log("[CART_MODEL] Database error in getCartCount: " . $e->getMessage());
        return 0;
    }
}

/**
 * Check if product exists in user's cart
 * @param int $userId User ID
 * @param int $productId Product ID
 * @return bool True if product is in cart
 */
function isInCart($userId, $productId) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT id FROM cart WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$userId, $productId]);
        
        return $stmt->fetch() !== false;
        
    } catch (PDOException $e) {
        error_log("[CART_MODEL] Database error in isInCart: " . $e->getMessage());
        return false;
    }
}
?>