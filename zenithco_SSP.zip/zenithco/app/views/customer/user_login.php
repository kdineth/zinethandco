<?php include __DIR__ . '/../layout/userheader.php'; ?>

<main class="min-h-screen bg-pure flex items-center justify-center py-24 px-4">
  <div class="w-full max-w-md bg-white border border-silver shadow-lg rounded-xl p-8">
    
    <!-- Header -->
    <div class="text-center mb-8">
      <div class="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
        <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
        </svg>
      </div>
      <h2 class="text-2xl font-display text-charcoal mb-2">Welcome Back</h2>
      <p class="text-storm">Sign in to your Zenith & Co account</p>
    </div>

    <!-- Error Messages -->
    <?php if (isset($_SESSION['error'])): ?>
      <div class="bg-error/10 border border-error/30 text-error px-4 py-3 rounded-lg mb-6">
        <div class="flex items-center">
          <svg class="w-5 h-5 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
          </svg>
          <span><?= htmlspecialchars($_SESSION['error']); ?></span>
        </div>
      </div>
      <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <!-- Success Messages -->
    <?php if (isset($_SESSION['success'])): ?>
      <div class="bg-success/10 border border-success/30 text-success px-4 py-3 rounded-lg mb-6">
        <div class="flex items-center">
          <svg class="w-5 h-5 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
          </svg>
          <span><?= htmlspecialchars($_SESSION['success']); ?></span>
        </div>
      </div>
      <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <!-- Login Form -->
    <form method="POST" action="/zenithco/public/index.php?page=user_login" class="space-y-6">
      
      <!-- Email Field -->
      <div>
        <label for="email" class="block text-sm font-medium text-charcoal mb-2">Email Address</label>
        <div class="relative">
          <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg class="h-5 w-5 text-steel" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
            </svg>
          </div>
          <input type="email" 
                 name="email" 
                 id="email" 
                 required
                 value="<?= isset($_SESSION['login_email']) ? htmlspecialchars($_SESSION['login_email']) : '' ?>"
                 class="w-full pl-10 pr-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-colors duration-200"
                 placeholder="your@email.com">
        </div>
      </div>

      <!-- Password Field -->
      <div>
        <label for="password" class="block text-sm font-medium text-charcoal mb-2">Password</label>
        <div class="relative">
          <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg class="h-5 w-5 text-steel" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
            </svg>
          </div>
          <input type="password" 
                 name="password" 
                 id="password" 
                 required
                 class="w-full pl-10 pr-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-colors duration-200"
                 placeholder="Enter your password">
        </div>
      </div>

      <!-- Remember Me & Forgot Password -->
      <div class="flex items-center justify-between">
        <div class="flex items-center">
          <input type="checkbox" 
                 name="remember_me" 
                 id="remember_me" 
                 class="h-4 w-4 text-primary focus:ring-primary border-silver rounded">
          <label for="remember_me" class="ml-2 text-sm text-charcoal">Remember me</label>
        </div>
        <a href="/zenithco/public/index.php?page=forgot_password" 
           class="text-sm text-primary hover:text-primary_dark transition-colors duration-200">
          Forgot password?
        </a>
      </div>

      <!-- Login Button -->
      <button type="submit" 
              name="login"
              class="w-full bg-primary text-pure font-semibold py-3 rounded-lg hover:bg-primary_dark transition-colors duration-200 shadow-soft hover:shadow-primary">
        Sign In
      </button>

      <!-- Divider -->
      <div class="relative my-6">
        <div class="absolute inset-0 flex items-center">
          <div class="w-full border-t border-silver"></div>
        </div>
        <div class="relative flex justify-center text-sm">
          <span class="px-3 bg-white text-steel">or</span>
        </div>
      </div>

      <!-- Alternative Sign In Options -->
      <div class="space-y-3">
        <!-- Google Sign In -->
        <button type="button" 
                class="w-full flex items-center justify-center px-4 py-3 border border-silver rounded-lg text-charcoal font-medium hover:bg-ghost hover:border-steel transition-colors duration-200">
          <svg class="w-5 h-5 mr-3" viewBox="0 0 24 24">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
          </svg>
          Continue with Google
        </button>

        <!-- Guest Access -->
        <a href="/zenithco/public/index.php?page=landing" 
           class="w-full flex items-center justify-center px-4 py-3 border border-silver rounded-lg text-charcoal font-medium hover:bg-ghost hover:border-steel transition-colors duration-200">
          <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
          </svg>
          Continue as Guest
        </a>
      </div>

      <!-- Register Link -->
      <div class="text-center pt-4">
        <p class="text-sm text-storm">
          Don't have an account?
          <a href="/zenithco/public/index.php?page=user_register" 
             class="text-primary hover:text-primary_dark font-medium transition-colors duration-200">
            Create account
          </a>
        </p>
      </div>
    </form>

    <!-- Customer Support -->
    <div class="mt-8 pt-6 border-t border-silver">
      <div class="text-center">
        <p class="text-xs text-steel mb-3">Need help signing in?</p>
        <div class="flex flex-col sm:flex-row justify-center items-center space-y-2 sm:space-y-0 sm:space-x-4 text-xs">
          <a href="/zenithco/public/index.php?page=contact" 
             class="flex items-center text-primary hover:text-primary_dark transition-colors duration-200">
            <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
            </svg>
            Contact Support
          </a>
          <span class="hidden sm:block text-silver">•</span>
          <a href="tel:+94771234567" 
             class="flex items-center text-primary hover:text-primary_dark transition-colors duration-200">
            <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
            </svg>
            +94 77 123 4567
          </a>
        </div>
      </div>
    </div>

    <!-- Security Notice -->
    <div class="mt-6 p-3 bg-ghost rounded-lg">
      <div class="flex items-start">
        <svg class="w-4 h-4 text-primary mt-0.5 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
        </svg>
        <div>
          <p class="text-xs text-charcoal font-medium">Secure Login</p>
          <p class="text-xs text-steel">Your information is protected with industry-standard encryption.</p>
        </div>
      </div>
    </div>
  </div>
</main>

<?php 
// Clear login email from session after display
if (isset($_SESSION['login_email'])) unset($_SESSION['login_email']); 
?>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>