<?php include __DIR__ . '/../layout/layout.php'; ?>

<div class="min-h-screen bg-ivory px-4 py-10">
    <div class="max-w-7xl mx-auto">
        <div class="flex justify-between items-center mb-8">
            <h2 class="text-3xl font-display text-navy">Update Products</h2>
            <a href="/zenithco/public/index.php?page=admin_dashboard"
               class="bg-navy text-white px-4 py-2 rounded hover:bg-essence transition">
               ← Back to Dashboard
            </a>
        </div>

        <?php if (empty($products)): ?>
            <p class="text-essence/70 text-sm">No products found.</p>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white text-sm border border-ether rounded-lg overflow-hidden">
                    <thead class="bg-mist text-essence uppercase text-xs">
                        <tr>
                            <th class="px-4 py-3 text-left">Image</th>
                            <th class="px-4 py-3 text-left">Name</th>
                            <th class="px-4 py-3 text-left">Price</th>
                            <th class="px-4 py-3 text-left">Stock</th>
                            <th class="px-4 py-3 text-left">Update</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                            <tr class="border-t border-ether">
                                <td class="px-4 py-3"><img src="<?= $product['image'] ?>" class="h-16 w-16 object-cover rounded"></td>
                                <td class="px-4 py-3"><?= htmlspecialchars($product['name']) ?></td>
                                <td class="px-4 py-3">Rs. <?= number_format($product['price'], 2) ?></td>
                                <td class="px-4 py-3"><?= (int)$product['stock'] ?></td>
                                <td class="px-4 py-3">
                                    <a href="/zenithco/public/index.php?page=edit_product&id=<?= $product['id'] ?>"
                                       class="inline-block bg-navy text-white px-3 py-1 rounded hover:bg-essence transition text-xs">
                                       Update
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
