<?php
include __DIR__ . '/../layout/userheader.php';

if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: /zenithco/public/index.php?page=user_login");
    exit;
}

// Get order details from session or URL parameters
$order_number = $_SESSION['last_order_id'] ?? 'ZC' . time();
$order_total = $_SESSION['last_order_total'] ?? 0;
$customer_email = $_SESSION['customer_email'] ?? 'your email';
?>

<main class="min-h-screen pt-24 pb-20 bg-ghost">
  
  <!-- Success Animation Container -->
  <div class="max-w-4xl mx-auto px-6 py-12">
    
    <!-- Main Confirmation Card -->
    <div class="bg-pure rounded-3xl border border-silver shadow-large p-12 text-center animate-scale-in">
      
      <!-- Success Icon -->
      <div class="relative mb-8">
        <div class="w-24 h-24 mx-auto bg-success/10 rounded-full flex items-center justify-center animate-pulse-subtle">
          <div class="w-16 h-16 bg-success rounded-full flex items-center justify-center">
            <svg class="w-8 h-8 text-pure" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/>
            </svg>
          </div>
        </div>
        <!-- Decorative rings -->
        <div class="absolute inset-0 w-24 h-24 mx-auto border-2 border-success/20 rounded-full animate-ping"></div>
        <div class="absolute inset-2 w-20 h-20 mx-auto border border-success/30 rounded-full"></div>
      </div>

      <!-- Success Message -->
      <div class="mb-8">
        <h1 class="text-4xl lg:text-5xl font-display text-charcoal mb-4 animate-slide-up">
          Order Confirmed!
        </h1>
        <p class="text-xl text-storm leading-relaxed animate-fade-in">
          Thank you for choosing Zenith & Co. Your order has been successfully placed and is being prepared with care.
        </p>
      </div>

      <!-- Order Details -->
      <div class="bg-ghost rounded-2xl p-8 mb-8 animate-slide-up">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
          <div>
            <div class="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-3">
              <svg class="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v6a2 2 0 002 2h2m0-8v8m0-8h8m-8 0V3a2 2 0 012-2h4a2 2 0 012 2v2m-6 8h8a2 2 0 002-2V9a2 2 0 00-2-2h-8m0 0V3"></path>
              </svg>
            </div>
            <h3 class="text-sm font-semibold text-charcoal mb-1">Order Number</h3>
            <p class="text-lg font-mono text-primary">#<?= htmlspecialchars($order_number) ?></p>
          </div>
          
          <div>
            <div class="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-3">
              <svg class="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
              </svg>
            </div>
            <h3 class="text-sm font-semibold text-charcoal mb-1">Order Total</h3>
            <p class="text-lg font-semibold text-charcoal">LKR <?= number_format($order_total, 2) ?></p>
          </div>
          
          <div>
            <div class="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-3">
              <svg class="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
              </svg>
            </div>
            <h3 class="text-sm font-semibold text-charcoal mb-1">Confirmation Sent</h3>
            <p class="text-sm text-storm"><?= htmlspecialchars($customer_email) ?></p>
          </div>
        </div>
      </div>

      <!-- What Happens Next -->
      <div class="text-left mb-8 animate-slide-up">
        <h2 class="text-2xl font-serif text-charcoal mb-6 text-center">What happens next?</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          <div class="text-center">
            <div class="w-16 h-16 bg-primary text-pure rounded-2xl flex items-center justify-center mx-auto mb-4 font-bold text-xl">
              1
            </div>
            <h3 class="font-semibold text-charcoal mb-2">Order Processing</h3>
            <p class="text-sm text-storm">We'll carefully prepare and package your jewelry with our signature presentation.</p>
          </div>
          
          <div class="text-center">
            <div class="w-16 h-16 bg-primary text-pure rounded-2xl flex items-center justify-center mx-auto mb-4 font-bold text-xl">
              2
            </div>
            <h3 class="font-semibold text-charcoal mb-2">Quality Check</h3>
            <p class="text-sm text-storm">Each piece undergoes our rigorous quality inspection before shipping.</p>
          </div>
          
          <div class="text-center">
            <div class="w-16 h-16 bg-primary text-pure rounded-2xl flex items-center justify-center mx-auto mb-4 font-bold text-xl">
              3
            </div>
            <h3 class="font-semibold text-charcoal mb-2">Secure Shipping</h3>
            <p class="text-sm text-storm">Your order will be shipped with tracking and insurance for your peace of mind.</p>
          </div>
        </div>
      </div>

      <!-- Action Buttons -->
      <div class="flex flex-col sm:flex-row justify-center gap-4 mb-8 animate-fade-in">
        <a href="/zenithco/public/index.php?page=user_orders"
           class="inline-flex items-center justify-center px-8 py-4 bg-primary text-pure font-semibold rounded-xl hover:bg-primary_dark transition-colors duration-200 shadow-soft hover:shadow-primary">
          <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v6a2 2 0 002 2h2m0-8v8m0-8h8m-8 0V3a2 2 0 012-2h4a2 2 0 012 2v2m-6 8h8a2 2 0 002-2V9a2 2 0 00-2-2h-8m0 0V3"></path>
          </svg>
          Track Your Order
        </a>
        
        <a href="/zenithco/public/index.php?page=user_products"
           class="inline-flex items-center justify-center px-8 py-4 border-2 border-silver text-charcoal font-semibold rounded-xl hover:border-primary hover:text-primary transition-colors duration-200">
          <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13l-1.5 6h13l-1.5-6M10 21a1 1 0 100-2 1 1 0 000 2zm8 0a1 1 0 100-2 1 1 0 000 2z"></path>
          </svg>
          Continue Shopping
        </a>
      </div>

      <!-- Support Information -->
      <div class="border-t border-silver pt-8 animate-fade-in">
        <p class="text-sm text-storm mb-4">Need help with your order?</p>
        <div class="flex flex-col sm:flex-row justify-center items-center space-y-2 sm:space-y-0 sm:space-x-6 text-sm">
          <a href="/zenithco/public/index.php?page=contact" 
             class="flex items-center text-primary hover:text-primary_dark transition-colors">
            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
            </svg>
            Contact Support
          </a>
          <span class="hidden sm:block text-silver">•</span>
          <a href="tel:+94771234567" 
             class="flex items-center text-primary hover:text-primary_dark transition-colors">
            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
            </svg>
            +94 77 123 4567
          </a>
          <span class="hidden sm:block text-silver">•</span>
          <a href="mailto:support@zenithandco.com" 
             class="flex items-center text-primary hover:text-primary_dark transition-colors">
            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
            </svg>
            Email Us
          </a>
        </div>
      </div>
    </div>

    <!-- Additional Information Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
      
      <!-- Shipping Information -->
      <div class="bg-pure rounded-2xl border border-silver p-6 shadow-soft animate-slide-left">
        <div class="flex items-center mb-4">
          <div class="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mr-3">
            <svg class="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
            </svg>
          </div>
          <h3 class="text-lg font-semibold text-charcoal">Shipping & Delivery</h3>
        </div>
        <ul class="text-sm text-storm space-y-2">
          <li class="flex items-center">
            <svg class="w-4 h-4 mr-2 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
            Free worldwide shipping on all orders
          </li>
          <li class="flex items-center">
            <svg class="w-4 h-4 mr-2 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
            Estimated delivery: 5-7 business days
          </li>
          <li class="flex items-center">
            <svg class="w-4 h-4 mr-2 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
            Fully insured and trackable
          </li>
        </ul>
      </div>

      <!-- Customer Care -->
      <div class="bg-pure rounded-2xl border border-silver p-6 shadow-soft animate-slide-right">
        <div class="flex items-center mb-4">
          <div class="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mr-3">
            <svg class="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
            </svg>
          </div>
          <h3 class="text-lg font-semibold text-charcoal">Customer Care</h3>
        </div>
        <ul class="text-sm text-storm space-y-2">
          <li class="flex items-center">
            <svg class="w-4 h-4 mr-2 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
            30-day hassle-free returns
          </li>
          <li class="flex items-center">
            <svg class="w-4 h-4 mr-2 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
            Lifetime craftsmanship warranty
          </li>
          <li class="flex items-center">
            <svg class="w-4 h-4 mr-2 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
            24/7 customer support available
          </li>
        </ul>
      </div>
    </div>
  </div>
</main>

<?php 
// Clear order-related session data
unset($_SESSION['cart']);
unset($_SESSION['last_order_id']);
unset($_SESSION['last_order_total']);
unset($_SESSION['customer_email']);
?>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>