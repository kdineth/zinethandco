<?php
include __DIR__ . '/../layout/userheader.php';
?>

<main class="bg-pure pt-24">

  <!-- Hero Section -->
  <section class="py-20 bg-ghost">
    <div class="max-w-4xl mx-auto px-6 text-center">
      <h1 class="text-5xl font-display text-charcoal mb-6">Get in Touch</h1>
      <p class="text-xl text-storm leading-relaxed">
        We're here to help you find the perfect piece or answer any questions you may have. Reach out to our team of experts who are passionate about creating exceptional jewelry experiences.
      </p>
    </div>
  </section>

  <!-- Contact Information -->
  <section class="py-20 bg-pure">
    <div class="max-w-7xl mx-auto px-6">
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
        
        <!-- Visit Our Showroom -->
        <div class="text-center p-8 bg-ghost rounded-lg border border-silver">
          <div class="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-charcoal mb-4">Visit Our Showroom</h3>
          <div class="space-y-2 text-storm">
            <p class="font-medium">123 Heritage Boulevard</p>
            <p>Colombo 03, Sri Lanka</p>
            <p class="mt-4 text-sm">
              <strong>Opening Hours:</strong><br>
              Monday - Saturday: 9:00 AM - 7:00 PM<br>
              Sunday: 10:00 AM - 5:00 PM
            </p>
          </div>
        </div>

        <!-- Call Us -->
        <div class="text-center p-8 bg-ghost rounded-lg border border-silver">
          <div class="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-charcoal mb-4">Call Us</h3>
          <div class="space-y-2 text-storm">
            <p class="font-medium text-lg">+94 77 123 4567</p>
            <p class="text-sm">Main Sales & Customer Service</p>
            <p class="font-medium text-lg mt-4">+94 77 123 4568</p>
            <p class="text-sm">Custom Design Consultations</p>
            <p class="mt-4 text-sm">
              <strong>Available:</strong><br>
              Monday - Friday: 8:00 AM - 8:00 PM<br>
              Saturday - Sunday: 9:00 AM - 6:00 PM
            </p>
          </div>
        </div>

        <!-- Email Us -->
        <div class="text-center p-8 bg-ghost rounded-lg border border-silver">
          <div class="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-charcoal mb-4">Email Us</h3>
          <div class="space-y-2 text-storm">
            <p><a href="mailto:info@zenithandco.com" class="font-medium text-primary hover:text-primary_dark">info@zenithandco.com</a></p>
            <p class="text-sm">General Inquiries</p>
            <p><a href="mailto:custom@zenithandco.com" class="font-medium text-primary hover:text-primary_dark mt-4 block">custom@zenithandco.com</a></p>
            <p class="text-sm">Custom Design Services</p>
            <p><a href="mailto:support@zenithandco.com" class="font-medium text-primary hover:text-primary_dark mt-4 block">support@zenithandco.com</a></p>
            <p class="text-sm">Customer Support</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Contact Form -->
  <section class="py-20 bg-ghost">
    <div class="max-w-4xl mx-auto px-6">
      <div class="text-center mb-12">
        <h2 class="text-4xl font-display text-charcoal mb-6">Send Us a Message</h2>
        <p class="text-xl text-storm">
          Have a question or want to schedule a consultation? Fill out the form below and we'll get back to you within 24 hours.
        </p>
      </div>

      <form action="#" method="POST" class="bg-pure p-10 rounded-lg border border-silver shadow-soft">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <label for="first_name" class="block text-sm font-medium text-charcoal mb-2">First Name *</label>
            <input type="text" id="first_name" name="first_name" required
                   class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary">
          </div>
          <div>
            <label for="last_name" class="block text-sm font-medium text-charcoal mb-2">Last Name *</label>
            <input type="text" id="last_name" name="last_name" required
                   class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary">
          </div>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <label for="email" class="block text-sm font-medium text-charcoal mb-2">Email Address *</label>
            <input type="email" id="email" name="email" required
                   class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary">
          </div>
          <div>
            <label for="phone" class="block text-sm font-medium text-charcoal mb-2">Phone Number</label>
            <input type="tel" id="phone" name="phone"
                   class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary">
          </div>
        </div>

        <div class="mb-6">
          <label for="subject" class="block text-sm font-medium text-charcoal mb-2">Subject *</label>
          <select id="subject" name="subject" required class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary">
            <option value="">Please select a subject</option>
            <option value="general">General Inquiry</option>
            <option value="custom_design">Custom Design Consultation</option>
            <option value="existing_order">Existing Order Question</option>
            <option value="repair_service">Repair & Maintenance</option>
            <option value="warranty">Warranty Claim</option>
            <option value="appointment">Schedule Appointment</option>
            <option value="other">Other</option>
          </select>
        </div>

        <div class="mb-6">
          <label for="preferred_contact" class="block text-sm font-medium text-charcoal mb-2">Preferred Contact Method</label>
          <div class="flex flex-wrap gap-4 mt-2">
            <label class="flex items-center">
              <input type="radio" name="preferred_contact" value="email" class="text-primary focus:ring-primary">
              <span class="ml-2 text-sm text-charcoal">Email</span>
            </label>
            <label class="flex items-center">
              <input type="radio" name="preferred_contact" value="phone" class="text-primary focus:ring-primary">
              <span class="ml-2 text-sm text-charcoal">Phone</span>
            </label>
            <label class="flex items-center">
              <input type="radio" name="preferred_contact" value="no_preference" class="text-primary focus:ring-primary" checked>
              <span class="ml-2 text-sm text-charcoal">No Preference</span>
            </label>
          </div>
        </div>
        
        <div class="mb-8">
          <label for="message" class="block text-sm font-medium text-charcoal mb-2">Message *</label>
          <textarea id="message" name="message" rows="6" required
                    class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary resize-none"
                    placeholder="Please provide details about your inquiry, including any specific requirements or questions you may have..."></textarea>
        </div>
        
        <div class="flex items-center mb-6">
          <input type="checkbox" id="newsletter" name="newsletter" class="text-primary focus:ring-primary">
          <label for="newsletter" class="ml-2 text-sm text-charcoal">
            I would like to receive updates about new collections and exclusive offers
          </label>
        </div>
        
        <div class="text-center">
          <button type="submit"
                  class="bg-primary text-pure font-semibold py-4 px-10 rounded-lg hover:bg-primary_dark transition-colors duration-200 shadow-soft hover:shadow-primary">
            Send Message
          </button>
        </div>
      </form>
    </div>
  </section>

  <!-- Map Section -->
  <section class="py-20 bg-pure">
    <div class="max-w-7xl mx-auto px-6">
      <div class="text-center mb-12">
        <h2 class="text-4xl font-display text-charcoal mb-6">Find Us</h2>
        <p class="text-xl text-storm">
          Visit our beautiful showroom in the heart of Colombo to experience our collections in person
        </p>
      </div>
      
      <div class="bg-ghost rounded-lg p-8 border border-silver">
        <div class="aspect-video bg-silver rounded-lg flex items-center justify-center">
          <!-- Replace with actual Google Maps embed -->
          <div class="text-center">
            <svg class="w-16 h-16 text-steel mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
            </svg>
            <p class="text-storm">Interactive Map Coming Soon</p>
            <p class="text-sm text-steel mt-2">123 Heritage Boulevard, Colombo 03, Sri Lanka</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FAQ Section -->
  <section class="py-20 bg-ghost">
    <div class="max-w-4xl mx-auto px-6">
      <div class="text-center mb-12">
        <h2 class="text-4xl font-display text-charcoal mb-6">Frequently Asked Questions</h2>
        <p class="text-xl text-storm">
          Quick answers to common questions about our services and policies
        </p>
      </div>
      
      <div class="space-y-6">
        <div class="bg-pure p-6 rounded-lg border border-silver">
          <h3 class="text-lg font-semibold text-charcoal mb-3">Do you offer custom design services?</h3>
          <p class="text-storm">Yes, we specialize in custom jewelry design. Our team will work with you to create a unique piece that reflects your personal style and vision. Contact us to schedule a consultation.</p>
        </div>
        
        <div class="bg-pure p-6 rounded-lg border border-silver">
          <h3 class="text-lg font-semibold text-charcoal mb-3">What is your return policy?</h3>
          <p class="text-storm">We offer a 30-day return policy for unworn items in original condition. Custom-designed pieces are final sale. Please contact us within 30 days of purchase to initiate a return.</p>
        </div>
        
        <div class="bg-pure p-6 rounded-lg border border-silver">
          <h3 class="text-lg font-semibold text-charcoal mb-3">Do you provide certificates of authenticity?</h3>
          <p class="text-storm">Yes, all our jewelry pieces come with certificates of authenticity detailing the materials used, craftsmanship details, and care instructions.</p>
        </div>
        
        <div class="bg-pure p-6 rounded-lg border border-silver">
          <h3 class="text-lg font-semibold text-charcoal mb-3">How long does custom design take?</h3>
          <p class="text-storm">Custom design projects typically take 4-8 weeks depending on complexity. We'll provide a detailed timeline during your consultation and keep you updated throughout the process.</p>
        </div>
      </div>
    </div>
  </section>

</main>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>