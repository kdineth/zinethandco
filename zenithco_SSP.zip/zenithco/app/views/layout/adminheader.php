<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Zenith & Co Admin</title>
  
  <!-- Tailwind CSS -->
  <link rel="stylesheet" href="/zenithco/public/css/output.css">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">

  <!-- Favicons (optional) -->
  <link rel="icon" href="/zenithco/public/images/favicon.png" type="image/png">
</head>
<body class="bg-ivory text-charcoal font-sans">

  <header class="bg-navy shadow">
    <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
      <h1 class="text-2xl font-display text-ivory">Zenith & Co Admin</h1>

      <?php if (isset($_SESSION['admin_username'])): ?>
        <div class="text-ivory text-sm flex items-center space-x-4">
          <span>Welcome, <strong><?= htmlspecialchars($_SESSION['admin_username']) ?></strong></span>
          <a href="/zenithco/app/controllers/admincontroller.php?action=logout"
             class="bg-amber-600 hover:bg-red-600 px-3 py-1 rounded text-white transition text-sm">
            Logout
          </a>
        </div>
      <?php endif; ?>
    </div>
  </header>
