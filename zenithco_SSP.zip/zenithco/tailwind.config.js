/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.php",
    "./public/**/*.php",
    "./*.php"
  ],
  theme: {
    extend: {
      colors: {
        // Original backend colors (keep for compatibility)
        ivory: "#F7F6F1",
        ether: "#E9E8E1",
        mist: "#E0E9E3",
        essence: "#353C44",
        ember: "#D3A558",
        navy: "#2F4156",
        
        // New minimal professional colors
        // Pure whites and off-whites
        pure: "#FFFFFF",
        snow: "#FAFAFA",
        ghost: "#F8F9FA",
        smoke: "#F5F6F7",
        
        // Light grays
        silver: "#E9ECEF",
        cloud: "#CED4DA",
        
        // Medium grays
        slate: "#ADB5BD",
        steel: "#6C757D",
        storm: "#495057",
        
        // Dark grays and blacks
        charcoal: "#343A40",
        graphite: "#212529",
        midnight: "#1A1D20",
        obsidian: "#000000",
        
        // Professional dark blues (updated)
        sky: "#F1F5F9",
        ocean: "#E2E8F0",
        azure: "#CBD5E1",
        slate_blue: "#64748B",
        steel_blue: "#475569",
        dark_blue: "#334155",
        navy_blue: "#1E293B",
        deep_navy: "#0F172A",
        midnight_blue: "#020617",
        
        // Primary brand colors (dark blues)
        primary: "#1E293B",      // Main brand color
        primary_dark: "#0F172A",  // Darker variant
        primary_light: "#334155", // Lighter variant
        
        // Accent colors (minimal use)
        success: "#059669",
        warning: "#D97706",
        error: "#DC2626",
        info: "#0891B2"
      },
      fontFamily: {
        sans: ['Inter', 'Montserrat', 'system-ui', 'sans-serif'],
        serif: ['Playfair Display', 'Georgia', 'serif'],
        display: ['Cormorant Garamond', 'Times', 'serif'],
        mono: ['JetBrains Mono', 'monospace']
      },
      animation: {
        // Original animations
        'fade-in': 'fadeIn 0.5s ease-in-out',
        'slide-up': 'slideUp 0.5s ease-out',
        'float': 'float 3s ease-in-out infinite',
        'shimmer': 'shimmer 2s infinite',
        'scale-in': 'scaleIn 0.6s ease-out',
        'bounce-subtle': 'bounceSubtle 2s infinite',
        
        // New minimal animations
        'slide-down': 'slideDown 0.5s ease-out',
        'slide-left': 'slideLeft 0.5s ease-out',
        'slide-right': 'slideRight 0.5s ease-out',
        'pulse-subtle': 'pulseSubtle 2s ease-in-out infinite'
      },
      keyframes: {
        // Original keyframes
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' }
        },
        slideUp: {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' }
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' }
        },
        shimmer: {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(100%)' }
        },
        scaleIn: {
          '0%': { transform: 'scale(0.9)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' }
        },
        bounceSubtle: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-5px)' }
        },
        
        // New keyframes
        slideDown: {
          '0%': { transform: 'translateY(-20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' }
        },
        slideLeft: {
          '0%': { transform: 'translateX(20px)', opacity: '0' },
          '100%': { transform: 'translateX(0)', opacity: '1' }
        },
        slideRight: {
          '0%': { transform: 'translateX(-20px)', opacity: '0' },
          '100%': { transform: 'translateX(0)', opacity: '1' }
        },
        pulseSubtle: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.8' }
        }
      },
      backgroundImage: {
        // Original gradients
        'luxury-gradient': 'linear-gradient(135deg, #F7F6F1 0%, #E0E9E3 100%)',
        'ember-gradient': 'linear-gradient(135deg, #D3A558 0%, #B8934A 100%)',
        'essence-gradient': 'linear-gradient(135deg, #353C44 0%, #2F4156 100%)',
        'shimmer-gradient': 'linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)',
        
        // New professional gradients
        'minimal-gradient': 'linear-gradient(135deg, #FFFFFF 0%, #F8F9FA 100%)',
        'primary-gradient': 'linear-gradient(135deg, #1E293B 0%, #0F172A 100%)',
        'dark-gradient': 'linear-gradient(135deg, #343A40 0%, #212529 100%)',
        'subtle-gradient': 'linear-gradient(135deg, #F5F6F7 0%, #E9ECEF 100%)'
      },
      backdropBlur: {
        'xs': '2px',
        'sm': '4px'
      },
      spacing: {
        '18': '4.5rem',
        '22': '5.5rem',
        '88': '22rem',
        '100': '25rem',
        '112': '28rem',
        '128': '32rem'
      },
      borderRadius: {
        '4xl': '2rem',
        '5xl': '2.5rem'
      },
      boxShadow: {
        // Original shadows
        'luxury': '0 25px 50px -12px rgba(47, 65, 86, 0.25)',
        'ember': '0 10px 30px -5px rgba(211, 165, 88, 0.3)',
        'subtle': '0 2px 15px -3px rgba(0, 0, 0, 0.07)',
        'glow': '0 0 20px rgba(211, 165, 88, 0.4)',
        
        // New minimal shadows
        'minimal': '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
        'soft': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        'medium': '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
        'large': '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
        'primary': '0 10px 25px -5px rgba(30, 41, 59, 0.3)',
        'inner': 'inset 0 2px 4px 0 rgba(0, 0, 0, 0.06)'
      },
      letterSpacing: {
        'luxury': '0.025em',
        'tight': '-0.025em',
        'snug': '-0.015em'
      },
      lineHeight: {
        'luxury': '1.3'
      }
    }
  },
  plugins: []
}