<?php
require_once __DIR__ . '/../../config/database.php';

function getWishlistItems($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT p.* 
        FROM whishlist w 
        JOIN products p ON w.product_id = p.id 
        WHERE w.user_id = ?
    ");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

function addToWishlist($user_id, $product_id) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT IGNORE INTO whishlist (user_id, product_id) VALUES (?, ?)");
    return $stmt->execute([$user_id, $product_id]);
}

function removeFromWishlist($user_id, $product_id) {
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM whishlist WHERE user_id = ? AND product_id = ?");
    return $stmt->execute([$user_id, $product_id]);
}

function getAdminWishlistItems() {
    global $pdo;

    $query = "
        SELECT 
            w.id,
            w.created_at AS added_on,
            u.name AS user_name,
            u.email AS user_email,
            p.name AS product_name,
            p.price AS product_price
        FROM whishlist w
        JOIN users u ON w.user_id = u.id
        JOIN products p ON w.product_id = p.id
        ORDER BY w.created_at DESC
    ";

    return $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);
}
