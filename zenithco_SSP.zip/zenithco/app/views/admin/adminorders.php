<?php include __DIR__ . '/../layout/layout.php'; ?>

<div class="min-h-screen bg-ivory px-6 py-10">
  <div class="max-w-7xl mx-auto">
    <div class="flex justify-between items-center mb-8">
      <h2 class="text-3xl font-display text-navy">Manage Orders</h2>
      <a href="/zenithco/public/index.php?page=admin_dashboard"
         class="bg-navy text-white px-4 py-2 rounded hover:bg-essence transition">
         ← Back to Dashboard
      </a>
    </div>

    <?php if (empty($orders)): ?>
      <p class="text-essence/70 text-sm">No orders yet.</p>
    <?php else: ?>
      <div class="overflow-x-auto">
        <table class="min-w-full bg-white text-sm border border-ether rounded-lg overflow-hidden">
          <thead class="bg-mist text-essence uppercase text-xs">
            <tr>
              <th class="px-4 py-3">Order ID</th>
              <th class="px-4 py-3">User</th>
              <th class="px-4 py-3">Email</th>
              <th class="px-4 py-3">Total</th>
              <th class="px-4 py-3">Status</th>
              <th class="px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($orders as $order): ?>
              <tr class="border-t border-ether">
                <td class="px-4 py-3"><?= $order['id'] ?></td>
                <td class="px-4 py-3"><?= htmlspecialchars($order['user_name']) ?></td>
                <td class="px-4 py-3"><?= htmlspecialchars($order['email']) ?></td>
                <td class="px-4 py-3">Rs. <?= number_format($order['total_amount'], 2) ?></td>
                <td class="px-4 py-3"><?= $order['status'] ?></td>
                <td class="px-4 py-3 space-x-2">
                  <a href="/zenithco/public/index.php?page=order_details&id=<?= $order['id'] ?>"
                     class="bg-navy text-white px-3 py-1 rounded hover:bg-essence text-xs">Details</a>
                  <form method="POST" action="/zenithco/public/index.php?page=update_order_status&id=<?= $order['id'] ?>" class="inline">
                    <select name="status" onchange="this.form.submit()" class="text-xs px-2 py-1 rounded bg-ether border">
                      <option disabled selected>Change Status</option>
                      <option value="Pending">Pending</option>
                      <option value="Processing">Processing</option>
                      <option value="Completed">Completed</option>
                      <option value="Cancelled">Cancelled</option>
                    </select>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
