<?php
require_once __DIR__ . '/../models/cart.php';
require_once __DIR__ . '/../models/product.php';

/**
 * Handle Add to Cart
 */
function handleAddToCart() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    error_log("[CART_CONTROLLER] handleAddToCart() called");
    error_log("[CART_CONTROLLER] POST data: " . print_r($_POST, true));
    error_log("[CART_CONTROLLER] SESSION data: " . print_r($_SESSION, true));
    
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        error_log("[CART_CONTROLLER] User not logged in");
        $_SESSION['error'] = "Please login to add items to cart";
        header("Location: /zenithco/public/index.php?page=user_login");
        exit();
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $userId = $_SESSION['user_id'];
        $productId = $_POST['product_id'] ?? null;
        $quantity = (int)($_POST['quantity'] ?? 1);
        
        error_log("[CART_CONTROLLER] Processing add to cart - User: $userId, Product: $productId, Quantity: $quantity");
        
        // Validate input
        if (!$productId || $quantity <= 0) {
            error_log("[CART_CONTROLLER] Invalid product ID or quantity");
            $_SESSION['error'] = "Invalid product or quantity";
            header("Location: " . ($_SERVER['HTTP_REFERER'] ?? "/zenithco/public/index.php?page=landing"));
            exit();
        }
        
        // Check if product exists
        $product = getProductById($productId);
        if (!$product) {
            error_log("[CART_CONTROLLER] Product not found: $productId");
            $_SESSION['error'] = "Product not found";
            header("Location: " . ($_SERVER['HTTP_REFERER'] ?? "/zenithco/public/index.php?page=landing"));
            exit();
        }
        
        error_log("[CART_CONTROLLER] Product found: " . $product['name']);
        
        // Add to cart
        try {
            if (addToCart($userId, $productId, $quantity)) {
                error_log("[CART_CONTROLLER] Successfully added to cart");
                $_SESSION['success'] = "Product added to cart successfully!";
            } else {
                error_log("[CART_CONTROLLER] Failed to add to cart");
                $_SESSION['error'] = "Failed to add product to cart";
            }
        } catch (Exception $e) {
            error_log("[CART_CONTROLLER] Exception adding to cart: " . $e->getMessage());
            $_SESSION['error'] = "Error adding product to cart: " . $e->getMessage();
        }
        
        // Redirect back to previous page or to cart
        $redirectUrl = $_SERVER['HTTP_REFERER'] ?? "/zenithco/public/index.php?page=user_cart";
        error_log("[CART_CONTROLLER] Redirecting to: $redirectUrl");
        header("Location: $redirectUrl");
        exit();
    } else {
        error_log("[CART_CONTROLLER] Not a POST request");
        header("Location: /zenithco/public/index.php?page=landing");
        exit();
    }
}

/**
 * Show Cart Page
 */
function showCart() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    error_log("[CART_CONTROLLER] showCart() called");
    
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        error_log("[CART_CONTROLLER] User not logged in for cart view");
        $_SESSION['error'] = "Please login to view your cart";
        header("Location: /zenithco/public/index.php?page=user_login");
        exit();
    }
    
    $userId = $_SESSION['user_id'];
    error_log("[CART_CONTROLLER] Loading cart for user: $userId");
    
    try {
        $cartItems = getCartItems($userId);
        $cartTotal = getCartTotal($userId);
        $cartCount = getCartCount($userId);
        
        error_log("[CART_CONTROLLER] Cart loaded - Items: " . count($cartItems) . ", Total: $cartTotal, Count: $cartCount");
        
        // Include the cart view
        include __DIR__ . '/../views/customer/user_cart.php';
        
    } catch (Exception $e) {
        error_log("[CART_CONTROLLER] Exception loading cart: " . $e->getMessage());
        $_SESSION['error'] = "Error loading cart: " . $e->getMessage();
        
        // Set empty defaults and show cart anyway
        $cartItems = [];
        $cartTotal = 0;
        $cartCount = 0;
        include __DIR__ . '/../views/customer/user_cart.php';
    }
}

/**
 * Handle Remove from Cart
 */
function handleRemoveFromCart() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    error_log("[CART_CONTROLLER] handleRemoveFromCart() called");
    
    if (!isset($_SESSION['user_id'])) {
        error_log("[CART_CONTROLLER] User not logged in for remove from cart");
        $_SESSION['error'] = "Please login first";
        header("Location: /zenithco/public/index.php?page=user_login");
        exit();
    }
    
    $userId = $_SESSION['user_id'];
    $productId = $_GET['product_id'] ?? $_POST['product_id'] ?? null;
    
    error_log("[CART_CONTROLLER] Removing from cart - User: $userId, Product: $productId");
    
    if ($productId) {
        try {
            if (removeFromCart($userId, $productId)) {
                error_log("[CART_CONTROLLER] Successfully removed from cart");
                $_SESSION['success'] = "Item removed from cart";
            } else {
                error_log("[CART_CONTROLLER] Failed to remove from cart");
                $_SESSION['error'] = "Failed to remove item from cart";
            }
        } catch (Exception $e) {
            error_log("[CART_CONTROLLER] Exception removing from cart: " . $e->getMessage());
            $_SESSION['error'] = "Error removing item: " . $e->getMessage();
        }
    } else {
        error_log("[CART_CONTROLLER] No product ID provided for removal");
        $_SESSION['error'] = "No product specified for removal";
    }
    
    header("Location: /zenithco/public/index.php?page=user_cart");
    exit();
}

/**
 * Handle Update Cart Quantity
 */
function handleUpdateCartQuantity() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    error_log("[CART_CONTROLLER] handleUpdateCartQuantity() called");
    
    if (!isset($_SESSION['user_id'])) {
        error_log("[CART_CONTROLLER] User not logged in for quantity update");
        $_SESSION['error'] = "Please login first";
        header("Location: /zenithco/public/index.php?page=user_login");
        exit();
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $userId = $_SESSION['user_id'];
        $productId = $_POST['product_id'] ?? null;
        $quantity = (int)($_POST['quantity'] ?? 0);
        
        error_log("[CART_CONTROLLER] Updating cart quantity - User: $userId, Product: $productId, Quantity: $quantity");
        
        if ($productId && $quantity >= 0) {
            try {
                if (updateCartQuantity($userId, $productId, $quantity)) {
                    error_log("[CART_CONTROLLER] Successfully updated cart quantity");
                    $_SESSION['success'] = "Cart updated successfully";
                } else {
                    error_log("[CART_CONTROLLER] Failed to update cart quantity");
                    $_SESSION['error'] = "Failed to update cart";
                }
            } catch (Exception $e) {
                error_log("[CART_CONTROLLER] Exception updating cart quantity: " . $e->getMessage());
                $_SESSION['error'] = "Error updating cart: " . $e->getMessage();
            }
        } else {
            error_log("[CART_CONTROLLER] Invalid product ID or quantity for update");
            $_SESSION['error'] = "Invalid product or quantity";
        }
    } else {
        error_log("[CART_CONTROLLER] Not a POST request for quantity update");
        $_SESSION['error'] = "Invalid request method";
    }
    
    header("Location: /zenithco/public/index.php?page=user_cart");
    exit();
}

/**
 * Handle Clear Cart
 */
function handleClearCart() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    error_log("[CART_CONTROLLER] handleClearCart() called");
    
    if (!isset($_SESSION['user_id'])) {
        error_log("[CART_CONTROLLER] User not logged in for clear cart");
        $_SESSION['error'] = "Please login first";
        header("Location: /zenithco/public/index.php?page=user_login");
        exit();
    }
    
    $userId = $_SESSION['user_id'];
    
    try {
        if (clearCart($userId)) {
            error_log("[CART_CONTROLLER] Successfully cleared cart");
            $_SESSION['success'] = "Cart cleared successfully";
        } else {
            error_log("[CART_CONTROLLER] Failed to clear cart");
            $_SESSION['error'] = "Failed to clear cart";
        }
    } catch (Exception $e) {
        error_log("[CART_CONTROLLER] Exception clearing cart: " . $e->getMessage());
        $_SESSION['error'] = "Error clearing cart: " . $e->getMessage();
    }
    
    header("Location: /zenithco/public/index.php?page=user_cart");
    exit();
}

/**
 * Get cart data for AJAX requests
 */
function getCartData() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    header('Content-Type: application/json');
    
    if (!isset($_SESSION['user_id'])) {
        echo json_encode([
            'success' => false,
            'message' => 'User not logged in',
            'data' => ['count' => 0, 'total' => 0]
        ]);
        exit();
    }
    
    $userId = $_SESSION['user_id'];
    
    try {
        $cartCount = getCartCount($userId);
        $cartTotal = getCartTotal($userId);
        
        echo json_encode([
            'success' => true,
            'data' => [
                'count' => $cartCount,
                'total' => number_format($cartTotal, 2),
                'items' => getCartItems($userId)
            ]
        ]);
        
    } catch (Exception $e) {
        error_log("[CART_CONTROLLER] Exception getting cart data: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'Error loading cart data',
            'data' => ['count' => 0, 'total' => 0]
        ]);
    }
    
    exit();
}

/**
 * Add to cart via AJAX
 */
function ajaxAddToCart() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    header('Content-Type: application/json');
    
    if (!isset($_SESSION['user_id'])) {
        echo json_encode([
            'success' => false,
            'message' => 'Please login to add items to cart'
        ]);
        exit();
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $userId = $_SESSION['user_id'];
        $productId = $_POST['product_id'] ?? null;
        $quantity = (int)($_POST['quantity'] ?? 1);
        
        if (!$productId || $quantity <= 0) {
            echo json_encode([
                'success' => false,
                'message' => 'Invalid product or quantity'
            ]);
            exit();
        }
        
        try {
            if (addToCart($userId, $productId, $quantity)) {
                $cartCount = getCartCount($userId);
                $cartTotal = getCartTotal($userId);
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Product added to cart successfully!',
                    'data' => [
                        'count' => $cartCount,
                        'total' => number_format($cartTotal, 2)
                    ]
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to add product to cart'
                ]);
            }
        } catch (Exception $e) {
            echo json_encode([
                'success' => false,
                'message' => 'Error adding product to cart: ' . $e->getMessage()
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid request method'
        ]);
    }
    
    exit();
}