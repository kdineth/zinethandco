<?php
require_once __DIR__ . '/../models/product.php';

function showAddProductForm() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (!isset($_SESSION['admin_logged_in'])) {
        header("Location: /zenithco/public/index.php?page=admin_login");
        exit();
    }
    include __DIR__ . '/../views/admin/addproduct.php';
}

function handleAddProduct() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = trim($_POST['name']);
        $price = $_POST['price'];
        $description = trim($_POST['description']);
        $stock = $_POST['stock'];

        $uploadDir = __DIR__ . '/../../public/uploads/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
        $imageName = uniqid() . '-' . basename($_FILES['image']['name']);
        $uploadPath = $uploadDir . $imageName;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath)) {
            $imagePath = '/zenithco/public/uploads/' . $imageName;
            if (addProduct($name, $price, $description, $imagePath, $stock)) {
                $_SESSION['success'] = "Product added successfully!";
            } else {
                $_SESSION['error'] = "Failed to save product to database.";
            }
        } else {
            $_SESSION['error'] = "Image upload failed.";
        }
        header("Location: /zenithco/public/index.php?page=add_product");
        exit();
    }
}

function showAllProducts() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (!isset($_SESSION['admin_logged_in'])) {
        header("Location: /zenithco/public/index.php?page=admin_login");
        exit();
    }
    $products = getAllProducts();
    include __DIR__ . '/../views/admin/viewproducts.php';
}

function showAllProductsForUpdate() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (!isset($_SESSION['admin_logged_in'])) {
        header("Location: /zenithco/public/index.php?page=admin_login");
        exit();
    }
    $products = getAllProducts();
    include __DIR__ . '/../views/admin/updateproducts.php';
}

function showEditProductForm($id) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (!isset($_SESSION['admin_logged_in'])) {
        header("Location: /zenithco/public/index.php?page=admin_login");
        exit();
    }
    $product = getProductById($id);
    if (!$product) {
        $_SESSION['error'] = "Product not found.";
        header("Location: /zenithco/public/index.php?page=view_products");
        exit();
    }
    include __DIR__ . '/../views/admin/editproduct.php';
}

function handleEditProduct($id) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = trim($_POST['name']);
        $price = $_POST['price'];
        $description = trim($_POST['description']);
        $stock = $_POST['stock'];
        $oldImage = $_POST['old_image'];
        $imagePath = $oldImage;

        if (isset($_FILES['image']) && $_FILES['image']['name']) {
            $uploadDir = __DIR__ . '/../../public/uploads/';
            $imageName = uniqid() . '-' . basename($_FILES['image']['name']);
            $uploadPath = $uploadDir . $imageName;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath)) {
                $imagePath = '/zenithco/public/uploads/' . $imageName;
            }
        }

        if (updateProduct($id, $name, $price, $description, $imagePath, $stock)) {
            $_SESSION['success'] = "Product updated successfully!";
        } else {
            $_SESSION['error'] = "Failed to update product.";
        }

        header("Location: /zenithco/public/index.php?page=view_products");
        exit();
    }
}

function handleDeleteProduct($id) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (!isset($_SESSION['admin_logged_in'])) {
        header("Location: /zenithco/public/index.php?page=admin_login");
        exit();
    }

    if (deleteProduct($id)) {
        $_SESSION['success'] = "Product deleted successfully!";
    } else {
        $_SESSION['error'] = "Failed to delete product.";
    }

    header("Location: /zenithco/public/index.php?page=view_products");
    exit();
}

function showAllProductsForDelete() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (!isset($_SESSION['admin_logged_in'])) {
        header("Location: /zenithco/public/index.php?page=admin_login");
        exit();
    }
    $products = getAllProducts();
    include __DIR__ . '/../views/admin/deleteproducts.php';
}

function handleBulkDelete() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (!empty($_POST['selected_products'])) {
        foreach ($_POST['selected_products'] as $id) {
            deleteProduct($id);
        }
        $_SESSION['success'] = "Selected products deleted successfully!";
    } else {
        $_SESSION['error'] = "No products selected.";
    }
    header("Location: /zenithco/public/index.php?page=delete_products");
    exit();
}

function showLandingPage() {
    $products = getFeaturedProducts(); // from product.php
    include __DIR__ . '/../views/customer/landingpage.php';
}

function showUserProductGrid() {
    $products = getAllProducts(); // from product.php
    include __DIR__ . '/../views/customer/user-products.php';
}

function showProductDetail() {
    $id = $_GET['id'] ?? null;
    if (!$id) {
        include __DIR__ . '/../views/customer/product_detail.php';
        return;
    }
    $product = getProductById($id);
    include __DIR__ . '/../views/customer/product_detail.php';
}
