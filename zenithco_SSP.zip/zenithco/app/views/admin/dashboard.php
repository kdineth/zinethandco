<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: /zenithco/public/index.php?page=admin_login");
    exit();
}
include __DIR__ . '/../layout/layout.php';
?>

<div class="bg-ivory min-h-screen flex-grow">
    <div class="max-w-7xl mx-auto px-6 py-12">
        <h2 class="text-3xl font-display text-navy mb-10">Admin Dashboard</h2>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <!-- Product Management -->
            <div class="bg-white border border-ether rounded-lg shadow p-6">
                <h3 class="text-xl font-serif text-navy mb-4">Product Management</h3>
                <p class="text-sm text-essence/70 mb-6">Add, view, update or delete product listings.</p>
                <div class="space-y-2">
                    <a href="/zenithco/public/index.php?page=add_product" class="block w-full bg-mist text-essence rounded py-2 px-4 text-center hover:bg-navy hover:text-ivory transition">Add Product</a>
                   <a href="/zenithco/public/index.php?page=view_products"
   class="block w-full bg-mist text-essence rounded py-2 px-4 text-center hover:bg-navy hover:text-ivory transition">
   View Products
</a>

                    <a href="/zenithco/public/index.php?page=update_products" class="block w-full bg-mist text-essence rounded py-2 px-4 text-center hover:bg-navy hover:text-ivory transition">Update Product</a>
                    <a href="/zenithco/public/index.php?page=delete_products" class="block w-full bg-mist text-essence rounded py-2 px-4 text-center hover:bg-navy hover:text-ivory transition">Delete Product</a>
                </div>
            </div>

            <!-- User Management -->
            <div class="bg-white border border-ether rounded-lg shadow p-6">
                <h3 class="text-xl font-serif text-navy mb-4">User Management</h3>
                <p class="text-sm text-essence/70 mb-6">Access user accounts and manage permissions.</p>
                <a href="/zenithco/public/index.php?page=view_users"
   class="block w-full bg-mist text-essence rounded py-2 px-4 text-center hover:bg-navy hover:text-ivory transition">
   View Users
</a>

            </div>

           <!-- Order Management -->
<div class="bg-white border border-ether rounded-lg shadow p-6">
    <h3 class="text-xl font-serif text-navy mb-4">Order Management</h3>
    <p class="text-sm text-essence/70 mb-6">Monitor and process customer orders.</p>
    
    <div class="space-y-2">
        <a href="/zenithco/public/index.php?page=manage_orders"
           class="block w-full bg-mist text-essence rounded py-2 px-4 text-center hover:bg-ember hover:text-ivory transition">
           Manage Orders
        </a>
        <a href="/zenithco/public/index.php?page=admin_wishlist"
           class="block w-full bg-mist text-essence rounded py-2 px-4 text-center hover:bg-navy hover:text-ivory transition">
           View Wishlist Items
        </a>
    </div>
</div>

        </div>
    </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
