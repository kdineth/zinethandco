<footer class="bg-primary text-pure pt-16 pb-8">
    <div class="max-w-7xl mx-auto px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-10 text-sm">
        <!-- Brand -->
        <div class="md:col-span-1">
            <h2 class="font-display text-2xl mb-4 text-pure">Zenith & Co</h2>
            <p class="text-pure/80 mb-6 leading-relaxed">
                Crafting exceptional jewelry since 1987. Where traditional artistry meets contemporary elegance in every handcrafted piece.
            </p>
            <div class="space-y-2 text-pure/70">
                <p class="flex items-center">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                    </svg>
                    123 Heritage Blvd, Colombo
                </p>
                <p class="flex items-center">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
                    </svg>
                    +94 77 123 4567
                </p>
                <p class="flex items-center">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                    </svg>
                    support@zenithandco.com
                </p>
            </div>
        </div>

        <!-- Quick Links -->
        <div>
            <h3 class="font-semibold mb-4 text-pure">Shop</h3>
            <ul class="space-y-3 text-pure/80">
                <li><a href="/zenithco/public/index.php?page=user_products" class="hover:text-pure transition-colors">All Collections</a></li>
                <li><a href="/zenithco/public/index.php?page=user_products&category=rings" class="hover:text-pure transition-colors">Rings</a></li>
                <li><a href="/zenithco/public/index.php?page=user_products&category=necklaces" class="hover:text-pure transition-colors">Necklaces</a></li>
                <li><a href="/zenithco/public/index.php?page=user_products&category=earrings" class="hover:text-pure transition-colors">Earrings</a></li>
                <li><a href="/zenithco/public/index.php?page=user_products&category=bracelets" class="hover:text-pure transition-colors">Bracelets</a></li>
                <li><a href="#" class="hover:text-pure transition-colors">Gift Cards</a></li>
            </ul>
        </div>

        <!-- Customer Service -->
        <div>
            <h3 class="font-semibold mb-4 text-pure">Customer Service</h3>
            <ul class="space-y-3 text-pure/80">
                <li><a href="#" class="hover:text-pure transition-colors">Size Guide</a></li>
                <li><a href="#" class="hover:text-pure transition-colors">Shipping & Returns</a></li>
                <li><a href="#" class="hover:text-pure transition-colors">Care Instructions</a></li>
                <li><a href="#" class="hover:text-pure transition-colors">Warranty</a></li>
                <li><a href="#" class="hover:text-pure transition-colors">Contact Support</a></li>
                <li><a href="#" class="hover:text-pure transition-colors">FAQ</a></li>
            </ul>
        </div>

        <!-- Company -->
        <div>
            <h3 class="font-semibold mb-4 text-pure">Company</h3>
            <ul class="space-y-3 text-pure/80">
                <li><a href="#" class="hover:text-pure transition-colors">Our Story</a></li>
                <li><a href="#" class="hover:text-pure transition-colors">Craftsmanship</a></li>
                <li><a href="#" class="hover:text-pure transition-colors">Sustainability</a></li>
                <li><a href="#" class="hover:text-pure transition-colors">Careers</a></li>
                <li><a href="#" class="hover:text-pure transition-colors">Press</a></li>
                <li><a href="#" class="hover:text-pure transition-colors">Reviews</a></li>
            </ul>
        </div>
    </div>

    <!-- Newsletter Signup -->
    <div class="max-w-7xl mx-auto px-6 lg:px-8 mt-12 pt-8 border-t border-pure/20">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
                <h3 class="text-lg font-semibold text-pure mb-2">Stay Connected</h3>
                <p class="text-pure/80">Subscribe to receive updates on new collections and exclusive offers.</p>
            </div>
            <div class="lg:text-right">
                <form class="flex flex-col sm:flex-row gap-3 lg:justify-end">
                    <input type="email" 
                           placeholder="Enter your email" 
                           class="px-4 py-3 rounded-lg border border-pure/30 bg-pure/10 text-pure placeholder-pure/60 focus:outline-none focus:ring-2 focus:ring-pure/50 backdrop-blur-sm">
                    <button type="submit" 
                            class="px-6 py-3 bg-pure text-primary font-semibold rounded-lg hover:bg-pure/90 transition-colors duration-200">
                        Subscribe
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Social Media & Bottom Bar -->
    <div class="max-w-7xl mx-auto px-6 lg:px-8 mt-8 pt-6 border-t border-pure/20">
        <div class="flex flex-col md:flex-row justify-between items-center gap-4">
            <!-- Social Media -->
            <div class="flex space-x-4">
                <a href="#" class="text-pure/70 hover:text-pure transition-colors" title="Facebook">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                    </svg>
                </a>
                <a href="#" class="text-pure/70 hover:text-pure transition-colors" title="Instagram">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 6.618 5.367 11.986 11.988 11.986s11.987-5.368 11.987-11.986C24.014 5.367 18.635.001 12.017.001zm5.568 16.918c-.397 1.021-1.556 2.179-2.574 2.574-1.297.502-4.37.502-5.667 0-1.018-.395-2.177-1.553-2.574-2.574-.502-1.297-.502-4.369 0-5.666.397-1.021 1.556-2.179 2.574-2.574 1.297-.502 4.37-.502 5.667 0 1.018.395 2.177 1.553 2.574 2.574.502 1.297.502 4.369 0 5.666z"/>
                    </svg>
                </a>
                <a href="#" class="text-pure/70 hover:text-pure transition-colors" title="Twitter">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                    </svg>
                </a>
                <a href="#" class="text-pure/70 hover:text-pure transition-colors" title="Pinterest">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.174-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.739.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.402.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.357-.629-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24.009 12.017 24.009c6.624 0 11.99-5.367 11.99-11.986C24.007 5.367 18.641.001 12.017.001z"/>
                    </svg>
                </a>
            </div>

            <!-- Legal Links -->
            <div class="flex flex-wrap justify-center md:justify-end gap-6 text-xs text-pure/70">
                <a href="#" class="hover:text-pure transition-colors">Privacy Policy</a>
                <a href="#" class="hover:text-pure transition-colors">Terms of Service</a>
                <a href="#" class="hover:text-pure transition-colors">Cookie Policy</a>
                <a href="#" class="hover:text-pure transition-colors">Accessibility</a>
            </div>
        </div>

        <!-- Copyright -->
        <div class="text-center mt-6 pt-6 border-t border-pure/20">
            <p class="text-xs text-pure/60">
                &copy; <?= date('Y') ?> Zenith & Co. All rights reserved. | Crafted with excellence since 1987.
            </p>
        </div>
    </div>
</footer>