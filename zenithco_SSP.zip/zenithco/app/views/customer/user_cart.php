<?php
include __DIR__ . '/../layout/userheader.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// If cart variables aren't set, set them to safe defaults
if (!isset($cartItems)) $cartItems = [];
if (!isset($cartTotal)) $cartTotal = 0;
if (!isset($cartCount)) $cartCount = 0;
?>

<main class="bg-ivory pt-32 pb-16 px-4 sm:px-8 min-h-screen">
  <div class="max-w-6xl mx-auto">
    <div class="mb-8">
      <h1 class="text-4xl font-display text-essence mb-2">Shopping Cart</h1>
      <p class="text-essence/70">Review your selected items</p>
    </div>

    <!-- Success/Error Messages -->
    <?php if (isset($_SESSION['success'])): ?>
      <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
        <?= htmlspecialchars($_SESSION['success']) ?>
        <?php unset($_SESSION['success']); ?>
      </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
      <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
        <?= htmlspecialchars($_SESSION['error']) ?>
        <?php unset($_SESSION['error']); ?>
      </div>
    <?php endif; ?>

    <?php if (!empty($cartItems)): ?>
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Cart Items -->
        <div class="lg:col-span-2">
          <div class="bg-pure rounded-lg border border-mist shadow-soft overflow-hidden">
            <div class="p-6 border-b border-mist">
              <h2 class="text-xl font-semibold text-essence">Cart Items (<?= count($cartItems) ?>)</h2>
            </div>
            
            <div class="divide-y divide-mist">
              <?php foreach ($cartItems as $item): ?>
                <div class="p-6 flex flex-col sm:flex-row gap-4">
                  <!-- Product Image -->
                  <div class="flex-shrink-0">
                    <img src="<?= htmlspecialchars($item['image'] ?? '/zenithco/public/images/placeholder.jpg') ?>" 
                         alt="<?= htmlspecialchars($item['name'] ?? 'Product') ?>"
                         class="w-24 h-24 object-cover rounded-lg border border-mist">
                  </div>
                  
                  <!-- Product Details -->
                  <div class="flex-1 min-w-0">
                    <h3 class="text-lg font-semibold text-essence mb-1">
                      <?= htmlspecialchars($item['name'] ?? 'Unknown Product') ?>
                    </h3>
                    <p class="text-sm text-storm mb-3 line-clamp-2">
                      <?= htmlspecialchars($item['description'] ?? 'No description') ?>
                    </p>
                    <p class="text-lg font-bold text-ember">
                      LKR <?= number_format($item['price'] ?? 0, 2) ?>
                    </p>
                  </div>
                  
                  <!-- Quantity Controls -->
                  <div class="flex flex-col sm:items-end gap-3">
                    <form method="POST" action="/zenithco/public/index.php?page=update_cart_quantity" class="flex items-center gap-2">
                      <input type="hidden" name="product_id" value="<?= $item['product_id'] ?? $item['cart_id'] ?>">
                      <label for="quantity_<?= $item['product_id'] ?? $item['cart_id'] ?>" class="text-sm text-storm">Qty:</label>
                      <input type="number" 
                             id="quantity_<?= $item['product_id'] ?? $item['cart_id'] ?>"
                             name="quantity" 
                             value="<?= $item['quantity'] ?? 1 ?>" 
                             min="1" 
                             max="99"
                             class="w-16 px-2 py-1 border border-silver rounded text-center">
                      <button type="submit" class="px-3 py-1 bg-primary text-white text-sm rounded hover:bg-primary_dark transition-colors">
                        Update
                      </button>
                    </form>
                    
                    <!-- Subtotal -->
                    <div class="text-right">
                      <p class="text-lg font-bold text-essence">
                        LKR <?= number_format($item['subtotal'] ?? (($item['price'] ?? 0) * ($item['quantity'] ?? 1)), 2) ?>
                      </p>
                    </div>
                    
                    <!-- Remove Button -->
                    <a href="/zenithco/public/index.php?page=remove_from_cart&product_id=<?= $item['product_id'] ?? $item['cart_id'] ?>" 
                       class="text-red-600 hover:text-red-800 text-sm underline"
                       onclick="return confirm('Are you sure you want to remove this item?')">
                      Remove
                    </a>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
        
        <!-- Cart Summary -->
        <div class="lg:col-span-1">
          <div class="bg-pure rounded-lg border border-mist shadow-soft p-6 sticky top-24">
            <h2 class="text-xl font-semibold text-essence mb-4">Order Summary</h2>
            
            <div class="space-y-3 mb-6">
              <div class="flex justify-between text-storm">
                <span>Items (<?= count($cartItems) ?>)</span>
                <span>LKR <?= number_format($cartTotal, 2) ?></span>
              </div>
              <div class="flex justify-between text-storm">
                <span>Shipping</span>
                <span>Free</span>
              </div>
              <div class="border-t border-mist pt-3">
                <div class="flex justify-between text-lg font-bold text-essence">
                  <span>Total</span>
                  <span>LKR <?= number_format($cartTotal, 2) ?></span>
                </div>
              </div>
            </div>
            
            <!-- Action Buttons -->
            <div class="space-y-3">
              <!-- FIXED: Changed button to working link -->
              <a href="/zenithco/public/index.php?page=checkout" 
                 class="block w-full text-center bg-primary text-white font-semibold py-3 rounded-lg hover:bg-primary_dark transition-colors">
                <svg class="w-5 h-5 inline-block mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6.5-5v5a1 1 0 01-1 1H9a1 1 0 01-1-1v-5m8 0V9a1 1 0 00-1-1H9a1 1 0 00-1 1v4.01"/>
                </svg>
                Proceed to Checkout
              </a>
              
              <a href="/zenithco/public/index.php?page=user_products" 
                 class="block w-full text-center border border-silver text-charcoal font-medium py-3 rounded-lg hover:border-primary hover:text-primary transition-colors">
                <svg class="w-5 h-5 inline-block mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16l-4-4m0 0l4-4m-4 4h18"/>
                </svg>
                Continue Shopping
              </a>
            </div>
            
            <!-- Additional Quick Actions -->
            <div class="mt-6 pt-6 border-t border-mist space-y-3">
              <a href="/zenithco/public/index.php?page=user_wishlist" 
                 class="flex items-center text-sm text-primary hover:text-primary_dark transition-colors">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
                </svg>
                View Wishlist
              </a>
              
              <a href="/zenithco/public/index.php?page=user_orders" 
                 class="flex items-center text-sm text-primary hover:text-primary_dark transition-colors">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v6a2 2 0 002 2h2m0-8v8m0-8h8m-8 0V3a2 2 0 012-2h4a2 2 0 012 2v2m-6 8h8a2 2 0 002-2V9a2 2 0 00-2-2h-8m0 0V3"/>
                </svg>
                Order History
              </a>
              
              <a href="/zenithco/public/index.php?page=clear_cart" 
                 class="flex items-center text-sm text-red-600 hover:text-red-800 transition-colors"
                 onclick="return confirm('Are you sure you want to clear your entire cart?')">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                </svg>
                Clear Cart
              </a>
            </div>
          </div>
        </div>
      </div>
      
    <?php else: ?>
      <!-- Empty Cart -->
      <div class="text-center py-16 bg-pure rounded-lg border border-mist">
        <div class="max-w-md mx-auto">
          <div class="w-24 h-24 bg-ghost rounded-full flex items-center justify-center mx-auto mb-6">
            <svg class="w-12 h-12 text-steel" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                    d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6.5-5v5a1 1 0 01-1 1H9a1 1 0 01-1-1v-5m8 0V9a1 1 0 00-1-1H9a1 1 0 00-1 1v4.01"/>
            </svg>
          </div>
          <h3 class="text-2xl font-semibold text-essence mb-2">Your cart is empty</h3>
          <p class="text-storm mb-6">Add some beautiful jewelry pieces to get started!</p>
          
          <div class="space-y-3">
            <a href="/zenithco/public/index.php?page=user_products" 
               class="inline-block bg-primary text-white font-semibold px-8 py-3 rounded-lg hover:bg-primary_dark transition-colors">
              <svg class="w-5 h-5 inline-block mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
              </svg>
              Shop Now
            </a>
            <br>
            <a href="/zenithco/public/index.php?page=landing" 
               class="inline-block text-primary hover:text-primary_dark underline">
              Browse Featured Products
            </a>
          </div>
        </div>
      </div>
    <?php endif; ?>
    
    <!-- Cart Summary Bar (Mobile Fixed) -->
    <?php if (!empty($cartItems)): ?>
      <div class="fixed bottom-0 left-0 right-0 bg-pure border-t border-mist p-4 lg:hidden">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-sm text-storm"><?= count($cartItems) ?> items</p>
            <p class="text-lg font-bold text-essence">LKR <?= number_format($cartTotal, 2) ?></p>
          </div>
          <a href="/zenithco/public/index.php?page=checkout" 
             class="bg-primary text-white font-semibold px-6 py-3 rounded-lg hover:bg-primary_dark transition-colors">
            Checkout
          </a>
        </div>
      </div>
    <?php endif; ?>
  </div>
</main>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>