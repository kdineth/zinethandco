<?php include __DIR__ . '/../layout/layout.php'; ?>

<div class="min-h-screen bg-ivory px-4 py-10">
  <div class="max-w-7xl mx-auto">
    <div class="flex justify-between items-center mb-8">
      <h2 class="text-3xl font-display text-navy">All Products</h2>
      <a href="/zenithco/public/index.php?page=admin_dashboard"
         class="bg-navy text-white px-4 py-2 rounded hover:bg-essence transition">
         ← Back to Dashboard
      </a>
    </div>

    <?php if (empty($products)): ?>
      <p class="text-essence/70 text-sm">No products found.</p>
    <?php else: ?>
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php foreach ($products as $product): ?>
          <div class="bg-white rounded-lg shadow border border-ether overflow-hidden flex flex-col">
            <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>"
                 class="h-52 object-cover w-full">
            <div class="p-4 flex flex-col justify-between flex-grow">
              <h3 class="text-lg font-serif text-navy mb-1"><?= htmlspecialchars($product['name']) ?></h3>
              <p class="text-sm text-essence mb-2"><?= htmlspecialchars($product['description']) ?></p>
              <div class="mt-auto">
                <p class="text-ember font-medium">Rs. <?= number_format($product['price'], 2) ?></p>
                <p class="text-xs text-essence/60 mt-1">Stock: <?= (int)$product['stock'] ?></p>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
