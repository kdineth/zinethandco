<?php
// Save this as: zenithco/cart_diagnostic.php (in root folder, same level as public)

session_start();
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    die("Please login first: <a href='public/index.php?page=user_login'>Login</a>");
}

$userId = $_SESSION['user_id'];
echo "<h1>Cart Diagnostic for User ID: $userId</h1>";

try {
    // Test 1: Raw cart data
    echo "<h2>Test 1: Raw Cart Data</h2>";
    $stmt = $pdo->prepare("SELECT * FROM cart WHERE user_id = ?");
    $stmt->execute([$userId]);
    $cartData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p><strong>Cart items in database:</strong> " . count($cartData) . "</p>";
    
    if (!empty($cartData)) {
        echo "<table border='1' style='border-collapse: collapse;'>";
        echo "<tr><th>ID</th><th>Product ID</th><th>Quantity</th><th>Created</th></tr>";
        foreach ($cartData as $item) {
            echo "<tr>";
            echo "<td>{$item['id']}</td>";
            echo "<td>{$item['product_id']}</td>";
            echo "<td>{$item['quantity']}</td>";
            echo "<td>{$item['created_at']}</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Test 2: Check if products exist
        echo "<h2>Test 2: Product Existence Check</h2>";
        foreach ($cartData as $cartItem) {
            $stmt = $pdo->prepare("SELECT id, name, price, image FROM products WHERE id = ?");
            $stmt->execute([$cartItem['product_id']]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($product) {
                echo "<p style='color: green;'>✅ Product ID {$cartItem['product_id']}: <strong>{$product['name']}</strong> - LKR {$product['price']}</p>";
            } else {
                echo "<p style='color: red;'>❌ Product ID {$cartItem['product_id']}: <strong>NOT FOUND</strong></p>";
            }
        }
        
        // Test 3: JOIN query test
        echo "<h2>Test 3: JOIN Query Test</h2>";
        $stmt = $pdo->prepare("
            SELECT c.*, p.name, p.price, p.image, p.description
            FROM cart c 
            LEFT JOIN products p ON c.product_id = p.id 
            WHERE c.user_id = ?
        ");
        $stmt->execute([$userId]);
        $joinData = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<p><strong>JOIN query returned:</strong> " . count($joinData) . " items</p>";
        
        if (!empty($joinData)) {
            echo "<table border='1' style='border-collapse: collapse;'>";
            echo "<tr><th>Cart ID</th><th>Product ID</th><th>Name</th><th>Price</th><th>Quantity</th></tr>";
            foreach ($joinData as $item) {
                $nameDisplay = $item['name'] ? $item['name'] : '<span style="color:red;">NULL</span>';
                $priceDisplay = $item['price'] ? $item['price'] : '<span style="color:red;">NULL</span>';
                
                echo "<tr>";
                echo "<td>{$item['id']}</td>";
                echo "<td>{$item['product_id']}</td>";
                echo "<td>$nameDisplay</td>";
                echo "<td>$priceDisplay</td>";
                echo "<td>{$item['quantity']}</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p style='color: red;'>JOIN query returned no results!</p>";
        }
        
        // Test 4: Manual reconstruction
        echo "<h2>Test 4: Manual Cart Item Reconstruction</h2>";
        $manualItems = [];
        foreach ($cartData as $cartItem) {
            $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$cartItem['product_id']]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($product) {
                $manualItems[] = [
                    'cart_id' => $cartItem['id'],
                    'product_id' => $cartItem['product_id'],
                    'quantity' => $cartItem['quantity'],
                    'name' => $product['name'],
                    'price' => $product['price'],
                    'image' => $product['image'],
                    'description' => $product['description'],
                    'subtotal' => $cartItem['quantity'] * $product['price']
                ];
            }
        }
        
        echo "<p><strong>Manual reconstruction created:</strong> " . count($manualItems) . " items</p>";
        
        if (!empty($manualItems)) {
            echo "<h3>Reconstructed Cart Items:</h3>";
            foreach ($manualItems as $item) {
                echo "<div style='border: 1px solid #ccc; margin: 10px; padding: 10px;'>";
                echo "<h4>{$item['name']}</h4>";
                echo "<p>Price: LKR {$item['price']} x {$item['quantity']} = LKR {$item['subtotal']}</p>";
                echo "<p>Image: {$item['image']}</p>";
                echo "</div>";
            }
            
            // Show what the working getCartItems should return
            echo "<h3>Expected getCartItems() Output:</h3>";
            echo "<pre>" . print_r($manualItems, true) . "</pre>";
        }
        
    } else {
        echo "<p style='color: red;'>No cart items found in database!</p>";
    }
    
    // Test 5: Products table check
    echo "<h2>Test 5: Products Table Check</h2>";
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM products");
    $result = $stmt->fetch();
    echo "<p>Total products in database: {$result['count']}</p>";
    
    if ($result['count'] > 0) {
        $stmt = $pdo->query("SELECT id, name FROM products LIMIT 5");
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo "<p>Sample products:</p>";
        foreach ($products as $product) {
            echo "<p>- ID: {$product['id']}, Name: {$product['name']}</p>";
        }
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'><strong>Error:</strong> " . $e->getMessage() . "</p>";
    echo "<p><strong>Stack trace:</strong></p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

echo "<br><br>";
echo "<a href='public/index.php?page=user_cart'>Back to Cart</a> | ";
echo "<a href='public/index.php?page=user_products'>Shop Products</a>";
?>