<footer class="bg-navy py-6 mt-auto">
  <div class="max-w-7xl mx-auto px-4">
    <div class="flex flex-col items-center text-center">
      <h3 class="font-display text-xl text-ivory mb-2">Zenith & Co</h3>
      <div class="h-px w-12 bg-ember mb-4"></div>
      <p class="text-ether/70 text-sm">&copy; <?= date('Y'); ?> Zenith & Co. All rights reserved.</p>
    </div>
  </div>
</footer>

</body>
</html>
