<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Zenith & Co</title>

  <!-- Load Tailwind CSS -->
  <link rel="stylesheet" href="/zenithco/src/output.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Playfair+Display:wght@400;600&family=Cormorant+Garamond:wght@300;500;600&family=Montserrat:wght@400;500;600&display=swap" rel="stylesheet">
</head>

<body class="bg-pure text-charcoal font-sans scroll-smooth">
  <!-- Announcement Bar -->
  <div class="bg-primary text-pure text-center py-2 text-sm font-medium">
    Enjoy Free Worldwide Shipping on Orders Over LKR 75,000
  </div>

  <!-- Header -->
  <header class="fixed top-0 left-0 w-full z-50 bg-pure/95 backdrop-blur-md border-b border-silver shadow-sm">
    <div class="max-w-7xl mx-auto px-6 lg:px-8 py-4">
      <div class="flex justify-between items-center">
        <!-- Brand Logo -->
        <a href="/zenithco/public/index.php?page=landing" class="font-display text-2xl tracking-wide text-charcoal font-semibold hover:text-primary transition-colors">
          Zenith & Co
        </a>

        <!-- Search -->
        <div class="hidden lg:flex flex-1 max-w-md mx-8">
          <form method="GET" action="/zenithco/public/index.php" class="w-full relative">
            <input type="hidden" name="page" value="user_products">
            <input type="text" name="search" placeholder="Search jewelry..." 
              value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>"
              class="w-full px-4 py-2 pl-10 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary text-sm">
            <svg class="w-4 h-4 text-steel absolute left-3 top-1/2 transform -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6M8 11a3 3 0 116 0 3 3 0 01-6 0z"/>
            </svg>
          </form>
        </div>

        <!-- Nav Menu -->
        <nav class="hidden md:flex space-x-8 text-sm font-medium">
          <a href="/zenithco/public/index.php?page=user_products" class="text-charcoal hover:text-primary">Shop Now</a>
          <a href="/zenithco/public/index.php?page=aboutus" class="text-charcoal hover:text-primary">About Us</a>
          <a href="/zenithco/public/index.php?page=services" class="text-charcoal hover:text-primary">Services</a>
          <a href="/zenithco/public/index.php?page=contact" class="text-charcoal hover:text-primary">Contact</a>
        </nav>

        <!-- Icons -->
        <div class="flex items-center space-x-4">
          <!-- Mobile Search -->
          <button id="mobile-search-toggle" class="lg:hidden text-charcoal hover:text-primary" title="Search">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6M8 11a3 3 0 116 0 3 3 0 01-6 0z"/>
            </svg>
          </button>

          <!-- Wishlist -->
          <a href="/zenithco/public/index.php?page=user_wishlist" class="text-charcoal hover:text-primary transition" title="Wishlist">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                    d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
          </a>

          <!-- Cart -->
          <a href="/zenithco/public/index.php?page=user_cart" class="text-charcoal hover:text-primary relative transition" title="Cart">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13l-1.5 6h13l-1.5-6M10 21a1 1 0 100-2 1 1 0 000 2zm8 0a1 1 0 100-2 1 1 0 000 2z"/>
            </svg>
            <span class="absolute -top-2 -right-2 bg-primary text-white text-xs font-bold w-5 h-5 rounded-full flex justify-center items-center">0</span>
          </a>

          <!-- Account -->
          <?php if (isset($_SESSION['user_id'])): ?>
            <div class="relative group">
              <button class="text-charcoal hover:text-primary transition" title="Account">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                </svg>
              </button>
              <div class="absolute right-0 mt-2 w-48 bg-pure border border-silver rounded-lg shadow opacity-0 invisible group-hover:opacity-100 group-hover:visible transition">
                <a href="/zenithco/public/index.php?page=user_profile" class="block px-4 py-2 text-sm hover:bg-ghost">My Profile</a>
                <a href="/zenithco/public/index.php?page=user_orders" class="block px-4 py-2 text-sm hover:bg-ghost">My Orders</a>
                <a href="/zenithco/public/index.php?page=user_wishlist" class="block px-4 py-2 text-sm hover:bg-ghost">Wishlist</a>
                <hr class="my-2 border-silver" />
                <a href="/zenithco/public/index.php?page=logout" class="block px-4 py-2 text-sm text-error hover:bg-ghost">Sign Out</a>
              </div>
            </div>
          <?php else: ?>
            <a href="/zenithco/public/index.php?page=user_login" 
               class="bg-primary text-white px-4 py-2 rounded-lg font-medium hover:bg-primary_dark transition"
               title="Login or Register">
              Log In
            </a>
          <?php endif; ?>
        </div>

        <!-- Mobile Nav Toggle -->
        <button id="mobile-menu-toggle" class="md:hidden text-charcoal hover:text-primary transition">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M4 6h16M4 12h16M4 18h16"/>
          </svg>
        </button>
      </div>

      <!-- Mobile Search -->
      <div class="lg:hidden mt-4 hidden" id="mobile-search">
        <form method="GET" action="/zenithco/public/index.php" class="relative">
          <input type="hidden" name="page" value="user_products">
          <input type="text" name="search" placeholder="Search jewelry..." 
            class="w-full px-4 py-3 pl-10 border border-silver rounded-lg focus:ring-2 focus:ring-primary focus:border-primary">
          <svg class="w-4 h-4 text-steel absolute left-3 top-1/2 transform -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M21 21l-6-6M8 11a3 3 0 116 0 3 3 0 01-6 0z"/>
          </svg>
        </form>
      </div>

      <!-- Mobile Navigation -->
      <div class="md:hidden mt-4 hidden" id="mobile-menu">
        <nav class="space-y-3 pb-4">
          <a href="/zenithco/public/index.php?page=user_products" class="block text-charcoal hover:text-primary font-medium">Shop Now</a>
          <a href="/zenithco/public/index.php?page=aboutus" class="block text-charcoal hover:text-primary font-medium">About Us</a>
          <a href="/zenithco/public/index.php?page=services" class="block text-charcoal hover:text-primary font-medium">Services</a>
          <a href="/zenithco/public/index.php?page=contact" class="block text-charcoal hover:text-primary font-medium">Contact</a>
          <a href="/zenithco/public/index.php?page=user_wishlist" class="block text-charcoal hover:text-primary font-medium">Wishlist</a>
        </nav>
      </div>
    </div>
  </header>

  <script>
    document.getElementById('mobile-menu-toggle').addEventListener('click', () => {
      document.getElementById('mobile-menu').classList.toggle('hidden');
    });
    document.getElementById('mobile-search-toggle').addEventListener('click', () => {
      document.getElementById('mobile-search').classList.toggle('hidden');
    });
  </script>
