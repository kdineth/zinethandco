<?php 
include __DIR__ . '/../layout/userheader.php';
if (session_status() === PHP_SESSION_NONE) session_start();
?>

<main class="bg-ivory pt-32 pb-16 px-4 sm:px-8 min-h-screen animate-fade-in">
  <!-- Go Back Button -->
  <div class="max-w-6xl mx-auto mb-6">
    <a href="http://localhost/zenithco/public/index.php?page=user_products" 
       class="inline-flex items-center text-sm text-essence hover:text-ember transition-colors">
      <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
      </svg>
      Back to Products
    </a>
  </div>

  <!-- Success/Error Messages -->
  <?php if (isset($_SESSION['success'])): ?>
    <div class="max-w-6xl mx-auto mb-6">
      <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
        <?= htmlspecialchars($_SESSION['success']) ?>
        <?php unset($_SESSION['success']); ?>
      </div>
    </div>
  <?php endif; ?>

  <?php if (isset($_SESSION['error'])): ?>
    <div class="max-w-6xl mx-auto mb-6">
      <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <?= htmlspecialchars($_SESSION['error']) ?>
        <?php unset($_SESSION['error']); ?>
      </div>
    </div>
  <?php endif; ?>

  <?php if (!empty($product)): ?>
    <div class="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 items-start">
      
      <!-- Product Image -->
      <div class="rounded-lg overflow-hidden border border-mist shadow">
        <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-auto object-cover">
      </div>
      
      <!-- Product Info -->
      <div>
        <h1 class="text-4xl font-display text-essence mb-4"><?= htmlspecialchars($product['name']) ?></h1>
        <p class="text-xl text-ember font-semibold mb-4">LKR <?= number_format($product['price'], 2) ?></p>
        <p class="text-storm mb-6 leading-relaxed"><?= nl2br(htmlspecialchars($product['description'])) ?></p>

        <!-- Stock Information -->
        <?php if (isset($product['stock']) && $product['stock'] > 0): ?>
          <div class="flex items-center gap-2 mb-4">
            <span class="inline-block w-3 h-3 bg-green-500 rounded-full"></span>
            <span class="text-sm text-green-600">In Stock (<?= $product['stock'] ?> available)</span>
          </div>
        <?php else: ?>
          <div class="flex items-center gap-2 mb-4">
            <span class="inline-block w-3 h-3 bg-red-500 rounded-full"></span>
            <span class="text-sm text-red-600">Out of Stock</span>
          </div>
        <?php endif; ?>

        <!-- Quantity -->
        <div class="flex items-center gap-4 mb-6">
          <label for="quantity" class="text-sm text-charcoal">Quantity:</label>
          <input type="number" id="quantity" name="quantity" value="1" min="1" max="<?= $product['stock'] ?? 99 ?>" required class="w-20 px-3 py-2 border border-silver rounded focus:ring-2 focus:ring-primary">
        </div>

        <!-- Action Buttons -->
        <?php if (isset($_SESSION['user_id'])): ?>
          <!-- User is logged in - show working buttons -->
          <div class="space-y-4">
            <!-- Add to Cart -->
            <form method="POST" action="/zenithco/public/index.php">
              <input type="hidden" name="action" value="add_to_cart">
              <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
              <input type="hidden" name="quantity" id="cart_quantity" value="1">
              <button type="submit" 
                      class="w-full sm:w-auto bg-primary text-white px-6 py-3 rounded-lg font-medium hover:bg-primary_dark transition"
                      <?= (!isset($product['stock']) || $product['stock'] <= 0) ? 'disabled' : '' ?>>
                Add to Cart
              </button>
            </form>

            <!-- Buy Now (you can implement this later) -->
            <form method="POST" action="/zenithco/public/index.php?page=checkout">
              <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
              <input type="hidden" name="quantity" id="buy_quantity" value="1">
              <button type="submit" 
                      class="w-full sm:w-auto bg-ember text-white px-6 py-3 rounded-lg font-medium hover:bg-essence transition"
                      <?= (!isset($product['stock']) || $product['stock'] <= 0) ? 'disabled' : '' ?>>
                Buy Now
              </button>
            </form>

            <!-- Wishlist -->
            <form method="POST" action="/zenithco/public/index.php?page=add_wishlist" class="mt-4">
              <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
              <button type="submit" class="inline-flex items-center text-sm text-charcoal hover:text-primary transition">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
                </svg>
                Add to Wishlist
              </button>
            </form>
          </div>
        <?php else: ?>
          <!-- User is not logged in - show login prompts -->
          <div class="space-y-4">
            <a href="/zenithco/public/index.php?page=user_login" 
               class="block w-full sm:w-auto text-center bg-primary text-white px-6 py-3 rounded-lg font-medium hover:bg-primary_dark transition">
              Login to Add to Cart
            </a>
            
            <a href="/zenithco/public/index.php?page=user_login" 
               class="block w-full sm:w-auto text-center bg-ember text-white px-6 py-3 rounded-lg font-medium hover:bg-essence transition">
              Login to Buy Now
            </a>

            <a href="/zenithco/public/index.php?page=user_login" 
               class="inline-flex items-center text-sm text-charcoal hover:text-primary transition mt-4">
              <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
              </svg>
              Login to Add to Wishlist
            </a>
          </div>
        <?php endif; ?>

        <!-- Product Details Section -->
        <div class="mt-8 pt-8 border-t border-mist">
          <h3 class="text-lg font-semibold text-essence mb-4">Product Details</h3>
          <div class="space-y-2 text-sm text-storm">
            <?php if (isset($product['stock'])): ?>
              <p><strong>Stock:</strong> <?= $product['stock'] ?> units</p>
            <?php endif; ?>
            <p><strong>Product ID:</strong> #<?= $product['id'] ?></p>
            <p><strong>Category:</strong> Jewelry</p>
          </div>
        </div>

        <!-- Related Actions -->
        <div class="mt-8 pt-8 border-t border-mist">
          <div class="flex flex-wrap gap-4">
            <a href="/zenithco/public/index.php?page=user_cart" 
               class="inline-flex items-center text-sm text-primary hover:text-primary_dark transition">
              <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6.5-5v5a1 1 0 01-1 1H9a1 1 0 01-1-1v-5m8 0V9a1 1 0 00-1-1H9a1 1 0 00-1 1v4.01"/>
              </svg>
              View Cart
            </a>
            
            <a href="/zenithco/public/index.php?page=user_products" 
               class="inline-flex items-center text-sm text-primary hover:text-primary_dark transition">
              <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
              </svg>
              Continue Shopping
            </a>
          </div>
        </div>
      </div>
    </div>
  <?php else: ?>
    <div class="text-center text-essence mt-20">
      <div class="max-w-md mx-auto">
        <div class="w-24 h-24 bg-ghost rounded-full flex items-center justify-center mx-auto mb-6">
          <svg class="w-12 h-12 text-steel" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
          </svg>
        </div>
        <h2 class="text-2xl font-display mb-4">Product Not Found</h2>
        <p class="text-storm mb-6">This product may have been removed or is currently unavailable.</p>
        <a href="/zenithco/public/index.php?page=user_products" 
           class="inline-block bg-primary text-white font-semibold px-8 py-3 rounded-lg hover:bg-primary_dark transition-colors">
          Browse All Products
        </a>
      </div>
    </div>
  <?php endif; ?>
</main>

<script>
// Update quantity for both forms when user changes the quantity input
document.getElementById('quantity').addEventListener('change', function() {
  const quantity = this.value;
  const cartQuantity = document.getElementById('cart_quantity');
  const buyQuantity = document.getElementById('buy_quantity');
  
  if (cartQuantity) cartQuantity.value = quantity;
  if (buyQuantity) buyQuantity.value = quantity;
});
</script>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>