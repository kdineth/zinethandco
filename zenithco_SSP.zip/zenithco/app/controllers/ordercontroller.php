<?php
require_once __DIR__ . '/../models/order.php';
require_once __DIR__ . '/../models/cart.php';

/**
 * Debug logging function
 */
function debugLog($message) {
    error_log("[ORDER_CONTROLLER_DEBUG] " . $message);
    // Also output to screen for immediate debugging (remove in production)
    echo "<!-- DEBUG: " . htmlspecialchars($message) . " -->\n";
}

/**
 * Show checkout page
 */
function showCheckout() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    debugLog("showCheckout() called");
    
    if (!isset($_SESSION['user_id'])) {
        debugLog("User not logged in for checkout");
        $_SESSION['error'] = "Please login to checkout";
        header("Location: /zenithco/public/index.php?page=user_login");
        exit();
    }
    
    $userId = $_SESSION['user_id'];
    debugLog("Loading checkout for user ID: $userId");
    
    $cartItems = getCartItems($userId);
    $cartTotal = getCartTotal($userId);
    $cartCount = getCartCount($userId);
    
    debugLog("Cart has " . count($cartItems) . " items, total: $cartTotal, count: $cartCount");
    
    if (empty($cartItems)) {
        debugLog("Cart is empty, redirecting to cart page");
        $_SESSION['error'] = "Your cart is empty";
        header("Location: /zenithco/public/index.php?page=user_cart");
        exit();
    }
    
    debugLog("Including billing page with cart data");
    include __DIR__ . '/../views/customer/user_billing.php';
}

/**
 * Process order from checkout form
 */
function processOrder() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    debugLog("=== processOrder() CALLED ===");
    debugLog("REQUEST_METHOD: " . $_SERVER['REQUEST_METHOD']);
    debugLog("POST data received: " . print_r($_POST, true));
    debugLog("SESSION data: " . print_r($_SESSION, true));
    
    if (!isset($_SESSION['user_id'])) {
        debugLog("ERROR: User not logged in for order processing");
        $_SESSION['error'] = "Please login to place an order";
        header("Location: /zenithco/public/index.php?page=user_login");
        exit();
    }
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        debugLog("ERROR: Not a POST request, method is: " . $_SERVER['REQUEST_METHOD']);
        $_SESSION['error'] = "Invalid request method";
        header("Location: /zenithco/public/index.php?page=user_cart");
        exit();
    }
    
    $userId = $_SESSION['user_id'];
    debugLog("Processing order for user ID: $userId");
    
    // Validate required fields
    $requiredFields = ['name', 'email', 'phone', 'address', 'city', 'zip', 'payment'];
    $missingFields = [];
    
    foreach ($requiredFields as $field) {
        if (empty($_POST[$field])) {
            $missingFields[] = $field;
        }
    }
    
    if (!empty($missingFields)) {
        debugLog("ERROR: Missing required fields: " . implode(', ', $missingFields));
        $_SESSION['error'] = "Please fill in all required fields: " . implode(', ', $missingFields);
        header("Location: /zenithco/public/index.php?page=checkout");
        exit();
    }
    
    debugLog("All required fields validated successfully");
    
    // Get cart data
    $cartTotal = getCartTotal($userId);
    $cartItems = getCartItems($userId);
    
    debugLog("Cart validation - Total: $cartTotal, Items count: " . count($cartItems));
    
    if (empty($cartItems) || $cartTotal <= 0) {
        debugLog("ERROR: Cart is empty or total is 0");
        $_SESSION['error'] = "Your cart is empty";
        header("Location: /zenithco/public/index.php?page=user_cart");
        exit();
    }
    
    // Prepare billing data
    $billingData = [
        'name' => trim($_POST['name']),
        'email' => trim($_POST['email']),
        'phone' => trim($_POST['phone']),
        'address' => trim($_POST['address']),
        'city' => trim($_POST['city']),
        'zip' => trim($_POST['zip']),
        'payment' => $_POST['payment']
    ];
    
    debugLog("Billing data prepared: " . print_r($billingData, true));
    
    // Validate payment method
    $validPaymentMethods = ['card', 'cod', 'paypal', 'bank_transfer'];
    if (!in_array($billingData['payment'], $validPaymentMethods)) {
        debugLog("ERROR: Invalid payment method: " . $billingData['payment']);
        $_SESSION['error'] = "Invalid payment method selected";
        header("Location: /zenithco/public/index.php?page=checkout");
        exit();
    }
    
    // Additional validation for card payments
    if ($billingData['payment'] === 'card') {
        $cardFields = ['card_number', 'expiry_date', 'cvv', 'card_name'];
        $missingCardFields = [];
        
        foreach ($cardFields as $field) {
            if (empty($_POST[$field])) {
                $missingCardFields[] = $field;
            }
        }
        
        if (!empty($missingCardFields)) {
            debugLog("ERROR: Missing card fields: " . implode(', ', $missingCardFields));
            $_SESSION['error'] = "Please fill in all card details";
            header("Location: /zenithco/public/index.php?page=checkout");
            exit();
        }
    }
    
    debugLog("All validation passed, attempting to create order");
    
    // Create order
    try {
        debugLog("Calling createOrder function");
        $orderId = createOrder($userId, $cartTotal, $billingData);
        
        if ($orderId) {
            debugLog("SUCCESS: Order created with ID: $orderId");
            $_SESSION['success'] = "Order placed successfully! Order ID: #$orderId";
            
            // Clear any previous errors
            unset($_SESSION['error']);
            
            debugLog("Redirecting to order success page");
            header("Location: /zenithco/public/index.php?page=order_success&order_id=$orderId");
            exit();
        } else {
            debugLog("ERROR: createOrder returned false");
            $_SESSION['error'] = "Failed to place order. Please try again.";
            header("Location: /zenithco/public/index.php?page=checkout");
            exit();
        }
        
    } catch (Exception $e) {
        debugLog("EXCEPTION creating order: " . $e->getMessage());
        debugLog("Exception trace: " . $e->getTraceAsString());
        $_SESSION['error'] = "An error occurred while placing your order: " . $e->getMessage();
        header("Location: /zenithco/public/index.php?page=checkout");
        exit();
    }
}

/**
 * Show order success page
 */
function showOrderSuccess() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    debugLog("showOrderSuccess() called");
    
    if (!isset($_SESSION['user_id'])) {
        debugLog("User not logged in for order success page");
        header("Location: /zenithco/public/index.php?page=user_login");
        exit();
    }
    
    $orderId = $_GET['order_id'] ?? null;
    $userId = $_SESSION['user_id'];
    
    debugLog("Loading success page for order: $orderId, user: $userId");
    
    if (!$orderId) {
        debugLog("ERROR: No order ID provided");
        $_SESSION['error'] = "Invalid order ID";
        header("Location: /zenithco/public/index.php?page=user_orders");
        exit();
    }
    
    $order = getOrderById($orderId, $userId);
    $items = getOrderItems($orderId);
    
    debugLog("Order data loaded - Order found: " . ($order ? "YES" : "NO") . ", Items count: " . count($items));
    
    if (!$order) {
        debugLog("ERROR: Order not found for ID: $orderId");
        $_SESSION['error'] = "Order not found";
        header("Location: /zenithco/public/index.php?page=user_orders");
        exit();
    }
    
    debugLog("Including order success page");
    include __DIR__ . '/../views/customer/order_success.php';
}

/**
 * Show user orders
 */
function showUserOrders() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    debugLog("showUserOrders() called");
    
    if (!isset($_SESSION['user_id'])) {
        debugLog("User not logged in for orders page");
        $_SESSION['error'] = "Please login to view your orders";
        header("Location: /zenithco/public/index.php?page=user_login");
        exit();
    }
    
    $userId = $_SESSION['user_id'];
    $orders = getUserOrders($userId);
    
    debugLog("Retrieved " . count($orders) . " orders for user: $userId");
    
    include __DIR__ . '/../views/customer/user_orders.php';
}

/**
 * Show order details for user
 */
function showUserOrderDetails($orderId) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    debugLog("showUserOrderDetails() called for order: $orderId");
    
    if (!isset($_SESSION['user_id'])) {
        debugLog("User not logged in for order details");
        $_SESSION['error'] = "Please login to view order details";
        header("Location: /zenithco/public/index.php?page=user_login");
        exit();
    }
    
    $userId = $_SESSION['user_id'];
    $order = getOrderById($orderId, $userId);
    $items = getOrderItems($orderId);
    
    debugLog("Order details loaded - Order: " . ($order ? "FOUND" : "NOT FOUND") . ", Items: " . count($items));
    
    if (!$order) {
        debugLog("ERROR: Order not found: $orderId");
        $_SESSION['error'] = "Order not found";
        header("Location: /zenithco/public/index.php?page=user_orders");
        exit();
    }
    
    include __DIR__ . '/../views/customer/order_details.php';
}

/**
 * Show admin orders
 */
function showAllOrders() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    debugLog("showAllOrders() called (admin)");
    
    if (!isset($_SESSION['admin_logged_in'])) {
        debugLog("Admin not logged in");
        header("Location: /zenithco/public/index.php?page=admin_login");
        exit();
    }
    
    $orders = getAllOrders();
    debugLog("Retrieved " . count($orders) . " orders for admin");
    
    include __DIR__ . '/../views/admin/orders_list.php';
}

/**
 * Show admin order details
 */
function showAdminOrderDetails($orderId) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    debugLog("showAdminOrderDetails() called for order: $orderId");
    
    if (!isset($_SESSION['admin_logged_in'])) {
        debugLog("Admin not logged in");
        header("Location: /zenithco/public/index.php?page=admin_login");
        exit();
    }
    
    $order = getOrderById($orderId);
    $items = getOrderItems($orderId);
    
    debugLog("Admin order details - Order: " . ($order ? "FOUND" : "NOT FOUND") . ", Items: " . count($items));
    
    if (!$order) {
        debugLog("ERROR: Order not found for admin: $orderId");
        $_SESSION['error'] = "Order not found";
        header("Location: /zenithco/public/index.php?page=manage_orders");
        exit();
    }
    
    include __DIR__ . '/../views/admin/order_details.php';
}

/**
 * Handle order status update (admin)
 */
function handleOrderStatusUpdate($orderId) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    debugLog("handleOrderStatusUpdate() called for order: $orderId");
    
    if (!isset($_SESSION['admin_logged_in'])) {
        debugLog("Admin not logged in for status update");
        header("Location: /zenithco/public/index.php?page=admin_login");
        exit();
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['status'])) {
        $newStatus = $_POST['status'];
        $validStatuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
        
        debugLog("Updating order $orderId status to: $newStatus");
        
        if (in_array($newStatus, $validStatuses)) {
            if (updateOrderStatus($orderId, $newStatus)) {
                debugLog("Status update successful");
                $_SESSION['success'] = "Order status updated successfully";
            } else {
                debugLog("Status update failed");
                $_SESSION['error'] = "Failed to update order status";
            }
        } else {
            debugLog("Invalid status: $newStatus");
            $_SESSION['error'] = "Invalid status";
        }
    }
    
    header("Location: /zenithco/public/index.php?page=order_details&id=$orderId");
    exit();
}

/**
 * Generate PDF receipt
 */
function generatePDFReceipt($orderId) {
    if (session_status() === PHP_SESSION_NONE) session_start();
    
    debugLog("generatePDFReceipt() called for order: $orderId");
    
    if (!isset($_SESSION['user_id'])) {
        debugLog("User not logged in for PDF generation");
        header("Location: /zenithco/public/index.php?page=user_login");
        exit();
    }
    
    $userId = $_SESSION['user_id'];
    $order = getOrderById($orderId, $userId);
    $items = getOrderItems($orderId);
    
    debugLog("PDF generation - Order: " . ($order ? "FOUND" : "NOT FOUND") . ", Items: " . count($items));
    
    if (!$order) {
        debugLog("ERROR: Order not found for PDF: $orderId");
        $_SESSION['error'] = "Order not found";
        header("Location: /zenithco/public/index.php?page=user_orders");
        exit();
    }
    
    // Set PDF headers
    header('Content-Type: text/html; charset=utf-8');
    header('Content-Disposition: inline; filename="ZenithCo_Order_' . $orderId . '.html"');
    
    debugLog("Generating PDF content");
    
    // Generate PDF content
    generateOrderPDF($order, $items);
    exit();
}

/**
 * Generate PDF content (simple HTML to PDF)
 */
function generateOrderPDF($order, $items) {
    debugLog("generateOrderPDF() called");
    
    // Simple HTML to PDF conversion
    ob_start();
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Order Receipt - ZenithCo</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px; }
            .company-name { font-size: 24px; font-weight: bold; color: #333; }
            .order-info { margin: 20px 0; }
            .order-info table { width: 100%; border-collapse: collapse; }
            .order-info th, .order-info td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
            .items-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            .items-table th, .items-table td { padding: 12px; text-align: left; border: 1px solid #ddd; }
            .items-table th { background-color: #f5f5f5; }
            .total { font-size: 18px; font-weight: bold; text-align: right; margin-top: 20px; }
            .footer { margin-top: 40px; text-align: center; font-size: 12px; color: #666; }
        </style>
    </head>
    <body>
        <div class="header">
            <div class="company-name">ZenithCo Jewelry</div>
            <p>Premium Jewelry Collection</p>
        </div>
        
        <div class="order-info">
            <h2>Order Receipt</h2>
            <table>
                <tr><th>Order ID:</th><td>#<?= $order['id'] ?></td></tr>
                <tr><th>Date:</th><td><?= date('F j, Y g:i A', strtotime($order['created_at'])) ?></td></tr>
                <tr><th>Status:</th><td><?= ucfirst($order['status']) ?></td></tr>
                <tr><th>Customer:</th><td><?= htmlspecialchars($order['customer_name']) ?></td></tr>
                <tr><th>Email:</th><td><?= htmlspecialchars($order['customer_email']) ?></td></tr>
                <tr><th>Phone:</th><td><?= htmlspecialchars($order['customer_phone']) ?></td></tr>
                <tr><th>Address:</th><td><?= htmlspecialchars($order['shipping_address'] . ', ' . $order['city'] . ' ' . $order['postal_code']) ?></td></tr>
                <tr><th>Payment:</th><td><?= ucfirst($order['payment_method']) ?></td></tr>
            </table>
        </div>
        
        <h3>Order Items</h3>
        <table class="items-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item['product_name']) ?></td>
                    <td><?= $item['quantity'] ?></td>
                    <td>LKR <?= number_format($item['price'], 2) ?></td>
                    <td>LKR <?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div class="total">
            <p>Total Amount: LKR <?= number_format($order['total_amount'], 2) ?></p>
        </div>
        
        <div class="footer">
            <p>Thank you for your business!</p>
            <p>ZenithCo Jewelry - Premium Collection</p>
            <p>Generated on <?= date('F j, Y g:i A') ?></p>
        </div>
    </body>
    </html>
    <?php
    
    $html = ob_get_clean();
    
    debugLog("PDF HTML generated, outputting content");
    
    // For a real PDF, you'd use a library like TCPDF or DOMPDF
    // For now, we'll output HTML that browsers can print as PDF
    echo $html;
}