<?php include __DIR__ . '/../layout/layout.php'; ?>

<div class="min-h-screen bg-ivory px-4 py-10">
  <div class="max-w-7xl mx-auto">
    <div class="flex justify-between items-center mb-8">
      <h2 class="text-3xl font-display text-navy">Delete Products</h2>
      <a href="/zenithco/public/index.php?page=admin_dashboard"
         class="bg-navy text-white px-4 py-2 rounded hover:bg-essence transition">
         ← Back to Dashboard
      </a>
    </div>

    <?php if (isset($_SESSION['success'])): ?>
      <div class="bg-green-100 text-green-800 p-4 rounded mb-4"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php elseif (isset($_SESSION['error'])): ?>
      <div class="bg-red-100 text-red-800 p-4 rounded mb-4"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <form method="POST" action="/zenithco/public/index.php?page=delete_products">
      <div class="overflow-x-auto">
        <table class="min-w-full bg-white text-sm border border-ether rounded-lg">
          <thead class="bg-mist text-essence uppercase text-xs">
            <tr>
              <th class="px-4 py-3 text-left"><input type="checkbox" id="selectAll"></th>
              <th class="px-4 py-3 text-left">Image</th>
              <th class="px-4 py-3 text-left">Name</th>
              <th class="px-4 py-3 text-left">Price</th>
              <th class="px-4 py-3 text-left">Stock</th>
              <th class="px-4 py-3 text-left">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($products as $product): ?>
              <tr class="border-t border-ether">
                <td class="px-4 py-3">
                  <input type="checkbox" name="selected_products[]" value="<?= $product['id'] ?>">
                </td>
                <td class="px-4 py-3"><img src="<?= $product['image'] ?>" class="h-12 w-12 object-cover rounded"></td>
                <td class="px-4 py-3"><?= htmlspecialchars($product['name']) ?></td>
                <td class="px-4 py-3">Rs. <?= number_format($product['price'], 2) ?></td>
                <td class="px-4 py-3"><?= (int)$product['stock'] ?></td>
                <td class="px-4 py-3">
                  <a href="/zenithco/public/index.php?page=delete_product&id=<?= $product['id'] ?>"
                     onclick="return confirm('Delete this product?')"
                     class="inline-block bg-red-600 text-white px-3 py-1 rounded hover:bg-red-800 transition text-xs">
                     Delete
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div class="mt-6">
        <button type="submit"
                class="bg-red-700 hover:bg-red-800 text-white px-6 py-3 rounded-lg transition">
          Delete Selected
        </button>
      </div>
    </form>
  </div>
</div>

<script>
  document.getElementById('selectAll').addEventListener('change', function () {
    const checkboxes = document.querySelectorAll('input[type="checkbox"][name="selected_products[]"]');
    for (let checkbox of checkboxes) {
      checkbox.checked = this.checked;
    }
  });
</script>

<?php include __DIR__ . '/../layout/footer.php'; ?>
