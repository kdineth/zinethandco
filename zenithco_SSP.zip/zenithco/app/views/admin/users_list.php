<?php include __DIR__ . '/../layout/adminheader.php'; ?>

<div class="min-h-screen bg-ivory px-4 py-10">
  <div class="max-w-7xl mx-auto">
    <div class="flex justify-between items-center mb-8">
      <h2 class="text-3xl font-display text-navy">Registered Users</h2>
      <a href="/zenithco/public/index.php?page=admin_dashboard"
         class="bg-navy text-white px-6 py-3 rounded-lg hover:bg-essence transition-colors duration-200 flex items-center">
         <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
           <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
         </svg>
         Back to Dashboard
      </a>
    </div>

    <?php if (empty($users)): ?>
      <div class="bg-white border border-ether rounded-lg p-12 text-center">
        <div class="w-16 h-16 bg-ghost rounded-full flex items-center justify-center mx-auto mb-4">
          <svg class="w-8 h-8 text-steel" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"/>
          </svg>
        </div>
        <h3 class="text-xl font-semibold text-essence mb-2">No Users Yet</h3>
        <p class="text-essence/70 text-sm">No users have registered yet. They will appear here once they sign up.</p>
      </div>
    <?php else: ?>
      <div class="bg-white border border-ether rounded-lg shadow-soft overflow-hidden">
        <!-- Desktop Table -->
        <div class="hidden md:block overflow-x-auto">
          <table class="min-w-full text-sm">
            <thead class="bg-mist">
              <tr>
                <th class="px-6 py-4 text-left font-semibold text-essence uppercase tracking-wider">#</th>
                <th class="px-6 py-4 text-left font-semibold text-essence uppercase tracking-wider">Profile</th>
                <th class="px-6 py-4 text-left font-semibold text-essence uppercase tracking-wider">Name</th>
                <th class="px-6 py-4 text-left font-semibold text-essence uppercase tracking-wider">Email</th>
                <th class="px-6 py-4 text-left font-semibold text-essence uppercase tracking-wider">Registered</th>
                <th class="px-6 py-4 text-left font-semibold text-essence uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-ether">
              <?php foreach ($users as $index => $user): ?>
                <tr class="hover:bg-ghost/50 transition-colors duration-150">
                  <td class="px-6 py-4 font-medium text-charcoal"><?= $index + 1 ?></td>
                  <td class="px-6 py-4">
                    <?php if (!empty($user['profile_image'])): ?>
                      <img src="<?= htmlspecialchars($user['profile_image']) ?>" 
                           alt="<?= htmlspecialchars($user['name']) ?>"
                           class="h-12 w-12 rounded-full object-cover border-2 border-silver">
                    <?php else: ?>
                      <div class="h-12 w-12 rounded-full bg-gradient-to-br from-primary/20 to-primary/40 flex items-center justify-center border-2 border-silver">
                        <span class="text-lg font-semibold text-primary">
                          <?= strtoupper(substr($user['name'] ?? '?', 0, 1)) ?>
                        </span>
                      </div>
                    <?php endif; ?>
                  </td>
                  <td class="px-6 py-4 text-charcoal">
                    <div class="font-medium"><?= htmlspecialchars($user['name']) ?></div>
                    <div class="text-sm text-storm">User ID: <?= $user['id'] ?></div>
                  </td>
                  <td class="px-6 py-4 text-charcoal">
                    <?= htmlspecialchars($user['email']) ?>
                  </td>
                  <td class="px-6 py-4 text-storm">
                    <div><?= date('M d, Y', strtotime($user['created_at'])) ?></div>
                    <div class="text-xs"><?= date('g:i A', strtotime($user['created_at'])) ?></div>
                  </td>
                  <td class="px-6 py-4">
                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800 border border-green-200">
                      <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 8 8">
                        <circle cx="4" cy="4" r="3"/>
                      </svg>
                      Active
                    </span>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <!-- Mobile Cards -->
        <div class="md:hidden divide-y divide-ether">
          <?php foreach ($users as $index => $user): ?>
            <div class="p-6">
              <div class="flex items-center space-x-4">
                <div>
                  <?php if (!empty($user['profile_image'])): ?>
                    <img src="<?= htmlspecialchars($user['profile_image']) ?>" 
                         alt="<?= htmlspecialchars($user['name']) ?>"
                         class="h-12 w-12 rounded-full object-cover border-2 border-silver">
                  <?php else: ?>
                    <div class="h-12 w-12 rounded-full bg-gradient-to-br from-primary/20 to-primary/40 flex items-center justify-center border-2 border-silver">
                      <span class="text-lg font-semibold text-primary">
                        <?= strtoupper(substr($user['name'] ?? '?', 0, 1)) ?>
                      </span>
                    </div>
                  <?php endif; ?>
                </div>
                <div class="flex-1">
                  <div class="flex justify-between items-center">
                    <h3 class="text-charcoal font-medium truncate"><?= htmlspecialchars($user['name']) ?></h3>
                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      Active
                    </span>
                  </div>
                  <p class="text-sm text-storm truncate"><?= htmlspecialchars($user['email']) ?></p>
                  <div class="flex justify-between mt-1 text-xs text-storm">
                    <span>ID: <?= $user['id'] ?></span>
                    <span><?= date('M d, Y', strtotime($user['created_at'])) ?></span>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>

        <!-- Table Footer -->
        <div class="bg-ghost px-6 py-4 border-t border-ether text-sm text-storm flex justify-between">
          <div>
            Total: <span class="text-charcoal font-medium"><?= count($users) ?></span> registered users
          </div>
          <div>
            Last updated: <?= date('M d, Y g:i A') ?>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php include __DIR__ . '/../layout/adminfooter.php'; ?>
