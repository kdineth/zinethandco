<?php include __DIR__ . '/../layout/userheader.php'; ?>

<main class="min-h-screen bg-pure flex items-center justify-center py-24 px-4">
  <div class="w-full max-w-xl bg-white border border-silver shadow-lg rounded-xl p-8">
    <h2 class="text-2xl font-display text-charcoal text-center mb-6">Create a New Account</h2>

    <?php if (isset($_SESSION['error'])): ?>
      <div class="bg-error/10 border border-error/30 text-error px-4 py-3 rounded-lg mb-4">
        <div class="flex items-center">
          <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
          </svg>
          <?= htmlspecialchars($_SESSION['error']); ?>
        </div>
      </div>
      <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['success'])): ?>
      <div class="bg-success/10 border border-success/30 text-success px-4 py-3 rounded-lg mb-4">
        <div class="flex items-center">
          <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
          </svg>
          <?= htmlspecialchars($_SESSION['success']); ?>
        </div>
      </div>
      <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <form method="POST" action="/zenithco/public/index.php?page=user_register" enctype="multipart/form-data" class="space-y-6">
      <div>
        <label for="name" class="block text-sm font-medium text-charcoal mb-1">Full Name *</label>
        <input type="text" name="name" id="name" required
               value="<?= isset($_SESSION['form_data']['name']) ? htmlspecialchars($_SESSION['form_data']['name']) : '' ?>"
               class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-colors">
      </div>

      <div>
        <label for="email" class="block text-sm font-medium text-charcoal mb-1">Email Address *</label>
        <input type="email" name="email" id="email" required
               value="<?= isset($_SESSION['form_data']['email']) ? htmlspecialchars($_SESSION['form_data']['email']) : '' ?>"
               class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-colors">
      </div>

      <div>
        <label for="phone" class="block text-sm font-medium text-charcoal mb-1">Phone Number</label>
        <input type="tel" name="phone" id="phone"
               value="<?= isset($_SESSION['form_data']['phone']) ? htmlspecialchars($_SESSION['form_data']['phone']) : '' ?>"
               class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-colors">
      </div>

      <div>
        <label for="password" class="block text-sm font-medium text-charcoal mb-1">Password *</label>
        <div class="relative">
          <input type="password" name="password" id="password" required minlength="6"
                 class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-colors">
          <button type="button" onclick="togglePassword('password')" class="absolute right-3 top-1/2 transform -translate-y-1/2 text-steel hover:text-charcoal">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" id="password-icon">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
            </svg>
          </button>
        </div>
        <p class="text-xs text-steel mt-1">Minimum 6 characters</p>
      </div>

      <div>
        <label for="confirm_password" class="block text-sm font-medium text-charcoal mb-1">Confirm Password *</label>
        <div class="relative">
          <input type="password" name="confirm_password" id="confirm_password" required minlength="6"
                 class="w-full px-4 py-3 border border-silver rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-colors">
          <button type="button" onclick="togglePassword('confirm_password')" class="absolute right-3 top-1/2 transform -translate-y-1/2 text-steel hover:text-charcoal">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" id="confirm_password-icon">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
            </svg>
          </button>
        </div>
      </div>

      <div>
        <label for="profile_image" class="block text-sm font-medium text-charcoal mb-1">Profile Picture (Optional)</label>
        <input type="file" name="profile_image" id="profile_image" accept="image/jpeg,image/png,image/jpg"
               class="w-full px-4 py-2 border border-silver rounded-lg text-sm bg-ghost file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-primary file:text-pure hover:file:bg-primary_dark transition-colors">
        <p class="text-xs text-steel mt-1">JPG, PNG or JPEG (Max: 2MB)</p>
      </div>

      <div class="flex items-center">
        <input type="checkbox" name="terms" id="terms" required
               class="w-4 h-4 text-primary focus:ring-primary border-silver rounded">
        <label for="terms" class="ml-2 text-sm text-charcoal">
          I agree to the <a href="#" class="text-primary hover:underline">Terms of Service</a> and 
          <a href="#" class="text-primary hover:underline">Privacy Policy</a> *
        </label>
      </div>

      <button type="submit" name="register"
              class="w-full bg-primary text-pure font-semibold py-3 rounded-lg hover:bg-primary_dark transition-colors duration-200 shadow-soft hover:shadow-primary">
        Create Account
      </button>

      <div class="text-center">
        <p class="text-sm text-storm">
          Already have an account?
          <a href="/zenithco/public/index.php?page=user_login" class="text-primary hover:underline font-medium">Sign in here</a>
        </p>
      </div>
    </form>
  </div>
</main>

<script>
function togglePassword(fieldId) {
  const field = document.getElementById(fieldId);
  const icon = document.getElementById(fieldId + '-icon');
  
  if (field.type === 'password') {
    field.type = 'text';
    icon.innerHTML = `
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L3 3m6.878 6.878L21 21"></path>
    `;
  } else {
    field.type = 'password';
    icon.innerHTML = `
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
    `;
  }
}

// Clear form data from session after display
<?php if (isset($_SESSION['form_data'])) unset($_SESSION['form_data']); ?>
</script>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>