<?php
require_once __DIR__ . '/../../config/database.php';

/**
 * Register a new user in the database.
 */
function registerUser($name, $email, $hashedPassword, $profileImage = null) {
    global $pdo;
    
    try {
        error_log("[USER_MODEL] Attempting to register user: $email");
        
        $stmt = $pdo->prepare("INSERT INTO users (name, email, password, profile_image, role, is_active, login_count, created_at) VALUES (?, ?, ?, ?, 'user', 1, 0, NOW())");
        $result = $stmt->execute([$name, $email, $hashedPassword, $profileImage]);
        
        if ($result) {
            error_log("[USER_MODEL] User registered successfully: $email");
        } else {
            error_log("[USER_MODEL] Failed to register user: $email");
            error_log("[USER_MODEL] Error info: " . print_r($stmt->errorInfo(), true));
        }
        
        return $result;
        
    } catch (PDOException $e) {
        error_log("[USER_MODEL] Database error in registerUser: " . $e->getMessage());
        error_log("[USER_MODEL] SQL State: " . $e->getCode());
        throw new Exception("Database error: " . $e->getMessage());
    }
}

/**
 * Get all users (admin panel use).
 */
function getAllUsers() {
    global $pdo;
    
    try {
        $stmt = $pdo->query("SELECT * FROM users ORDER BY created_at DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("[USER_MODEL] Database error in getAllUsers: " . $e->getMessage());
        return [];
    }
}

/**
 * Retrieve a user by their email address.
 */
function getUserByEmail($email) {
    global $pdo;
    
    try {
        error_log("[USER_MODEL] Looking up user by email: $email");
        
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            error_log("[USER_MODEL] User found: " . $user['name']);
        } else {
            error_log("[USER_MODEL] No user found with email: $email");
        }
        
        return $user;
        
    } catch (PDOException $e) {
        error_log("[USER_MODEL] Database error in getUserByEmail: " . $e->getMessage());
        return false;
    }
}

/**
 * Check if an email already exists in the database.
 */
function emailExists($email) {
    return getUserByEmail($email) !== false;
}

/**
 * Update user profile data.
 */
function updateUser($email, $name, $profileImage = null) {
    global $pdo;
    
    try {
        if ($profileImage) {
            $stmt = $pdo->prepare("UPDATE users SET name = ?, profile_image = ? WHERE email = ?");
            return $stmt->execute([$name, $profileImage, $email]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET name = ? WHERE email = ?");
            return $stmt->execute([$name, $email]);
        }
    } catch (PDOException $e) {
        error_log("[USER_MODEL] Database error in updateUser: " . $e->getMessage());
        return false;
    }
}

/**
 * Test database connection
 */
function testDatabaseConnection() {
    global $pdo;
    
    try {
        $stmt = $pdo->query("SELECT 1");
        error_log("[USER_MODEL] Database connection test: SUCCESS");
        return true;
    } catch (PDOException $e) {
        error_log("[USER_MODEL] Database connection test: FAILED - " . $e->getMessage());
        return false;
    }
}


function getUserById($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
