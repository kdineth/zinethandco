<?php
include __DIR__ . '/../layout/userheader.php';
if (session_status() === PHP_SESSION_NONE) session_start();
?>

<main class="bg-ivory pt-32 pb-16 px-4 sm:px-8 min-h-screen">
  <div class="max-w-4xl mx-auto">
    
    <!-- Success Header -->
    <div class="text-center mb-12">
      <div class="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
        <svg class="w-10 h-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
        </svg>
      </div>
      <h1 class="text-4xl font-display text-essence mb-4">Order Confirmed!</h1>
      <p class="text-xl text-storm">Thank you for your purchase. Your order has been successfully placed.</p>
    </div>

    <!-- Order Details Card -->
    <?php if (isset($order) && $order): ?>
      <div class="bg-pure rounded-lg border border-mist shadow-soft p-8 mb-8">
        <div class="flex items-center justify-between mb-6">
          <h2 class="text-2xl font-semibold text-essence">Order Details</h2>
          <span class="bg-green-100 text-green-800 px-4 py-2 rounded-full text-sm font-medium">
            Order #<?= $order['id'] ?>
          </span>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div>
            <h3 class="text-lg font-medium text-essence mb-3">Order Information</h3>
            <div class="space-y-2 text-sm">
              <p><span class="text-storm">Order Date:</span> <span class="font-medium text-charcoal"><?= date('F j, Y g:i A', strtotime($order['created_at'])) ?></span></p>
              <p><span class="text-storm">Status:</span> <span class="font-medium text-green-600"><?= ucfirst($order['status']) ?></span></p>
              <p><span class="text-storm">Payment Method:</span> <span class="font-medium text-charcoal"><?= ucfirst($order['payment_method']) ?></span></p>
              <p><span class="text-storm">Total Amount:</span> <span class="font-bold text-primary text-lg">LKR <?= number_format($order['total_amount'], 2) ?></span></p>
            </div>
          </div>
          
          <div>
            <h3 class="text-lg font-medium text-essence mb-3">Shipping Information</h3>
            <div class="space-y-2 text-sm">
              <p><span class="text-storm">Name:</span> <span class="font-medium text-charcoal"><?= htmlspecialchars($order['customer_name']) ?></span></p>
              <p><span class="text-storm">Email:</span> <span class="font-medium text-charcoal"><?= htmlspecialchars($order['customer_email']) ?></span></p>
              <p><span class="text-storm">Phone:</span> <span class="font-medium text-charcoal"><?= htmlspecialchars($order['customer_phone']) ?></span></p>
              <p><span class="text-storm">Address:</span> <span class="font-medium text-charcoal"><?= htmlspecialchars($order['shipping_address']) ?></span></p>
              <p><span class="text-storm">City:</span> <span class="font-medium text-charcoal"><?= htmlspecialchars($order['city']) ?> <?= htmlspecialchars($order['postal_code']) ?></span></p>
            </div>
          </div>
        </div>

        <!-- Order Items -->
        <?php if (!empty($items)): ?>
          <div class="border-t border-mist pt-6">
            <h3 class="text-lg font-medium text-essence mb-4">Order Items</h3>
            <div class="space-y-4">
              <?php foreach ($items as $item): ?>
                <div class="flex items-center space-x-4 p-4 bg-ghost rounded-lg">
                  <div class="w-16 h-16 bg-pure rounded-lg overflow-hidden border border-silver">
                    <img src="<?= htmlspecialchars($item['image'] ?? '/zenithco/public/images/placeholder.jpg') ?>" 
                         alt="<?= htmlspecialchars($item['product_name']) ?>"
                         class="w-full h-full object-cover">
                  </div>
                  <div class="flex-1">
                    <h4 class="font-medium text-essence"><?= htmlspecialchars($item['product_name']) ?></h4>
                    <p class="text-sm text-storm">Quantity: <?= $item['quantity'] ?></p>
                  </div>
                  <div class="text-right">
                    <p class="font-medium text-essence">LKR <?= number_format($item['price'], 2) ?></p>
                    <p class="text-sm text-storm">Total: LKR <?= number_format($item['price'] * $item['quantity'], 2) ?></p>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <!-- Action Buttons -->
    <div class="flex flex-col sm:flex-row gap-4 justify-center">
      <?php if (isset($order)): ?>
        <a href="/zenithco/public/index.php?page=download_receipt&order_id=<?= $order['id'] ?>" 
           class="inline-flex items-center justify-center px-8 py-4 bg-primary text-white font-semibold rounded-lg hover:bg-primary_dark transition-colors">
          <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
          </svg>
          Download Receipt
        </a>
      <?php endif; ?>
      
      <a href="/zenithco/public/index.php?page=user_orders" 
         class="inline-flex items-center justify-center px-8 py-4 border-2 border-silver text-charcoal font-semibold rounded-lg hover:border-primary hover:text-primary transition-colors">
        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v6a2 2 0 002 2h2m0-8v8m0-8h8m-8 0V3a2 2 0 012-2h4a2 2 0 012 2v2m-6 8h8a2 2 0 002-2V9a2 2 0 00-2-2h-8m0 0V3"/>
        </svg>
        View All Orders
      </a>
      
      <a href="/zenithco/public/index.php?page=user_products" 
         class="inline-flex items-center justify-center px-8 py-4 border-2 border-silver text-charcoal font-semibold rounded-lg hover:border-primary hover:text-primary transition-colors">
        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
        </svg>
        Continue Shopping
      </a>
    </div>

    <!-- What's Next Section -->
    <div class="mt-12 bg-pure rounded-lg border border-mist p-8">
      <h3 class="text-xl font-semibold text-essence mb-4">What happens next?</h3>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="text-center">
          <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
            </svg>
          </div>
          <h4 class="font-medium text-essence mb-2">Order Confirmation</h4>
          <p class="text-sm text-storm">You'll receive an email confirmation shortly with your order details.</p>
        </div>
        
        <div class="text-center">
          <div class="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 7.172V5L8 4z"/>
            </svg>
          </div>
          <h4 class="font-medium text-essence mb-2">Processing</h4>
          <p class="text-sm text-storm">Our team will carefully prepare and package your jewelry items.</p>
        </div>
        
        <div class="text-center">
          <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
            </svg>
          </div>
          <h4 class="font-medium text-essence mb-2">Shipping</h4>
          <p class="text-sm text-storm">Your order will be shipped and you'll receive tracking information.</p>
        </div>
      </div>
    </div>
  </div>
</main>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>