<?php
include __DIR__ . '/../layout/userheader.php';
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: /zenithco/public/index.php?page=user_login");
    exit;
}
?>

<main class="pt-24 pb-20 bg-ghost min-h-screen">
  <!-- Breadcrumb -->
  <section class="py-6 bg-pure border-b border-silver">
    <div class="max-w-7xl mx-auto px-6">
      <nav class="flex items-center space-x-2 text-sm">
        <a href="/zenithco/public/index.php?page=landing" class="text-steel hover:text-primary transition-colors">Home</a>
        <svg class="w-4 h-4 text-silver" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
        </svg>
        <a href="/zenithco/public/index.php?page=user_orders" class="text-steel hover:text-primary transition-colors">My Orders</a>
        <svg class="w-4 h-4 text-silver" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
        </svg>
        <span class="text-charcoal font-medium">Order Details</span>
      </nav>
    </div>
  </section>

  <div class="max-w-5xl mx-auto px-6 py-12">
    <!-- Header -->
    <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8">
      <div>
        <h1 class="text-4xl font-display text-charcoal mb-2">Order #<?= htmlspecialchars($order['id']) ?></h1>
        <p class="text-storm">Review your order details and track your items</p>
      </div>
      
      <div class="mt-4 lg:mt-0">
        <a href="/zenithco/public/index.php?page=user_orders"
           class="inline-flex items-center px-6 py-3 border-2 border-silver text-charcoal font-medium rounded-xl hover:border-primary hover:text-primary transition-colors duration-200">
          <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
          </svg>
          Back to Orders
        </a>
      </div>
    </div>

    <!-- Order Summary -->
    <div class="bg-pure border border-silver rounded-2xl p-8 mb-8 shadow-soft">
      <div class="flex items-center mb-6">
        <div class="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mr-3">
          <svg class="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v6a2 2 0 002 2h2m0-8v8m0-8h8m-8 0V3a2 2 0 012-2h4a2 2 0 012 2v2m-6 8h8a2 2 0 002-2V9a2 2 0 00-2-2h-8m0 0V3"></path>
          </svg>
        </div>
        <h2 class="text-2xl font-serif text-charcoal">Order Summary</h2>
      </div>
      
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-ghost rounded-xl p-6">
          <h3 class="text-sm font-medium text-charcoal mb-2">Status</h3>
          <?php
          $status = htmlspecialchars($order['status']);
          $statusClass = match(strtolower($status)) {
            'pending' => 'bg-warning/10 text-warning border-warning/30',
            'processing' => 'bg-info/10 text-info border-info/30',
            'shipped' => 'bg-primary/10 text-primary border-primary/30',
            'delivered' => 'bg-success/10 text-success border-success/30',
            'cancelled' => 'bg-error/10 text-error border-error/30',
            default => 'bg-steel/10 text-steel border-steel/30'
          };
          ?>
          <span class="inline-flex items-center px-4 py-2 rounded-lg text-lg font-medium border <?= $statusClass ?>">
            <?= ucfirst($status) ?>
          </span>
        </div>
        
        <div class="bg-ghost rounded-xl p-6">
          <h3 class="text-sm font-medium text-charcoal mb-2">Order Date</h3>
          <p class="text-lg font-semibold text-charcoal"><?= date('M d, Y', strtotime($order['created_at'])) ?></p>
          <p class="text-sm text-storm"><?= date('g:i A', strtotime($order['created_at'])) ?></p>
        </div>
        
        <div class="bg-ghost rounded-xl p-6">
          <h3 class="text-sm font-medium text-charcoal mb-2">Total Amount</h3>
          <p class="text-2xl font-bold text-primary">LKR <?= number_format($order['total_amount'], 2) ?></p>
        </div>
      </div>
    </div>

    <!-- Order Items -->
    <?php if (!empty($items)): ?>
      <div class="bg-pure border border-silver rounded-2xl shadow-soft overflow-hidden mb-8">
        <div class="bg-ghost border-b border-silver p-6">
          <div class="flex items-center">
            <div class="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mr-3">
              <svg class="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
              </svg>
            </div>
            <h2 class="text-2xl font-serif text-charcoal">Order Items</h2>
          </div>
        </div>

        <!-- Desktop Table View -->
        <div class="hidden lg:block overflow-x-auto">
          <table class="min-w-full">
            <thead class="bg-ghost border-b border-silver">
              <tr>
                <th class="px-8 py-6 text-left font-semibold text-charcoal">Product</th>
                <th class="px-8 py-6 text-left font-semibold text-charcoal">Image</th>
                <th class="px-8 py-6 text-left font-semibold text-charcoal">Price</th>
                <th class="px-8 py-6 text-left font-semibold text-charcoal">Quantity</th>
                <th class="px-8 py-6 text-left font-semibold text-charcoal">Subtotal</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-silver">
              <?php foreach ($items as $item): ?>
                <tr class="hover:bg-ghost/50 transition-colors duration-200">
                  <td class="px-8 py-6">
                    <h3 class="font-medium text-charcoal"><?= htmlspecialchars($item['product_name']) ?></h3>
                  </td>
                  <td class="px-8 py-6">
                    <div class="w-20 h-20 rounded-xl overflow-hidden bg-ghost border border-silver">
                      <img src="<?= htmlspecialchars($item['image']) ?>" alt="Product Image" class="w-full h-full object-cover">
                    </div>
                  </td>
                  <td class="px-8 py-6">
                    <span class="font-medium text-charcoal">LKR <?= number_format($item['price'], 2) ?></span>
                  </td>
                  <td class="px-8 py-6">
                    <span class="inline-flex items-center justify-center w-8 h-8 bg-ghost rounded-lg font-medium text-charcoal">
                      <?= $item['quantity'] ?>
                    </span>
                  </td>
                  <td class="px-8 py-6">
                    <span class="font-semibold text-primary text-lg">LKR <?= number_format($item['price'] * $item['quantity'], 2) ?></span>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <!-- Mobile Card View -->
        <div class="lg:hidden divide-y divide-silver">
          <?php foreach ($items as $item): ?>
            <div class="p-6">
              <div class="flex space-x-4">
                <div class="w-20 h-20 rounded-xl overflow-hidden bg-ghost border border-silver flex-shrink-0">
                  <img src="<?= htmlspecialchars($item['image']) ?>" alt="Product Image" class="w-full h-full object-cover">
                </div>
                
                <div class="flex-1 space-y-3">
                  <h3 class="font-medium text-charcoal"><?= htmlspecialchars($item['product_name']) ?></h3>
                  
                  <div class="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span class="text-storm">Price:</span>
                      <span class="font-medium text-charcoal block">LKR <?= number_format($item['price'], 2) ?></span>
                    </div>
                    <div>
                      <span class="text-storm">Quantity:</span>
                      <span class="font-medium text-charcoal block"><?= $item['quantity'] ?></span>
                    </div>
                  </div>
                  
                  <div class="pt-2 border-t border-silver">
                    <span class="text-sm text-storm">Subtotal:</span>
                    <span class="font-semibold text-primary text-lg block">LKR <?= number_format($item['price'] * $item['quantity'], 2) ?></span>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php else: ?>
      <!-- Empty Items State -->
      <div class="bg-pure border border-silver rounded-2xl p-12 text-center shadow-soft">
        <div class="w-16 h-16 bg-ghost rounded-full flex items-center justify-center mx-auto mb-4">
          <svg class="w-8 h-8 text-steel" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path>
          </svg>
        </div>
        <h3 class="text-xl font-serif text-charcoal mb-2">No Items Found</h3>
        <p class="text-storm">No items found in this order.</p>
      </div>
    <?php endif; ?>

    <!-- Action Buttons -->
    <div class="flex flex-col sm:flex-row gap-4 justify-center">
      <a href="/zenithco/public/index.php?page=user_orders"
         class="inline-flex items-center justify-center px-8 py-4 bg-primary text-pure font-semibold rounded-xl hover:bg-primary_dark transition-colors duration-200 shadow-soft hover:shadow-primary">
        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
        </svg>
        Back to My Orders
      </a>
      
      <a href="/zenithco/public/index.php?page=user_products"
         class="inline-flex items-center justify-center px-8 py-4 border-2 border-silver text-charcoal font-semibold rounded-xl hover:border-primary hover:text-primary transition-colors duration-200">
        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13l-1.5 6h13l-1.5-6M10 21a1 1 0 100-2 1 1 0 000 2zm8 0a1 1 0 100-2 1 1 0 000 2z"></path>
        </svg>
        Continue Shopping
      </a>
    </div>
  </div>
</main>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>