<?php include __DIR__ . '/../layout/layout.php'; ?>

<div class="min-h-screen flex justify-center items-center bg-ivory px-4">
  <div class="w-full max-w-2xl bg-white border border-ether rounded-lg shadow p-10">
    <!-- Back to Dashboard -->
    <div class="mb-6">
      <a href="/zenithco/public/index.php?page=admin_dashboard"
         class="inline-block text-sm font-medium text-white bg-navy px-4 py-2 rounded-md hover:bg-essence transition">
        ← Back to Dashboard
      </a>
    </div>

    <!-- Title -->
    <h2 class="text-2xl font-serif text-navy mb-6">Add New Product</h2>

    <!-- Flash Messages -->
    <?php if (isset($_SESSION['success'])): ?>
      <div class="bg-green-100 text-green-800 p-4 rounded mb-4"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php elseif (isset($_SESSION['error'])): ?>
      <div class="bg-red-100 text-red-800 p-4 rounded mb-4"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <!-- Product Form -->
    <form method="POST" action="/zenithco/public/index.php?page=add_product"
          enctype="multipart/form-data" class="space-y-6">
      <div>
        <label class="block text-sm font-medium text-essence mb-1">Product Name</label>
        <input type="text" name="name" required
               class="w-full px-4 py-3 bg-ether border border-ether rounded-md">
      </div>
      <div>
        <label class="block text-sm font-medium text-essence mb-1">Price (LKR)</label>
        <input type="number" name="price" step="0.01" required
               class="w-full px-4 py-3 bg-ether border border-ether rounded-md">
      </div>
      <div>
        <label class="block text-sm font-medium text-essence mb-1">Description</label>
        <textarea name="description" rows="4"
                  class="w-full px-4 py-3 bg-ether border border-ether rounded-md"></textarea>
      </div>
      <div>
        <label class="block text-sm font-medium text-essence mb-1">Upload Product Image</label>
        <input type="file" name="image" accept="image/*" required
               class="w-full px-4 py-2 border border-ether bg-ether rounded-md">
      </div>
      <div>
        <label class="block text-sm font-medium text-essence mb-1">Stock</label>
        <input type="number" name="stock" required
               class="w-full px-4 py-3 bg-ether border border-ether rounded-md">
      </div>

      <!-- Submit -->
      <button type="submit"
              class="bg-ember hover:bg-essence text-white px-6 py-3 rounded-lg transition">
        Add Product
      </button>
    </form>
  </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
