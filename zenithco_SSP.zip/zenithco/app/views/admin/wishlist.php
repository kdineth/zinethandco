<?php
require_once __DIR__ . '/../../config/database.php';

function getAdminWishlistItems() {
    global $pdo;

    $query = "
        SELECT 
            w.id,
            w.created_at AS added_on,
            u.name AS user_name,
            u.email AS user_email,
            p.name AS product_name,
            p.price AS product_price
        FROM whishlist w
        JOIN users u ON w.user_id = u.id
        JOIN products p ON w.product_id = p.id
        ORDER BY w.created_at DESC
    ";

    return $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);
}
