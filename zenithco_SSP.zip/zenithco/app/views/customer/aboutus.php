<?php
include __DIR__ . '/../layout/userheader.php';
?>

<main class="bg-pure pt-24">

  <!-- Hero Section -->
  <section class="py-20 bg-ghost">
    <div class="max-w-4xl mx-auto px-6 text-center">
      <h1 class="text-5xl font-display text-charcoal mb-6">Our Story</h1>
      <p class="text-xl text-storm leading-relaxed">
        For over three decades, Zenith & Co has been crafting exceptional jewelry that combines traditional artistry with contemporary elegance. Every piece tells a story of passion, precision, and unwavering commitment to excellence.
      </p>
    </div>
  </section>

  <!-- Heritage Section -->
  <section class="py-20 bg-pure">
    <div class="max-w-7xl mx-auto px-6">
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div>
          <img src="/zenithco/public/images/ourheritage.jpg" alt="Our Heritage" 
               class="w-full h-96 object-cover rounded-lg">
        </div>
        
        <div class="space-y-6">
          <p class="text-primary text-sm font-semibold uppercase tracking-wide">Established 1987</p>
          <h2 class="text-4xl font-display text-charcoal">A Legacy of Excellence</h2>
          <div class="space-y-4 text-storm leading-relaxed">
            <p>
              Founded in 1987 by master craftsman Alexander Zenith, our company began as a small workshop in the heart of Colombo. With a vision to create jewelry that transcends time and trends, Alexander established the foundation of what would become Sri Lanka's premier luxury jewelry house.
            </p>
            <p>
              From our humble beginnings, we have grown into a respected name in the jewelry industry, known for our meticulous attention to detail, exceptional craftsmanship, and commitment to using only the finest materials.
            </p>
            <p>
              Today, we continue to honor Alexander's legacy while embracing innovation and contemporary design, ensuring that each piece we create becomes a treasured heirloom for generations to come.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Values Section -->
  <section class="py-20 bg-ghost">
    <div class="max-w-7xl mx-auto px-6">
      <div class="text-center mb-16">
        <h2 class="text-4xl font-display text-charcoal mb-6">Our Values</h2>
        <p class="text-xl text-storm max-w-3xl mx-auto">
          These core principles guide everything we do, from selecting the finest materials to delivering exceptional customer service.
        </p>
      </div>
      
      <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div class="text-center p-8 bg-pure rounded-lg border border-silver">
          <div class="w-16 h-16 bg-ghost rounded-lg flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"></path>
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-charcoal mb-4">Exceptional Craftsmanship</h3>
          <p class="text-storm leading-relaxed">
            Every piece is meticulously handcrafted by our master artisans using time-honored techniques passed down through generations.
          </p>
        </div>
        
        <div class="text-center p-8 bg-pure rounded-lg border border-silver">
          <div class="w-16 h-16 bg-ghost rounded-lg flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-charcoal mb-4">Ethical Sourcing</h3>
          <p class="text-storm leading-relaxed">
            We are committed to responsible sourcing practices, ensuring our materials are ethically obtained and environmentally sustainable.
          </p>
        </div>
        
        <div class="text-center p-8 bg-pure rounded-lg border border-silver">
          <div class="w-16 h-16 bg-ghost rounded-lg flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-charcoal mb-4">Customer Dedication</h3>
          <p class="text-storm leading-relaxed">
            Our customers are at the heart of everything we do. We strive to exceed expectations and build lasting relationships.
          </p>
        </div>
      </div>
    </div>
  </section>


  <!-- Stats Section -->
  <section class="py-20 bg-ghost">
    <div class="max-w-7xl mx-auto px-6">
      <div class="text-center mb-12">
        <h2 class="text-4xl font-display text-charcoal mb-6">Our Impact</h2>
        <p class="text-xl text-storm">Numbers that reflect our commitment to excellence</p>
      </div>
      
      <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
        <div class="p-6">
          <p class="text-4xl font-bold text-primary mb-2">37+</p>
          <p class="text-storm font-medium">Years of Excellence</p>
        </div>
        <div class="p-6">
          <p class="text-4xl font-bold text-primary mb-2">10,000+</p>
          <p class="text-storm font-medium">Satisfied Customers</p>
        </div>
        <div class="p-6">
          <p class="text-4xl font-bold text-primary mb-2">500+</p>
          <p class="text-storm font-medium">Unique Designs</p>
        </div>
        <div class="p-6">
          <p class="text-4xl font-bold text-primary mb-2">50+</p>
          <p class="text-storm font-medium">Awards Won</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Sustainability Section -->
  <section class="py-20 bg-pure">
    <div class="max-w-7xl mx-auto px-6">
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div class="space-y-6">
          <p class="text-primary text-sm font-semibold uppercase tracking-wide">Sustainability</p>
          <h2 class="text-4xl font-display text-charcoal">Responsible Luxury</h2>
          <div class="space-y-4 text-storm leading-relaxed">
            <p>
              We believe that luxury should never come at the expense of our planet or its people. That's why we're committed to sustainable and ethical practices throughout our entire supply chain.
            </p>
            <p>
              From responsibly sourced materials to environmentally conscious manufacturing processes, we ensure that every piece of jewelry we create contributes to a better world.
            </p>
            <p>
              Our partnerships with certified suppliers and our investment in clean technologies demonstrate our ongoing commitment to responsible luxury.
            </p>
          </div>
          
          <div class="grid grid-cols-2 gap-6 pt-4">
            <div class="text-center p-4 bg-ghost rounded-lg border border-silver">
              <p class="text-2xl font-bold text-primary">100%</p>
              <p class="text-sm text-storm">Ethically Sourced</p>
            </div>
            <div class="text-center p-4 bg-ghost rounded-lg border border-silver">
              <p class="text-2xl font-bold text-primary">Carbon</p>
              <p class="text-sm text-storm">Neutral Operations</p>
            </div>
          </div>
        </div>
        
        <div>
          <img src="/zenithco/public/images/sustainability.jpg" alt="Sustainability" 
               class="w-full h-96 object-cover rounded-lg">
        </div>
      </div>
    </div>
  </section>

</main>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>