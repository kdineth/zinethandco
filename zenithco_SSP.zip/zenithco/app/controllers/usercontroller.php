<?php
require_once __DIR__ . '/../models/user.php';

// Add debugging to see what's happening
function debugLog($message) {
    error_log("[USER_CONTROLLER] " . $message);
    // Also display for immediate debugging (remove in production)
    echo "<!-- DEBUG: " . $message . " -->";
}

function showUserLogin() {
    debugLog("showUserLogin() called");
    include __DIR__ . '/../views/customer/user_login.php';
}

function handleUserLogin() {
    debugLog("handleUserLogin() called");
    debugLog("REQUEST_METHOD: " . $_SERVER['REQUEST_METHOD']);
    debugLog("POST data: " . print_r($_POST, true));
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        
        debugLog("Email: $email, Password length: " . strlen($password));

        // Add basic validation
        if (empty($email) || empty($password)) {
            if (session_status() === PHP_SESSION_NONE) session_start();
            $_SESSION['login_error'] = "Please fill in all fields.";
            $_SESSION['login_email'] = $email;
            header("Location: /zenithco/public/index.php?page=user_login");
            exit();
        }

        $user = getUserByEmail($email);
        debugLog("User found: " . ($user ? "Yes" : "No"));
        
        if ($user) {
            debugLog("Database password hash: " . substr($user['password'], 0, 20) . "...");
            debugLog("Password verify result: " . (password_verify($password, $user['password']) ? "TRUE" : "FALSE"));
        }
        
        if ($user && password_verify($password, $user['password'])) {
            if (session_status() === PHP_SESSION_NONE) session_start();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            debugLog("Login successful, redirecting to dashboard");
            header("Location: /zenithco/public/index.php?page=user_dashboard");
            exit();
        } else {
            if (session_status() === PHP_SESSION_NONE) session_start();
            $_SESSION['login_error'] = "Invalid email or password.";
            $_SESSION['login_email'] = $email;
            debugLog("Login failed, redirecting back to login");
            header("Location: /zenithco/public/index.php?page=user_login");
            exit();
        }
    } else {
        debugLog("Not a POST request");
    }
}

function showUserRegister() {
    debugLog("showUserRegister() called");
    include __DIR__ . '/../views/customer/user_register.php';
}

function handleUserRegister() {
    debugLog("handleUserRegister() called");
    debugLog("REQUEST_METHOD: " . $_SERVER['REQUEST_METHOD']);
    debugLog("POST data: " . print_r($_POST, true));
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = $_POST['name'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        debugLog("Name: $name, Email: $email, Password length: " . strlen($password));

        // Add basic validation
        if (empty($name) || empty($email) || empty($password)) {
            if (session_status() === PHP_SESSION_NONE) session_start();
            $_SESSION['register_error'] = "Please fill in all fields.";
            $_SESSION['register_name'] = $name;
            $_SESSION['register_email'] = $email;
            header("Location: /zenithco/public/index.php?page=user_register");
            exit();
        }

        if ($password !== $confirm_password) {
            if (session_status() === PHP_SESSION_NONE) session_start();
            $_SESSION['register_error'] = "Passwords do not match.";
            $_SESSION['register_name'] = $name;
            $_SESSION['register_email'] = $email;
            debugLog("Passwords don't match");
            header("Location: /zenithco/public/index.php?page=user_register");
            exit();
        }

        if (getUserByEmail($email)) {
            if (session_status() === PHP_SESSION_NONE) session_start();
            $_SESSION['register_error'] = "Email already exists.";
            $_SESSION['register_name'] = $name;
            $_SESSION['register_email'] = $email;
            debugLog("Email already exists");
            header("Location: /zenithco/public/index.php?page=user_register");
            exit();
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        debugLog("Attempting to register user with hashed password");
        
        try {
            $result = registerUser($name, $email, $hashedPassword);
            debugLog("Registration result: " . ($result ? "SUCCESS" : "FAILED"));
            
            if ($result) {
                if (session_status() === PHP_SESSION_NONE) session_start();
                $_SESSION['registration_success'] = "Registration successful! Please login.";
                header("Location: /zenithco/public/index.php?page=user_login");
                exit();
            } else {
                if (session_status() === PHP_SESSION_NONE) session_start();
                $_SESSION['register_error'] = "Registration failed. Please try again.";
                $_SESSION['register_name'] = $name;
                $_SESSION['register_email'] = $email;
                header("Location: /zenithco/public/index.php?page=user_register");
                exit();
            }
        } catch (Exception $e) {
            debugLog("Registration exception: " . $e->getMessage());
            if (session_status() === PHP_SESSION_NONE) session_start();
            $_SESSION['register_error'] = "Registration failed: " . $e->getMessage();
            $_SESSION['register_name'] = $name;
            $_SESSION['register_email'] = $email;
            header("Location: /zenithco/public/index.php?page=user_register");
            exit();
        }
    } else {
        debugLog("Not a POST request");
    }
}

function handleUserLogout() {
    debugLog("handleUserLogout() called");
    if (session_status() === PHP_SESSION_NONE) session_start();
    session_unset();
    session_destroy();
    header("Location: /zenithco/public/index.php?page=user_login");
    exit();
}

// Add these functions to your usercontroller.php

function showAllUsers() {
    // For admin to view all users
    if (!isset($_SESSION['admin_logged_in'])) {
        header("Location: /zenithco/public/index.php?page=admin_login");
        exit();
    }
    
    $users = getAllUsers();
    include __DIR__ . '/../views/admin/users_list.php';
}

function showUserProfile() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: /zenithco/public/index.php?page=user_login");
        exit();
    }
    
    include __DIR__ . '/../views/customer/user_profile.php';
}

function updateUserProfile() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: /zenithco/public/index.php?page=user_login");
        exit();
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Handle profile update logic here
        $name = $_POST['name'] ?? '';
        $email = $_SESSION['user_email'] ?? '';
        
        if (updateUser($email, $name)) {
            $_SESSION['success'] = "Profile updated successfully";
        } else {
            $_SESSION['error'] = "Failed to update profile";
        }
    }
    
    header("Location: /zenithco/public/index.php?page=user_profile");
    exit();
}