-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 28, 2025 at 09:23 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zenithco`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','processing','shipped','delivered','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_name` varchar(255) NOT NULL DEFAULT '',
  `customer_email` varchar(255) NOT NULL DEFAULT '',
  `customer_phone` varchar(50) NOT NULL DEFAULT '',
  `shipping_address` text DEFAULT NULL,
  `city` varchar(100) NOT NULL DEFAULT '',
  `postal_code` varchar(20) NOT NULL DEFAULT '',
  `payment_method` varchar(50) NOT NULL DEFAULT '',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total_amount`, `status`, `created_at`, `customer_name`, `customer_email`, `customer_phone`, `shipping_address`, `city`, `postal_code`, `payment_method`, `updated_at`) VALUES
(1, 5, 143000.00, 'pending', '2025-05-28 05:07:11', 'Dineth Kumarage', 'sk12@gmail.com', '0774230765', 'Adress number 1', 'weligalla', '20610', 'cod', '2025-05-28 05:07:11'),
(2, 5, 567000.00, 'pending', '2025-05-28 06:56:10', 'Dineth Kumarage', 'dnetsachintha@gmail.com', '0774230765', 'Adress number 1', 'weligalla', '20610', 'cod', '2025-05-28 06:56:10');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `product_name` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`, `product_name`, `image`) VALUES
(1, 1, 11, 1, 143000.00, 'Majesty Diamond ring', '/zenithco/public/uploads/6833fb33e0b29-Majesty Diamond ring.png'),
(2, 2, 16, 1, 567000.00, 'Gem Stone King', '/zenithco/public/uploads/68369d7deaae6-gem stone king.png');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `stock` int(11) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `description`, `image`, `stock`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Ring', 1500.00, 'tt', '/zenithco/public/uploads/682f92d0e090a-Fish And Chips (1).jpg', 1, 0, '2025-05-22 20:32:47', '2025-05-22 21:27:06'),
(2, 'test', 100.00, '100', '/zenithco/public/uploads/682f957b52d39-Brown Minimalist Food Instagram Highlight Covers (1).jpg', 1, 0, '2025-05-22 21:22:03', '2025-05-22 21:26:58'),
(3, 'Janadi', 199.00, 'ring', '/zenithco/public/uploads/683023d2294f8-WhatsApp Image 2025-05-21 at 10.47.27.jpeg', 1, 0, '2025-05-23 07:29:22', '2025-05-23 08:03:32'),
(4, 'Malik', 1000.00, 'descriptyion', '/zenithco/public/uploads/683074c39b7a6-Brown Minimalist Food Instagram Highlight Covers (1).jpg', 10, 0, '2025-05-23 13:14:43', '2025-05-23 13:15:27'),
(5, 'afaz', 10.00, 'hey', '/zenithco/public/uploads/68307f544bdab-WhatsApp Image 2025-05-19 at 00.27.44.jpeg', 1, 0, '2025-05-23 13:59:48', '2025-05-23 23:49:51'),
(6, 'testproduct', 1000000.00, 'Luxury ring with a gem', '/zenithco/public/uploads/68314b5c8b6ac-sustainability.jpg', 1, 0, '2025-05-24 04:30:20', '2025-05-24 04:30:41'),
(7, 'Dineth', 100.00, 'hi', '/zenithco/public/uploads/6831a5b2bef41-sustainability.jpg', 1, 0, '2025-05-24 10:55:46', '2025-05-26 04:04:32'),
(8, 'Festive Charm Diamond Ring', 156000.00, 'Gold Standard	\r\n18KT White Gold\r\n\r\nWeight	\r\n1.93 grams\r\n\r\nStone Type	\r\nDiamonds\r\n\r\nDiamond Weight	\r\n0.40ct\r\n\r\nSize	\r\nRing size:- 13 (U53)', '/zenithco/public/uploads/6833e70b1ff6b-festivecharmdiamondring.png', 3, 1, '2025-05-26 03:59:07', '2025-05-28 05:22:27'),
(9, 'Be My Love Diamond Ring', 200000.00, 'Gold Standard	\r\n18KT Pink Gold | White Gold\r\n\r\nWeight	\r\n2.57g\r\n\r\nSize	\r\nRing size – 14 (U 54)\r\n\r\nStone Type	\r\nDiamonds\r\n\r\nDiamond Weight	\r\n0.49ct', '/zenithco/public/uploads/6833ea3663bb9-bemylove.png', 2, 1, '2025-05-26 04:12:38', '2025-05-26 04:12:38'),
(10, 'Blossom Bliss Diamond Ring', 323400.00, 'Gold Standard	\r\n18KT Pink Gold\r\n\r\nWeight	\r\n5.1 grams\r\n\r\nStone Type	\r\nDiamonds\r\n\r\nDiamond Weight	\r\n0.42ct\r\n\r\nSize	\r\nRing Size – 13 (U 53)', '/zenithco/public/uploads/6833f4c30bb6d-blossam.png', 2, 1, '2025-05-26 04:57:39', '2025-05-26 04:57:39'),
(11, 'Majesty Diamond ring', 143000.00, 'Gold Standard	\r\n18KT White Gold\r\n\r\nWeight	\r\n3.11 grams\r\n\r\nStone Type	\r\nDiamonds\r\n\r\nDiamond Weight	\r\n0.36ct\r\n\r\nSize	\r\nRing size – 14 (U 54)', '/zenithco/public/uploads/6833fb33e0b29-Majesty Diamond ring.png', 1, 1, '2025-05-26 05:25:07', '2025-05-26 05:25:07'),
(12, '18kt two tone chain Gold', 270000.00, 'Crafted with the finest 18k gold, this luxurious chain boasts a stunning, intricate Byzantine design that catches the light beautifully. Perfect for adding a touch of elegance to any outfit.', '/zenithco/public/uploads/6833fd8f7762a-twotonechain.png', 3, 1, '2025-05-26 05:35:11', '2025-05-26 08:18:13'),
(13, 'Diamond hoop Earrings', 340000.00, 'Gold Standard	\r\n18KT Pink Gold\r\n\r\nWeight	\r\n4.98 grams\r\n\r\nDiamond Weight	\r\n0.33ct\r\n\r\nSize	\r\nDiameter – 2cm X 2cm | Width – 4mm', '/zenithco/public/uploads/6834005322058-moon beam diamond hoop earrins.png', 1, 1, '2025-05-26 05:46:59', '2025-05-26 05:46:59'),
(14, 'Prince Albert Chain', 670989.00, 'For an effortlessly stylish look.\r\n\r\nMaterial	Yellow Gold\r\nKaratage	22k\r\nWeight	191.250gms\r\nGender	Mens', '/zenithco/public/uploads/6836644fac572-prince albert chain.png', 1, 1, '2025-05-28 01:18:07', '2025-05-28 01:18:07'),
(15, 'Glamorous Stud', 234000.00, 'For an effortlessly stylish look.\r\n\r\nMaterial	White Gold\r\nKaratage	18k\r\nWeight	2.850gms\r\nGender	Womens', '/zenithco/public/uploads/6836654230cad-studs.png', 2, 1, '2025-05-28 01:22:10', '2025-05-28 01:22:10'),
(16, 'Gem Stone King', 567000.00, 'For an effortlessly stylish look.\r\n\r\nMaterial	Yellow Gold\r\nKaratage	22k\r\nWeight	13.240gms\r\nGender	Mens', '/zenithco/public/uploads/68369d7deaae6-gem stone king.png', 1, 1, '2025-05-28 05:22:05', '2025-05-28 05:22:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `is_active` tinyint(1) DEFAULT 1,
  `login_count` int(11) DEFAULT 0,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `profile_image`, `role`, `is_active`, `login_count`, `last_login`, `created_at`) VALUES
(1, 'Alice Silva', 'alice@example.com', '$2y$10$KIX/2fE8G./ySLFvwCVY7OdWyZB1B/h3.3w1FjtkF3BTYYrGZ.QXS', NULL, 'user', 1, 0, NULL, '2025-05-26 05:55:12'),
(2, 'Ben Fernando', 'ben@example.com', '$2y$10$KIX/2fE8G./ySLFvwCVY7OdWyZB1B/h3.3w1FjtkF3BTYYrGZ.QXS', NULL, 'user', 1, 0, NULL, '2025-05-26 05:55:12'),
(3, 'Carla Dias', 'carla@example.com', '$2y$10$KIX/2fE8G./ySLFvwCVY7OdWyZB1B/h3.3w1FjtkF3BTYYrGZ.QXS', NULL, 'user', 1, 0, NULL, '2025-05-26 05:55:12'),
(4, 'Dineth kumarage', 'dnet@gmail.com', '$2y$10$I/8UIxdHqhy.i366CkDgaeqSYAtkY5BslyANd8hKy1aQdRWmgPf5G', NULL, 'user', 1, 0, NULL, '2025-05-28 01:48:07'),
(5, 'Sarath Kumarage', 'sk12@gmail.com', '$2y$10$fc6Tbevtngz3aManzoHk2eo/LIumJFra65AgrwNq0GYr8U.1SQGxu', NULL, 'user', 1, 0, NULL, '2025-05-28 02:15:18');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `user_id`, `product_id`, `created_at`) VALUES
(1, 1, 8, '2025-05-26 06:41:39'),
(2, 1, 9, '2025-05-26 06:41:39'),
(3, 1, 10, '2025-05-26 06:41:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_orders_user_id` (`user_id`),
  ADD KEY `idx_orders_status` (`status`),
  ADD KEY `idx_orders_created_at` (`created_at`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_order_items_order_id` (`order_id`),
  ADD KEY `idx_order_items_product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_product_name` (`name`),
  ADD KEY `idx_price` (`price`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_role` (`role`),
  ADD KEY `idx_active` (`is_active`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_wishlist` (`user_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk_order_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_order_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
