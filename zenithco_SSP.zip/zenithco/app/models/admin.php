<?php
require_once __DIR__ . '/../../config/database.php';

function verifyAdmin($username, $password) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if ($admin && hash('sha256', $password) === $admin['password']) {
        return $admin;
    }
    return false;
}
