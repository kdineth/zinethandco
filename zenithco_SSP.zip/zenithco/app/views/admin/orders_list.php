<?php include __DIR__ . '/../layout/adminheader.php'; ?>

<div class="min-h-screen bg-ivory px-6 py-10">
  <div class="max-w-7xl mx-auto">
    <div class="flex justify-between items-center mb-8">
      <h1 class="text-3xl font-display text-navy">All Orders</h1>
      <a href="/zenithco/public/index.php?page=admin_dashboard" 
         class="text-sm text-white bg-navy px-4 py-2 rounded hover:bg-essence transition flex items-center">
        ← Back to Dashboard
      </a>
    </div>

    <?php if (!empty($orders)): ?>
      <form method="POST">
        <div class="overflow-x-auto bg-white border border-silver rounded-xl shadow">
          <table class="min-w-full text-sm divide-y divide-silver">
            <thead class="bg-mist text-left text-xs font-semibold uppercase text-essence">
              <tr>
                <th class="px-4 py-3">#</th>
                <th class="px-4 py-3">Order ID</th>
                <th class="px-4 py-3">Customer</th>
                <th class="px-4 py-3">Email</th>
                <th class="px-4 py-3">Total</th>
                <th class="px-4 py-3">Status</th>
                <th class="px-4 py-3">Placed At</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-ghost bg-pure text-charcoal">
              <?php foreach ($orders as $index => $order): ?>
                <tr class="hover:bg-ghost transition">
                  <td class="px-4 py-3 font-medium">
                    <?= $index + 1 ?>
                  </td>
                  <td class="px-4 py-3 font-semibold text-primary">
                    <?= htmlspecialchars($order['id']) ?>
                  </td>
                  <td class="px-4 py-3">
                    <?= htmlspecialchars($order['customer_name']) ?>
                  </td>
                  <td class="px-4 py-3">
                    <?= htmlspecialchars($order['customer_email']) ?>
                  </td>
                  <td class="px-4 py-3">
                    LKR <?= number_format($order['total_amount'] ?? 0, 2) ?>
                  </td>
                  <td class="px-4 py-3 capitalize">
                    <select name="statuses[<?= $order['id'] ?>]" class="border border-ether rounded px-2 py-1 bg-white text-sm">
                      <option value="pending" <?= $order['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                      <option value="processing" <?= $order['status'] === 'processing' ? 'selected' : '' ?>>Processing</option>
                      <option value="shipped" <?= $order['status'] === 'shipped' ? 'selected' : '' ?>>Shipped</option>
                      <option value="delivered" <?= $order['status'] === 'delivered' ? 'selected' : '' ?>>Delivered</option>
                      <option value="cancelled" <?= $order['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                  </td>
                  <td class="px-4 py-3">
                    <?= htmlspecialchars($order['created_at']) ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <div class="mt-6 text-right">
          <button type="submit" formaction="/zenithco/public/index.php?page=update_order_status" class="bg-ember text-white px-6 py-2 rounded hover:bg-navy transition">Update Statuses</button>
        </div>
      </form>
    <?php else: ?>
      <p class="text-sm text-ether mt-6">No orders found.</p>
    <?php endif; ?>
  </div>
</div>

<?php include __DIR__ . '/../layout/adminfooter.php'; ?>
