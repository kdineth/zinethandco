<?php
include __DIR__ . '/../layout/userheader.php';
if (session_status() === PHP_SESSION_NONE) session_start();
?>

<main class="bg-ivory pt-32 pb-16 px-4 sm:px-8 min-h-screen">
  <div class="max-w-6xl mx-auto">
    <div class="mb-8">
      <h1 class="text-4xl font-display text-essence mb-2">My Orders</h1>
      <p class="text-essence/70">Track and manage your jewelry orders</p>
    </div>

    <!-- Success/Error Messages -->
    <?php if (isset($_SESSION['success'])): ?>
      <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
        <?= htmlspecialchars($_SESSION['success']) ?>
        <?php unset($_SESSION['success']); ?>
      </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
      <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
        <?= htmlspecialchars($_SESSION['error']) ?>
        <?php unset($_SESSION['error']); ?>
      </div>
    <?php endif; ?>

    <?php if (!empty($orders)): ?>
      <div class="space-y-6">
        <?php foreach ($orders as $order): ?>
          <div class="bg-pure rounded-lg border border-mist shadow-soft overflow-hidden">
            <div class="p-6 border-b border-mist">
              <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h3 class="text-xl font-semibold text-essence mb-2">Order #<?= $order['id'] ?></h3>
                  <p class="text-sm text-storm">Placed on <?= date('F j, Y g:i A', strtotime($order['created_at'])) ?></p>
                </div>
                <div class="mt-4 sm:mt-0 text-right">
                  <?php
                  $status = strtolower($order['status']);
                  $statusClass = match($status) {
                    'pending' => 'bg-yellow-100 text-yellow-800 border-yellow-200',
                    'processing' => 'bg-blue-100 text-blue-800 border-blue-200',
                    'shipped' => 'bg-purple-100 text-purple-800 border-purple-200',
                    'delivered' => 'bg-green-100 text-green-800 border-green-200',
                    'cancelled' => 'bg-red-100 text-red-800 border-red-200',
                    default => 'bg-gray-100 text-gray-800 border-gray-200'
                  };
                  ?>
                  <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border <?= $statusClass ?>">
                    <?= ucfirst($order['status']) ?>
                  </span>
                </div>
              </div>
            </div>
            
            <div class="p-6">
              <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <h4 class="font-medium text-essence mb-2">Order Total</h4>
                  <p class="text-2xl font-bold text-primary">LKR <?= number_format($order['total_amount'], 2) ?></p>
                </div>
                
                <div>
                  <h4 class="font-medium text-essence mb-2">Payment Method</h4>
                  <p class="text-storm"><?= ucfirst($order['payment_method']) ?></p>
                </div>
                
                <div>
                  <h4 class="font-medium text-essence mb-2">Shipping Address</h4>
                  <p class="text-storm text-sm">
                    <?= htmlspecialchars($order['shipping_address']) ?><br>
                    <?= htmlspecialchars($order['city']) ?> <?= htmlspecialchars($order['postal_code']) ?>
                  </p>
                </div>
              </div>
              
              <div class="mt-6 flex flex-col sm:flex-row gap-3">
                <a href="/zenithco/public/index.php?page=order_details&id=<?= $order['id'] ?>" 
                   class="inline-flex items-center justify-center px-4 py-2 bg-primary text-white font-medium rounded-lg hover:bg-primary_dark transition-colors">
                  <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                  </svg>
                  View Details
                </a>
                
                <?php if (in_array($order['status'], ['delivered', 'shipped'])): ?>
                  <a href="/zenithco/public/index.php?page=download_receipt&order_id=<?= $order['id'] ?>" 
                     class="inline-flex items-center justify-center px-4 py-2 border border-silver text-charcoal font-medium rounded-lg hover:border-primary hover:text-primary transition-colors">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                    </svg>
                    Download Receipt
                  </a>
                <?php endif; ?>
                
                <?php if ($order['status'] === 'pending'): ?>
                  <button onclick="if(confirm('Are you sure you want to cancel this order?')) window.location.href='/zenithco/public/index.php?page=cancel_order&id=<?= $order['id'] ?>'" 
                          class="inline-flex items-center justify-center px-4 py-2 border border-red-300 text-red-600 font-medium rounded-lg hover:border-red-500 hover:text-red-800 transition-colors">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                    Cancel Order
                  </button>
                <?php endif; ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      
      <!-- Pagination would go here if needed -->
      
    <?php else: ?>
      <!-- Empty Orders State -->
      <div class="text-center py-16 bg-pure rounded-lg border border-mist">
        <div class="max-w-md mx-auto">
          <div class="w-24 h-24 bg-ghost rounded-full flex items-center justify-center mx-auto mb-6">
            <svg class="w-12 h-12 text-steel" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v6a2 2 0 002 2h2m0-8v8m0-8h8m-8 0V3a2 2 0 012-2h4a2 2 0 012 2v2m-6 8h8a2 2 0 002-2V9a2 2 0 00-2-2h-8m0 0V3"/>
            </svg>
          </div>
          <h3 class="text-2xl font-semibold text-essence mb-2">No orders yet</h3>
          <p class="text-storm mb-6">You haven't placed any orders yet. Start shopping to see your orders here!</p>
          
          <div class="space-y-3">
            <a href="/zenithco/public/index.php?page=user_products" 
               class="inline-block bg-primary text-white font-semibold px-8 py-3 rounded-lg hover:bg-primary_dark transition-colors">
              <svg class="w-5 h-5 inline-block mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
              </svg>
              Start Shopping
            </a>
            <br>
            <a href="/zenithco/public/index.php?page=landing" 
               class="inline-block text-primary hover:text-primary_dark underline">
              Browse Featured Products
            </a>
          </div>
        </div>
      </div>
    <?php endif; ?>
    
    <!-- Quick Actions -->
    <div class="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
      <a href="/zenithco/public/index.php?page=user_cart" 
         class="bg-pure rounded-lg border border-mist p-6 text-center hover:border-primary transition-colors">
        <div class="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
          <svg class="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6.5-5v5a1 1 0 01-1 1H9a1 1 0 01-1-1v-5m8 0V9a1 1 0 00-1-1H9a1 1 0 00-1 1v4.01"/>
          </svg>
        </div>
        <h3 class="font-medium text-essence mb-1">Shopping Cart</h3>
        <p class="text-sm text-storm">View items in your cart</p>
      </a>
      
      <a href="/zenithco/public/index.php?page=user_wishlist" 
         class="bg-pure rounded-lg border border-mist p-6 text-center hover:border-primary transition-colors">
        <div class="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
          <svg class="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
          </svg>
        </div>
        <h3 class="font-medium text-essence mb-1">Wishlist</h3>
        <p class="text-sm text-storm">View saved items</p>
      </a>
      
      <a href="/zenithco/public/index.php?page=user_profile" 
         class="bg-pure rounded-lg border border-mist p-6 text-center hover:border-primary transition-colors">
        <div class="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
          <svg class="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
          </svg>
        </div>
        <h3 class="font-medium text-essence mb-1">Profile</h3>
        <p class="text-sm text-storm">Manage your account</p>
      </a>
    </div>
  </div>
</main>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>