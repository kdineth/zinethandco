<?php
include __DIR__ . '/../layout/userheader.php';
?>

<main class="bg-pure pt-24">

  <!-- Hero Section -->
  <section class="py-20 bg-ghost">
    <div class="max-w-4xl mx-auto px-6 text-center">
      <h1 class="text-5xl font-display text-charcoal mb-6">Our Services</h1>
      <p class="text-xl text-storm leading-relaxed">
        From custom design to expert repairs, we offer comprehensive jewelry services to meet all your needs. Our master craftsmen combine traditional techniques with modern innovation to deliver exceptional results.
      </p>
    </div>
  </section>

  <!-- Main Services -->
  <section class="py-20 bg-pure">
    <div class="max-w-7xl mx-auto px-6">
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-20">
        
        <!-- Custom Design Service -->
        <div class="space-y-6">
          <div class="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center">
            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"></path>
            </svg>
          </div>
          <h2 class="text-3xl font-display text-charcoal">Custom Design</h2>
          <p class="text-storm leading-relaxed">
            Bring your vision to life with our bespoke jewelry design service. Our expert designers work closely with you to create one-of-a-kind pieces that reflect your personal style and story.
          </p>
          <ul class="space-y-2 text-storm">
            <li class="flex items-start">
              <svg class="w-5 h-5 text-primary mt-0.5 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
              </svg>
              Personal consultation and design concept development
            </li>
            <li class="flex items-start">
              <svg class="w-5 h-5 text-primary mt-0.5 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
              </svg>
              3D modeling and detailed sketches
            </li>
            <li class="flex items-start">
              <svg class="w-5 h-5 text-primary mt-0.5 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
              </svg>
              Premium material selection and sourcing
            </li>
            <li class="flex items-start">
              <svg class="w-5 h-5 text-primary mt-0.5 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
              </svg>
              Master craftsmanship and handmade creation
            </li>
          </ul>
          <a href="#contact" class="inline-block bg-primary text-pure font-semibold py-3 px-8 rounded-lg hover:bg-primary_dark transition-colors duration-200">
            Schedule Consultation
          </a>
        </div>
        
        <div>
          <img src="/zenithco/public/images/customdesignservice.jpg" alt="Custom Design Service" 
               class="w-full h-96 object-cover rounded-lg">
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-20">
        <div class="order-2 lg:order-1">
          <img src="/zenithco/public/images/repair-service.jpg" alt="Repair & Maintenance" 
               class="w-full h-96 object-cover rounded-lg">
        </div>
        
        <!-- Repair & Maintenance Service -->
        <div class="space-y-6 order-1 lg:order-2">
          <div class="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center">
            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path>
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
            </svg>
          </div>
          <h2 class="text-3xl font-display text-charcoal">Repair & Maintenance</h2>
          <p class="text-storm leading-relaxed">
            Keep your precious jewelry in perfect condition with our expert repair and maintenance services. Our skilled technicians can restore even the most delicate pieces to their original beauty.
          </p>
          <ul class="space-y-2 text-storm">
            <li class="flex items-start">
              <svg class="w-5 h-5 text-primary mt-0.5 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
              </svg>
              Ring resizing and reshaping
            </li>
            <li class="flex items-start">
              <svg class="w-5 h-5 text-primary mt-0.5 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
              </svg>
              Stone setting and replacement
            </li>
            <li class="flex items-start">
              <svg class="w-5 h-5 text-primary mt-0.5 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
              </svg>
              Chain and clasp repair
            </li>
            <li class="flex items-start">
              <svg class="w-5 h-5 text-primary mt-0.5 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
              </svg>
              Professional cleaning and polishing
            </li>
          </ul>
          <a href="#contact" class="inline-block border-2 border-primary text-primary font-semibold py-3 px-8 rounded-lg hover:bg-primary hover:text-pure transition-colors duration-200">
            Get Quote
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- Additional Services -->
  <section class="py-20 bg-ghost">
    <div class="max-w-7xl mx-auto px-6">
      <div class="text-center mb-16">
        <h2 class="text-4xl font-display text-charcoal mb-6">Additional Services</h2>
        <p class="text-xl text-storm max-w-3xl mx-auto">
          We offer a comprehensive range of jewelry services to ensure your pieces remain beautiful and valuable for years to come.
        </p>
      </div>
      
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        
        <!-- Appraisal Services -->
        <div class="bg-pure p-8 rounded-lg border border-silver text-center">
          <div class="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v6a2 2 0 002 2h2m0-8v8m0-8h8m-8 0V3a2 2 0 012-2h4a2 2 0 012 2v2m-6 8h8a2 2 0 002-2V9a2 2 0 00-2-2h-8m0 0V3"></path>
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-charcoal mb-4">Professional Appraisal</h3>
          <p class="text-storm mb-6">
            Certified gemological appraisals for insurance, estate planning, or resale purposes. Our expert appraisers provide detailed reports with accurate valuations.
          </p>
          <ul class="text-sm text-storm space-y-2 mb-6">
            <li>Insurance appraisals</li>
            <li>Estate valuations</li>
            <li>Damage assessments</li>
            <li>Certified documentation</li>
          </ul>
        </div>

        <!-- Cleaning & Care -->
        <div class="bg-pure p-8 rounded-lg border border-silver text-center">
          <div class="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-charcoal mb-4">Professional Cleaning</h3>
          <p class="text-storm mb-6">
            Keep your jewelry looking its best with our professional cleaning and care services. We use safe, effective methods to restore shine and brilliance.
          </p>
          <ul class="text-sm text-storm space-y-2 mb-6">
            <li>Ultrasonic cleaning</li>
            <li>Steam cleaning</li>
            <li>Hand polishing</li>
            <li>Protective coating</li>
          </ul>
        </div>

        <!-- Consultation -->
        <div class="bg-pure p-8 rounded-lg border border-silver text-center">
          <div class="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-charcoal mb-4">Expert Consultation</h3>
          <p class="text-storm mb-6">
            Get professional advice on jewelry selection, care, styling, and investment. Our experts are here to help you make informed decisions.
          </p>
          <ul class="text-sm text-storm space-y-2 mb-6">
            <li>Style consultation</li>
            <li>Investment advice</li>
            <li>Care guidance</li>
            <li>Gemstone education</li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <!-- Service Process -->
  <section class="py-20 bg-pure">
    <div class="max-w-7xl mx-auto px-6">
      <div class="text-center mb-16">
        <h2 class="text-4xl font-display text-charcoal mb-6">Our Service Process</h2>
        <p class="text-xl text-storm max-w-3xl mx-auto">
          We follow a meticulous process to ensure every service meets our exacting standards and exceeds your expectations.
        </p>
      </div>
      
      <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
        <div class="text-center">
          <div class="w-16 h-16 bg-primary text-pure rounded-full flex items-center justify-center mx-auto mb-6 font-bold text-xl">
            1
          </div>
          <h3 class="text-lg font-semibold text-charcoal mb-3">Consultation</h3>
          <p class="text-storm">
            We discuss your needs, assess your piece, and provide expert recommendations and transparent pricing.
          </p>
        </div>
        
        <div class="text-center">
          <div class="w-16 h-16 bg-primary text-pure rounded-full flex items-center justify-center mx-auto mb-6 font-bold text-xl">
            2
          </div>
          <h3 class="text-lg font-semibold text-charcoal mb-3">Planning</h3>
          <p class="text-storm">
            Our experts create a detailed service plan, including timeline and materials needed for your project.
          </p>
        </div>
        
        <div class="text-center">
          <div class="w-16 h-16 bg-primary text-pure rounded-full flex items-center justify-center mx-auto mb-6 font-bold text-xl">
            3
          </div>
          <h3 class="text-lg font-semibold text-charcoal mb-3">Execution</h3>
          <p class="text-storm">
            Our master craftsmen perform the work with precision and care, keeping you updated throughout the process.
          </p>
        </div>
        
        <div class="text-center">
          <div class="w-16 h-16 bg-primary text-pure rounded-full flex items-center justify-center mx-auto mb-6 font-bold text-xl">
            4
          </div>
          <h3 class="text-lg font-semibold text-charcoal mb-3">Delivery</h3>
          <p class="text-storm">
            We present your finished piece with care instructions and provide ongoing support for future needs.
          </p>
        </div>
      </div>
    </div>
  </section>

  <!-- Warranties & Guarantees -->
  <section class="py-20 bg-ghost">
    <div class="max-w-7xl mx-auto px-6">
      <div class="text-center mb-16">
        <h2 class="text-4xl font-display text-charcoal mb-6">Warranties & Guarantees</h2>
        <p class="text-xl text-storm max-w-3xl mx-auto">
          We stand behind our work with comprehensive warranties and guarantees, giving you peace of mind with every service.
        </p>
      </div>
      
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <div class="bg-pure p-8 rounded-lg border border-silver text-center">
          <div class="w-16 h-16 bg-success/10 rounded-lg flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-charcoal mb-4">Lifetime Craftsmanship Warranty</h3>
          <p class="text-storm">
            All our handcrafted pieces come with a lifetime warranty covering workmanship and structural integrity.
          </p>
        </div>
        
        <div class="bg-pure p-8 rounded-lg border border-silver text-center">
          <div class="w-16 h-16 bg-success/10 rounded-lg flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-charcoal mb-4">Service Guarantee</h3>
          <p class="text-storm">
            All repair and maintenance services include a 12-month guarantee on the work performed by our craftsmen.
          </p>
        </div>
        
        <div class="bg-pure p-8 rounded-lg border border-silver text-center">
          <div class="w-16 h-16 bg-success/10 rounded-lg flex items-center justify-center mx-auto mb-6">
            <svg class="w-8 h-8 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
            </svg>
          </div>
          <h3 class="text-xl font-semibold text-charcoal mb-4">Customer Satisfaction</h3>
          <p class="text-storm">
            If you're not completely satisfied with our service, we'll work with you to make it right at no additional cost.
          </p>
        </div>
      </div>
    </div>
  </section>

  <!-- CTA Section -->
  <section id="contact" class="py-20 bg-primary text-pure">
    <div class="max-w-4xl mx-auto px-6 text-center">
      <h2 class="text-4xl font-display mb-6">Ready to Get Started?</h2>
      <p class="text-xl text-pure/90 mb-8 leading-relaxed">
        Contact us today to discuss your jewelry needs. Our expert team is ready to provide personalized service and exceptional results.
      </p>
      
      <div class="flex flex-col sm:flex-row gap-4 justify-center">
        <a href="/zenithco/public/index.php?page=contact" class="inline-block bg-pure text-primary font-semibold py-4 px-8 rounded-lg hover:bg-pure/90 transition-colors duration-200">
          Schedule Consultation
        </a>
        <a href="tel:+94771234567" class="inline-block border-2 border-pure/80 text-pure font-semibold py-4 px-8 rounded-lg hover:bg-pure/10 transition-colors duration-200">
          Call Now
        </a>
      </div>
    </div>
  </section>

</main>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>