<?php
include __DIR__ . '/../layout/userheader.php';
if (session_status() === PHP_SESSION_NONE) session_start();
?>

<main class="bg-ivory pt-32 pb-16 px-4 sm:px-8 min-h-screen animate-fade-in">
  <div class="text-center mb-12">
    <h1 class="text-4xl font-display text-essence mb-2">All Collections</h1>
    <p class="text-essence/70 text-lg">Explore our full range of luxury jewelry</p>
  </div>

  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 max-w-7xl mx-auto">
    <?php if (!empty($products)): ?>
      <?php foreach ($products as $product): ?>
        <div class="group bg-pure border border-silver rounded-xl overflow-hidden hover:border-primary transition-colors duration-200 shadow-soft hover:shadow-medium relative">
          <!-- Wishlist Button -->
          <form method="POST" action="/zenithco/public/index.php?page=add_wishlist" class="absolute top-3 right-3 z-10">
            <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
            <button type="submit" title="Add to Wishlist"
                    class="w-9 h-9 bg-pure/90 backdrop-blur-sm border border-silver/50 rounded-full flex items-center justify-center text-steel hover:text-primary hover:bg-primary/5 hover:border-primary/30 transition-all duration-200">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                      d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
              </svg>
            </button>
          </form>

          <!-- Product Image -->
          <a href="/zenithco/public/index.php?page=product_detail&id=<?= $product['id'] ?>" class="block">
            <div class="aspect-square bg-ghost overflow-hidden">
              <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>"
                   class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
            </div>
          </a>

          <!-- Product Info -->
          <div class="p-4">
            <a href="/zenithco/public/index.php?page=product_detail&id=<?= $product['id'] ?>" class="block">
              <h3 class="text-lg font-semibold text-charcoal mb-2 group-hover:text-primary transition-colors line-clamp-1">
                <?= htmlspecialchars($product['name']) ?>
              </h3>
              <p class="text-sm text-storm mb-2 line-clamp-2"><?= htmlspecialchars($product['description']) ?></p>
              <p class="text-xl font-bold text-primary">LKR <?= number_format($product['price'], 2) ?></p>
            </a>

            <!-- Action Buttons -->
            <div class="mt-4 space-y-2">
              <?php if (!isset($_SESSION['user_id'])): ?>
                <a href="/zenithco/public/index.php?page=user_login" 
                   class="block w-full text-center bg-primary text-white font-semibold py-2 rounded-lg hover:bg-primary_dark transition-colors duration-200 text-sm">
                  Add to Cart
                </a>
                <a href="/zenithco/public/index.php?page=user_login"
                   class="block w-full text-center border border-silver text-charcoal font-medium py-2 rounded-lg hover:border-primary hover:text-primary transition-colors duration-200 text-sm">
                  Buy Now
                </a>
              <?php else: ?>
                <form method="POST" action="/zenithco/public/index.php" class="space-y-2">
                  <input type="hidden" name="action" value="add_to_cart">
                  <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                  <input type="hidden" name="quantity" value="1">
                  <button type="submit" class="w-full bg-primary text-white font-semibold py-2 rounded-lg hover:bg-primary_dark transition-colors duration-200 text-sm">
                    Add to Cart
                  </button>
                </form>
                <a href="/zenithco/public/index.php?page=product_detail&id=<?= $product['id'] ?>"
                   class="block w-full text-center border border-silver text-charcoal font-medium py-2 rounded-lg hover:border-primary hover:text-primary transition-colors duration-200 text-sm">
                  Buy Now
                </a>
              <?php endif; ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <p class="col-span-full text-center text-essence/60">No products found.</p>
    <?php endif; ?>
  </div>
</main>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>
