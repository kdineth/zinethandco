<?php
include __DIR__ . '/../layout/userheader.php';

if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: /zenithco/public/index.php?page=user_login");
    exit;
}

// This must be set by your controller: $orders = getUserOrders($_SESSION['user_id']);
?>

<main class="pt-24 pb-20 bg-ghost min-h-screen">
  <!-- Breadcrumb -->
  <section class="py-6 bg-pure border-b border-silver">
    <div class="max-w-7xl mx-auto px-6">
      <nav class="flex items-center space-x-2 text-sm">
        <a href="/zenithco/public/index.php?page=landing" class="text-steel hover:text-primary transition-colors">Home</a>
        <svg class="w-4 h-4 text-silver" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
        </svg>
        <span class="text-charcoal font-medium">My Orders</span>
      </nav>
    </div>
  </section>

  <div class="max-w-6xl mx-auto px-6 py-12">
    <!-- Header -->
    <div class="flex items-center justify-between mb-8">
      <div>
        <h1 class="text-4xl font-display text-charcoal mb-2">My Orders</h1>
        <p class="text-storm">Track and manage your jewelry orders</p>
      </div>
      
      <?php if (!empty($orders)): ?>
        <a href="/zenithco/public/index.php?page=user_products"
           class="inline-flex items-center px-6 py-3 border-2 border-silver text-charcoal font-medium rounded-xl hover:border-primary hover:text-primary transition-colors duration-200">
          <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
          </svg>
          New Order
        </a>
      <?php endif; ?>
    </div>

    <?php if (empty($orders)): ?>
      <!-- Empty State -->
      <div class="bg-pure border border-silver p-12 text-center rounded-2xl shadow-soft">
        <div class="max-w-md mx-auto">
          <div class="w-24 h-24 bg-ghost rounded-full flex items-center justify-center mx-auto mb-6">
            <svg class="w-12 h-12 text-steel" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v6a2 2 0 002 2h2m0-8v8m0-8h8m-8 0V3a2 2 0 012-2h4a2 2 0 012 2v2m-6 8h8a2 2 0 002-2V9a2 2 0 00-2-2h-8m0 0V3"></path>
            </svg>
          </div>
          <h2 class="text-2xl font-serif text-charcoal mb-4">No Orders Yet</h2>
          <p class="text-storm text-lg mb-8 leading-relaxed">
            You haven't placed any orders yet. Discover our beautiful collection of handcrafted jewelry pieces.
          </p>
          <a href="/zenithco/public/index.php?page=user_products"
             class="inline-flex items-center px-8 py-4 bg-primary text-pure font-semibold rounded-xl hover:bg-primary_dark transition-colors duration-200 shadow-soft hover:shadow-primary">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13l-1.5 6h13l-1.5-6M10 21a1 1 0 100-2 1 1 0 000 2zm8 0a1 1 0 100-2 1 1 0 000 2z"></path>
            </svg>
            Start Shopping
          </a>
        </div>
      </div>
    <?php else: ?>
      <!-- Orders Table -->
      <div class="bg-pure border border-silver rounded-2xl shadow-soft overflow-hidden">
        <!-- Desktop View -->
        <div class="hidden lg:block overflow-x-auto">
          <table class="min-w-full">
            <thead class="bg-ghost border-b border-silver">
              <tr>
                <th class="px-8 py-6 text-left font-semibold text-charcoal">Order ID</th>
                <th class="px-8 py-6 text-left font-semibold text-charcoal">Date</th>
                <th class="px-8 py-6 text-left font-semibold text-charcoal">Status</th>
                <th class="px-8 py-6 text-left font-semibold text-charcoal">Total</th>
                <th class="px-8 py-6 text-center font-semibold text-charcoal">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-silver">
              <?php foreach ($orders as $order): ?>
                <tr class="hover:bg-ghost/50 transition-colors duration-200">
                  <td class="px-8 py-6">
                    <span class="font-mono text-primary font-medium">#<?= htmlspecialchars($order['id']) ?></span>
                  </td>
                  <td class="px-8 py-6 text-charcoal">
                    <?= date('M d, Y', strtotime($order['created_at'])) ?>
                  </td>
                  <td class="px-8 py-6">
                    <?php
                    $status = htmlspecialchars($order['status']);
                    $statusClass = match(strtolower($status)) {
                      'pending' => 'bg-warning/10 text-warning border-warning/30',
                      'processing' => 'bg-info/10 text-info border-info/30',
                      'shipped' => 'bg-primary/10 text-primary border-primary/30',
                      'delivered' => 'bg-success/10 text-success border-success/30',
                      'cancelled' => 'bg-error/10 text-error border-error/30',
                      default => 'bg-steel/10 text-steel border-steel/30'
                    };
                    ?>
                    <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border <?= $statusClass ?>">
                      <?= ucfirst($status) ?>
                    </span>
                  </td>
                  <td class="px-8 py-6">
                    <span class="font-semibold text-charcoal text-lg">LKR <?= number_format($order['total_amount'], 2) ?></span>
                  </td>
                  <td class="px-8 py-6 text-center">
                    <a href="/zenithco/public/index.php?page=order_details&id=<?= $order['id'] ?>"
                       class="inline-flex items-center px-4 py-2 bg-primary text-pure font-medium rounded-lg hover:bg-primary_dark transition-colors duration-200 shadow-soft hover:shadow-primary">
                      <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                      </svg>
                      View Details
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <!-- Mobile View -->
        <div class="lg:hidden divide-y divide-silver">
          <?php foreach ($orders as $order): ?>
            <div class="p-6">
              <div class="flex justify-between items-start mb-4">
                <div>
                  <h3 class="font-mono text-primary font-medium">#<?= htmlspecialchars($order['id']) ?></h3>
                  <p class="text-sm text-storm"><?= date('M d, Y', strtotime($order['created_at'])) ?></p>
                </div>
                <div class="text-right">
                  <?php
                  $status = htmlspecialchars($order['status']);
                  $statusClass = match(strtolower($status)) {
                    'pending' => 'bg-warning/10 text-warning border-warning/30',
                    'processing' => 'bg-info/10 text-info border-info/30',
                    'shipped' => 'bg-primary/10 text-primary border-primary/30',
                    'delivered' => 'bg-success/10 text-success border-success/30',
                    'cancelled' => 'bg-error/10 text-error border-error/30',
                    default => 'bg-steel/10 text-steel border-steel/30'
                  };
                  ?>
                  <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border <?= $statusClass ?>">
                    <?= ucfirst($status) ?>
                  </span>
                </div>
              </div>
              
              <div class="flex justify-between items-center">
                <span class="font-semibold text-charcoal">LKR <?= number_format($order['total_amount'], 2) ?></span>
                <a href="/zenithco/public/index.php?page=order_details&id=<?= $order['id'] ?>"
                   class="inline-flex items-center px-4 py-2 bg-primary text-pure font-medium rounded-lg hover:bg-primary_dark transition-colors duration-200 text-sm">
                  <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                  </svg>
                  View Details
                </a>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endif; ?>
  </div>
</main>

<?php include __DIR__ . '/../layout/userfooter.php'; ?>