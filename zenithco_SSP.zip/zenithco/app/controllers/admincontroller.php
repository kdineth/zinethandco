<?php
// Safely start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../models/admin.php';

/**
 * Show Admin Login Page
 */
function showLogin() {
    $error = $_SESSION['error'] ?? null;
    unset($_SESSION['error']);
    include __DIR__ . '/../views/admin/login.php';
}

/**
 * Handle Admin Login Submission
 */
function handleLogin() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);

        if (empty($username) || empty($password)) {
            $_SESSION['error'] = "Please fill in all fields";
            header("Location: /zenithco/public/index.php?page=admin_login");
            exit();
        }

        $admin = verifyAdmin($username, $password);
        if ($admin) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $admin['username'];
            header("Location: /zenithco/public/index.php?page=admin_dashboard");
        } else {
            $_SESSION['error'] = "Invalid credentials";
            header("Location: /zenithco/public/index.php?page=admin_login");
        }
        exit();
    }
}

/**
 * Show Admin Dashboard
 */
function showDashboard() {
    if (!isset($_SESSION['admin_logged_in'])) {
        header("Location: /zenithco/public/index.php?page=admin_login");
        exit();
    }

    include __DIR__ . '/../views/admin/dashboard.php';
}

/**
 * Handle Admin Logout (if triggered via GET)
 */
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    header("Location: /zenithco/public/index.php?page=admin_login");
    exit();
}
