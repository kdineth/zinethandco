<?php
require_once __DIR__ . '/../../config/database.php';

/**
 * Create a new order
 * @param int $userId User ID
 * @param float $totalAmount Order total
 * @param array $billingData Billing information
 * @return int|false Order ID on success, false on failure
 */
function createOrder($userId, $totalAmount, $billingData) {
    global $pdo;
    
    try {
        error_log("[ORDER_MODEL] Creating order for user: $userId, total: $totalAmount");
        
        $pdo->beginTransaction();
        
        // Insert order
        $stmt = $pdo->prepare("
            INSERT INTO orders (user_id, total_amount, status, customer_name, customer_email, 
                               customer_phone, shipping_address, city, postal_code, payment_method, created_at) 
            VALUES (?, ?, 'pending', ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $userId,
            $totalAmount,
            $billingData['name'],
            $billingData['email'],
            $billingData['phone'],
            $billingData['address'],
            $billingData['city'],
            $billingData['zip'],
            $billingData['payment']
        ]);
        
        $orderId = $pdo->lastInsertId();
        error_log("[ORDER_MODEL] Order created with ID: $orderId");
        
        // Get cart items
        require_once __DIR__ . '/cart.php';
        $cartItems = getCartItems($userId);
        
        if (empty($cartItems)) {
            throw new Exception("Cart is empty");
        }
        
        // Insert order items
        foreach ($cartItems as $item) {
            $stmt = $pdo->prepare("
                INSERT INTO order_items (order_id, product_id, product_name, quantity, price, image) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $orderId,
                $item['product_id'],
                $item['name'],
                $item['quantity'],
                $item['price'],
                $item['image']
            ]);
            
            error_log("[ORDER_MODEL] Added order item: " . $item['name']);
        }
        
        // Clear cart after successful order
        clearCart($userId);
        error_log("[ORDER_MODEL] Cart cleared for user: $userId");
        
        $pdo->commit();
        return $orderId;
        
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("[ORDER_MODEL] Order creation error: " . $e->getMessage());
        return false;
    }
}

/**
 * Get order by ID
 * @param int $orderId Order ID
 * @param int|null $userId User ID (optional for security)
 * @return array|false Order data or false
 */
function getOrderById($orderId, $userId = null) {
    global $pdo;
    
    try {
        $sql = "SELECT * FROM orders WHERE id = ?";
        $params = [$orderId];
        
        if ($userId) {
            $sql .= " AND user_id = ?";
            $params[] = $userId;
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($order) {
            error_log("[ORDER_MODEL] Order found: $orderId");
        } else {
            error_log("[ORDER_MODEL] Order not found: $orderId");
        }
        
        return $order;
        
    } catch (PDOException $e) {
        error_log("[ORDER_MODEL] Database error in getOrderById: " . $e->getMessage());
        return false;
    }
}

/**
 * Get order items by order ID
 * @param int $orderId Order ID
 * @return array Order items
 */
function getOrderItems($orderId) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ? ORDER BY id");
        $stmt->execute([$orderId]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        error_log("[ORDER_MODEL] Found " . count($items) . " items for order: $orderId");
        return $items;
        
    } catch (PDOException $e) {
        error_log("[ORDER_MODEL] Database error in getOrderItems: " . $e->getMessage());
        return [];
    }
}

/**
 * Get all orders for a user
 * @param int $userId User ID
 * @return array User orders
 */
function getUserOrders($userId) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->execute([$userId]);
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        error_log("[ORDER_MODEL] Found " . count($orders) . " orders for user: $userId");
        return $orders;
        
    } catch (PDOException $e) {
        error_log("[ORDER_MODEL] Database error in getUserOrders: " . $e->getMessage());
        return [];
    }
}

/**
 * Update order status
 * @param int $orderId Order ID
 * @param string $status New status
 * @return bool Success status
 */
function updateOrderStatus($orderId, $status) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?");
        $result = $stmt->execute([$status, $orderId]);
        
        if ($result) {
            error_log("[ORDER_MODEL] Order $orderId status updated to: $status");
        } else {
            error_log("[ORDER_MODEL] Failed to update order $orderId status");
        }
        
        return $result;
        
    } catch (PDOException $e) {
        error_log("[ORDER_MODEL] Database error in updateOrderStatus: " . $e->getMessage());
        return false;
    }
}

/**
 * Get all orders (admin function)
 * @return array All orders
 */
function getAllOrders() {
    global $pdo;
    
    try {
        $stmt = $pdo->query("
            SELECT o.*, u.name as user_name, u.email as user_email 
            FROM orders o 
            LEFT JOIN users u ON o.user_id = u.id 
            ORDER BY o.created_at DESC
        ");
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        error_log("[ORDER_MODEL] Retrieved " . count($orders) . " orders for admin");
        return $orders;
        
    } catch (PDOException $e) {
        error_log("[ORDER_MODEL] Database error in getAllOrders: " . $e->getMessage());
        return [];
    }
}

/**
 * Get order statistics
 * @return array Order statistics
 */
function getOrderStats() {
    global $pdo;
    
    try {
        $stats = [];
        
        // Total orders
        $stmt = $pdo->query("SELECT COUNT(*) as total_orders FROM orders");
        $stats['total_orders'] = $stmt->fetchColumn();
        
        // Total revenue
        $stmt = $pdo->query("SELECT SUM(total_amount) as total_revenue FROM orders WHERE status != 'cancelled'");
        $stats['total_revenue'] = $stmt->fetchColumn() ?? 0;
        
        // Orders by status
        $stmt = $pdo->query("SELECT status, COUNT(*) as count FROM orders GROUP BY status");
        $statusCounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($statusCounts as $status) {
            $stats['status_' . $status['status']] = $status['count'];
        }
        
        error_log("[ORDER_MODEL] Generated order statistics");
        return $stats;
        
    } catch (PDOException $e) {
        error_log("[ORDER_MODEL] Database error in getOrderStats: " . $e->getMessage());
        return [];
    }
}

/**
 * Get recent orders
 * @param int $limit Number of orders to retrieve
 * @return array Recent orders
 */
function getRecentOrders($limit = 10) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            SELECT o.*, u.name as user_name 
            FROM orders o 
            LEFT JOIN users u ON o.user_id = u.id 
            ORDER BY o.created_at DESC 
            LIMIT ?
        ");
        $stmt->execute([$limit]);
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        error_log("[ORDER_MODEL] Retrieved " . count($orders) . " recent orders");
        return $orders;
        
    } catch (PDOException $e) {
        error_log("[ORDER_MODEL] Database error in getRecentOrders: " . $e->getMessage());
        return [];
    }
}

/**
 * Search orders
 * @param string $query Search query
 * @return array Matching orders
 */
function searchOrders($query) {
    global $pdo;
    
    try {
        $searchTerm = '%' . $query . '%';
        $stmt = $pdo->prepare("
            SELECT o.*, u.name as user_name 
            FROM orders o 
            LEFT JOIN users u ON o.user_id = u.id 
            WHERE o.id LIKE ? OR o.customer_name LIKE ? OR o.customer_email LIKE ? OR u.name LIKE ?
            ORDER BY o.created_at DESC
        ");
        $stmt->execute([$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        error_log("[ORDER_MODEL] Search found " . count($orders) . " orders for query: $query");
        return $orders;
        
    } catch (PDOException $e) {
        error_log("[ORDER_MODEL] Database error in searchOrders: " . $e->getMessage());
        return [];
    }
}