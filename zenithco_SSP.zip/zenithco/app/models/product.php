<?php
require_once __DIR__ . '/../../config/database.php';

function addProduct($name, $price, $description, $image, $stock) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO products (name, price, description, image, stock) VALUES (?, ?, ?, ?, ?)");
    return $stmt->execute([$name, $price, $description, $image, $stock]);
}

function getAllProducts() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM products WHERE is_active = 1 ORDER BY created_at DESC");
    return $stmt->fetchAll();
}

function getProductById($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function updateProduct($id, $name, $price, $description, $image, $stock) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE products SET name = ?, price = ?, description = ?, image = ?, stock = ? WHERE id = ?");
    return $stmt->execute([$name, $price, $description, $image, $stock, $id]);
}

function deleteProduct($id) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE products SET is_active = 0 WHERE id = ?");
    return $stmt->execute([$id]);
}

function getFeaturedProducts() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM products WHERE is_active = 1 ORDER BY created_at DESC LIMIT 5");
    return $stmt->fetchAll();
}

