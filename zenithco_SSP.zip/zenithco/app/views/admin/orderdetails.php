<?php include __DIR__ . '/../layout/layout.php'; ?>

<div class="min-h-screen bg-ivory px-6 py-10">
  <div class="max-w-5xl mx-auto">
    <h2 class="text-3xl font-display text-navy mb-6">Order Details</h2>
    
    <!-- Back to Orders -->
    <a href="/zenithco/public/index.php?page=manage_orders"
       class="bg-navy text-white px-4 py-2 rounded hover:bg-essence transition mb-6 inline-block">
       ← Back to Orders
    </a>

    <!-- Order Items Table -->
    <div class="overflow-x-auto mb-10">
      <table class="min-w-full bg-white text-sm border border-ether rounded-lg">
        <thead class="bg-mist text-essence uppercase text-xs">
          <tr>
            <th class="px-4 py-3">Product</th>
            <th class="px-4 py-3">Image</th>
            <th class="px-4 py-3">Price</th>
            <th class="px-4 py-3">Quantity</th>
            <th class="px-4 py-3">Total</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($items as $item): ?>
            <tr class="border-t border-ether">
              <td class="px-4 py-3"><?= htmlspecialchars($item['product_name']) ?></td>
              <td class="px-4 py-3"><img src="<?= $item['image'] ?>" class="h-12 w-12 object-cover rounded"></td>
              <td class="px-4 py-3">Rs. <?= number_format($item['price'], 2) ?></td>
              <td class="px-4 py-3"><?= $item['quantity'] ?></td>
              <td class="px-4 py-3">Rs. <?= number_format($item['quantity'] * $item['price'], 2) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- Back to Dashboard -->
    <a href="/zenithco/public/index.php?page=admin_dashboard"
       class="bg-ember text-white px-4 py-2 rounded hover:bg-essence transition inline-block">
       ← Back to Dashboard
    </a>
  </div>
</div>

<?php include __DIR__ . '/../layout/footer.php'; ?>
