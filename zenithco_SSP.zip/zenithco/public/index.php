<?php
session_start();

// Handle POST-based actions FIRST before any output
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'add_to_cart':
            require_once '../app/controllers/cartcontroller.php';
            handleAddToCart();
            break;
    }
}

$page = $_GET['page'] ?? 'admin_login';

require_once '../app/controllers/admincontroller.php';

switch ($page) {
    // ADMIN ROUTES
    case 'admin_login':
        $_SERVER['REQUEST_METHOD'] === 'POST' ? handleLogin() : showLogin();
        break;

    case 'admin_dashboard':
        showDashboard();
        break;

    case 'add_product':
    case 'view_products':
    case 'update_products':
    case 'edit_product':
    case 'delete_products':
    case 'delete_product':
        require_once '../app/controllers/productcontroller.php';
        $id = $_GET['id'] ?? null;
        if ($page === 'add_product') {
            $_SERVER['REQUEST_METHOD'] === 'POST' ? handleAddProduct() : showAddProductForm();
        } elseif ($page === 'view_products') {
            showAllProducts();
        } elseif ($page === 'update_products') {
            showAllProductsForUpdate();
        } elseif ($page === 'edit_product') {
            $_SERVER['REQUEST_METHOD'] === 'POST' ? handleEditProduct($id) : showEditProductForm($id);
        } elseif ($page === 'delete_products') {
            $_SERVER['REQUEST_METHOD'] === 'POST' ? handleBulkDelete() : showAllProductsForDelete();
        } elseif ($page === 'delete_product') {
            handleDeleteProduct($id);
        }
        break;

    case 'view_users':
        require_once '../app/controllers/usercontroller.php';
        function_exists('showAllUsers') ? showAllUsers() : printNotFound('showAllUsers');
        break;

    case 'manage_orders':
        require_once '../app/controllers/ordercontroller.php';
        showAllOrders();
        break;

    case 'admin_wishlist':
        require_once '../app/controllers/wishlistcontroller.php';
        showAdminWishlist();
        break;

    case 'update_order_status':
        require_once '../app/controllers/ordercontroller.php';
        $order_id = $_GET['id'] ?? null;
        handleOrderStatusUpdate($order_id);
        break;

    // USER AUTHENTICATION
    case 'user_login':
        require_once '../app/controllers/usercontroller.php';
        $_SERVER['REQUEST_METHOD'] === 'POST' ? handleUserLogin() : showUserLogin();
        break;

    case 'user_register':
        require_once '../app/controllers/usercontroller.php';
        $_SERVER['REQUEST_METHOD'] === 'POST' ? handleUserRegister() : showUserRegister();
        break;

    case 'logout':
        session_unset();
        session_destroy();
        header("Location: /zenithco/public/index.php?page=landing");
        exit();

    // USER DASHBOARD & PROFILE
    case 'user_dashboard':
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['redirect_after_login'] = 'user_dashboard';
            header("Location: /zenithco/public/index.php?page=user_login");
            exit();
        }
        require_once '../app/controllers/productcontroller.php';
        showLandingPage();
        break;

    case 'user_profile':
        require_once '../app/controllers/usercontroller.php';
        function_exists('showUserProfile') ? showUserProfile() : printNotFound('showUserProfile');
        break;

    case 'update_user_profile':
    case 'update_profile':
        require_once '../app/controllers/usercontroller.php';
        function_exists('updateUserProfile') ? updateUserProfile() : printNotFound('updateUserProfile');
        break;

    // PRODUCT PAGES
    case 'landing':
        require_once '../app/controllers/productcontroller.php';
        showLandingPage();
        break;

    case 'user_products':
        require_once '../app/controllers/productcontroller.php';
        showUserProductGrid();
        break;

    case 'product_detail':
        require_once '../app/controllers/productcontroller.php';
        showProductDetail();
        break;

    // CART MANAGEMENT
    case 'user_cart':
        require_once '../app/controllers/cartcontroller.php';
        showCart();
        break;

    case 'add_to_cart':
        require_once '../app/controllers/cartcontroller.php';
        handleAddToCart();
        break;

    case 'remove_from_cart':
        require_once '../app/controllers/cartcontroller.php';
        handleRemoveFromCart();
        break;

    case 'update_cart_quantity':
        require_once '../app/controllers/cartcontroller.php';
        handleUpdateCartQuantity();
        break;

    case 'clear_cart':
        require_once '../app/controllers/cartcontroller.php';
        handleClearCart();
        break;

    // CHECKOUT & ORDERS
    case 'checkout':
        require_once '../app/controllers/ordercontroller.php';
        showCheckout();
        break;

    case 'process_order':
    case 'confirm_order':
        require_once '../app/controllers/ordercontroller.php';
        processOrder();
        break;

    case 'order_success':
        require_once '../app/controllers/ordercontroller.php';
        showOrderSuccess();
        break;

    case 'user_orders':
        require_once '../app/controllers/ordercontroller.php';
        showUserOrders();
        break;

    case 'order_details':
        require_once '../app/controllers/ordercontroller.php';
        $order_id = $_GET['id'] ?? null;
        isset($_SESSION['admin_logged_in']) ? showAdminOrderDetails($order_id) : showUserOrderDetails($order_id);
        break;

    case 'download_receipt':
        require_once '../app/controllers/ordercontroller.php';
        $orderId = $_GET['order_id'] ?? null;
        if ($orderId) {
            generatePDFReceipt($orderId);
        }
        break;

    // WISHLIST
    case 'user_wishlist':
        require_once '../app/controllers/wishlistcontroller.php';
        showWishlist();
        break;

    case 'add_wishlist':
        require_once '../app/controllers/wishlistcontroller.php';
        handleAddToWishlist();
        break;

    case 'remove_wishlist':
        require_once '../app/controllers/wishlistcontroller.php';
        handleRemoveFromWishlist();
        break;

    // STATIC PAGES
    case 'aboutus':
        include '../app/views/customer/aboutus.php';
        break;

    case 'services':
        include '../app/views/customer/services.php';
        break;

    case 'contact':
        include '../app/views/customer/contact.php';
        break;

    case 'user_billing':
        include '../app/views/customer/user_billing.php';
        break;
    
    case 'process_order':
    require_once '../app/controllers/ordercontroller.php';
    processOrder();
    break;


    // DEFAULT
    default:
        echo "<h1 class='text-center mt-20 font-display text-red-700 text-xl'>404 - Page Not Found</h1>";
        break;
}

// Utility function to show not found error for missing functions
function printNotFound($functionName) {
    echo "<h1 class='text-center mt-20 font-display text-red-700 text-xl'>Function $functionName not found</h1>";
}
