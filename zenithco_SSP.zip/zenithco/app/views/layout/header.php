<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Zenith & Co Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ✅ Link to Tailwind CSS -->
    <link rel="stylesheet" href="/zenithco/public/css/tailwind.css">
</head>
<body class="bg-pure text-charcoal">
<header class="bg-navy shadow">
    <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        <!-- Brand Title -->
        <h1 class="text-2xl font-display text-ivory">Zenith & Co Admin</h1>

        <!-- Logged-In Admin Info + Logout -->
        <?php if (isset($_SESSION['admin_username'])): ?>
            <div class="text-ivory text-sm flex items-center space-x-4">
                <span>Welcome, <strong><?= htmlspecialchars($_SESSION['admin_username']) ?></strong></span>
                <a href="/zenithco/app/controllers/admincontroller.php?action=logout"
                   class="bg-ember px-3 py-1 rounded hover:bg-red-600 transition text-white text-sm">
                    Logout
                </a>
            </div>
        <?php endif; ?>
    </div>
</header>
